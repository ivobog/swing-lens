from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any

from sqlalchemy import and_, or_, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import set_committed_value

from app.models.ceri_tables import (
    CeriChangeEvent,
    CeriCompany,
    CeriProcessingRun,
    CeriScoreSnapshot,
)
from app.models.tables import BackgroundJob, PipelineRun
from app.observability.correlation import durable_causality_fields
from app.observability.db_monitor import job_phase
from app.observability.transaction_metrics import publish_after_commit
from app.services.background_job_service import (
    JobStatus,
    enqueue_job,
    heartbeat_job,
    is_cancel_requested,
    record_job_progress,
    set_job_result_status,
)
from app.services.background_worker import CancelRequested
from app.services.ceri.alert_service import CeriAlertService
from app.services.ceri.artifact_lineage import CeriArtifactOwnership
from app.services.ceri.backfill_service import CeriBackfillRequest, CeriBackfillService
from app.services.ceri.capture_service import CeriRunCaptureService
from app.services.ceri.change_rebuild_service import (
    CeriChangeRebuildCancelled,
    CeriChangeRebuildRequest,
    CeriChangeRebuildService,
)
from app.services.ceri.config import load_ceri_config
from app.services.ceri.enums import CeriDataset
from app.services.ceri.feature_flags import ceri_flags, parse_explicit_bool
from app.services.ceri.feature_rebuild_service import (
    CeriFeatureRebuildRequest,
    CeriFeatureRebuildService,
)
from app.services.ceri.normalization_service import CeriNormalizationService
from app.services.ceri.orchestration import (
    CeriIngestionCancelled,
    CeriIngestionRequest,
    CeriIngestionService,
)
from app.services.ceri.parent_pipeline_fence import require_parent_pipeline_active
from app.services.ceri.processing_run_service import CeriProcessingRunService
from app.services.ceri.provider_registry import CeriProviderRegistry
from app.services.ceri.providers.eodhd_client import EodhdTransientError
from app.services.ceri.providers.manual_provider import ManualCeriProvider
from app.services.ceri.purge_service import (
    CeriPurgeExecuteRequest,
    CeriPurgePreviewRequest,
    CeriPurgeService,
)
from app.services.configuration_delivery import anchored_job_configuration
from app.services.market_calculation_context_service import (
    resolve_pipeline_ceri_context,
    resolve_pipeline_market_context,
)
from app.services.pipeline_prerequisites import CeriParentPipelineTerminalError
from app.services.pipeline_stage_registry import (
    CERI_CAPTURE_PROGRESS_STAGE,
    CERI_CHANGE_DETECTION_PROGRESS_STAGE,
)
from app.services.redaction import redact_text

CERI_PROVIDER_INGEST = "CERI_PROVIDER_INGEST"
CERI_NORMALIZE = "CERI_NORMALIZE"
CERI_REBUILD_FEATURES = "CERI_REBUILD_FEATURES"
CERI_CAPTURE_RUN = "CERI_CAPTURE_RUN"
CERI_CHANGE_DETECTION = "CERI_CHANGE_DETECTION"
CERI_BACKFILL = "CERI_BACKFILL"
CERI_ALERT_REBUILD = "CERI_ALERT_REBUILD"
CERI_PURGE_LICENSED_DATA = "CERI_PURGE_LICENSED_DATA"

# Alert work is intentionally bounded below the PostgreSQL parameter budget and
# ordered by the immutable (created_at, id) cursor.  The result is invariant to
# this value; it controls only how much ORM state can be resident at once.
ALERT_REBUILD_BATCH_SIZE = 250

CeriJobHandler = Callable[[Session, BackgroundJob], dict[str, Any] | None]


def implemented_ceri_job_handlers() -> dict[str, CeriJobHandler]:
    from app.services.ceri.batched_job_handlers import implemented_batched_ceri_job_handlers

    return {
        CERI_PROVIDER_INGEST: execute_provider_ingest_job,
        CERI_NORMALIZE: execute_normalize_job,
        CERI_REBUILD_FEATURES: execute_rebuild_features_job,
        CERI_CAPTURE_RUN: execute_capture_run_job,
        CERI_CHANGE_DETECTION: execute_change_detection_job,
        CERI_BACKFILL: execute_backfill_job,
        CERI_ALERT_REBUILD: execute_alert_rebuild_job,
        CERI_PURGE_LICENSED_DATA: execute_purge_licensed_data_job,
        **implemented_batched_ceri_job_handlers(),
    }


@anchored_job_configuration
def execute_provider_ingest_job(
    db: Session,
    job: BackgroundJob,
    *,
    ingestion_service: CeriIngestionService | None = None,
) -> dict[str, Any]:
    if not ceri_flags().provider_ingest:
        return _skipped_job(CERI_PROVIDER_INGEST, "provider_ingest_disabled")
    payload = job.payload_json or {}
    require_parent_pipeline_active(db, job)
    dataset = _dataset(payload)
    provider = str(payload.get("provider") or "manual")
    ticker = _required_text(payload, "ticker")
    from app.services.scope_refresh_adoption import require_semantic_authority

    authority = require_semantic_authority(job) if isinstance(db, Session) else None

    if ingestion_service is None:
        ingestion_service = _ingestion_service_from_payload(payload, dataset)

    try:
        result = ingestion_service.ingest(
            db,
            CeriIngestionRequest(
                provider=provider,
                dataset=dataset,
                ticker=ticker,
                request_key=payload.get("request_key"),
                scope=payload.get("scope") or {"ticker": ticker},
                refresh_cycle_key=payload.get("refresh_cycle_key"),
                business_cutoff=_optional_date(payload.get("business_cutoff")),
                semantic_authority=authority,
            ),
            should_cancel=lambda: _heartbeat_and_check_cancel(db, job),
        )
    except CeriIngestionCancelled as exc:
        raise CancelRequested(str(exc)) from exc
    except CeriParentPipelineTerminalError:
        raise
    except EodhdTransientError:
        raise
    except SQLAlchemyError:
        raise
    except Exception as exc:
        _set_job_outcome_status(job, JobStatus.PARTIAL)
        return {
            "job_type": CERI_PROVIDER_INGEST,
            "status": "PARTIAL",
            "provider": provider,
            "dataset": dataset.value,
            "ticker": ticker,
            "failed": 1,
            "error": _safe_job_error(exc),
        }

    values = result.as_dict()
    normalize_job_id = _enqueue_normalize_job(
        db,
        source_job=job,
        source_payload=payload,
        ingestion_request_key=payload.get("request_key")
        or ingestion_service.request_key(
            CeriIngestionRequest(provider=provider, dataset=dataset, ticker=ticker)
        ),
        ingestion_result=values,
    )
    if normalize_job_id is not None:
        values["normalize_job_id"] = normalize_job_id
    if values.get("status") in {"PARTIAL", "CANCELLED"} or values.get("failed", 0):
        _set_job_outcome_status(job, JobStatus.PARTIAL)
    require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
    return {"job_type": CERI_PROVIDER_INGEST, **values}


@anchored_job_configuration
def execute_normalize_job(
    db: Session,
    job: BackgroundJob,
    *,
    normalization_service: CeriNormalizationService | None = None,
) -> dict[str, Any]:
    if not ceri_flags().enabled:
        return _skipped_job(CERI_NORMALIZE, "ceri_disabled")
    payload = job.payload_json or {}
    require_parent_pipeline_active(db, job)
    request_key = str(payload.get("request_key") or f"ceri:normalize:{job.id}")
    existing = _maybe_scalar(
        db,
        select(CeriProcessingRun).where(CeriProcessingRun.deterministic_request_key == request_key),
    )
    if existing is not None:
        values = {
            "job_type": CERI_NORMALIZE,
            "processing_run_id": existing.id,
            "status": existing.status,
            "normalized": existing.normalized_count,
            "coalesced": True,
        }
        feature_job_id = _enqueue_feature_rebuild_after_normalize(
            db,
            source_job=job,
            source_payload=payload,
            normalize_result=values,
        )
        if feature_job_id is not None:
            values["feature_job_id"] = feature_job_id
        publish_after_commit(
            db,
            "increment",
            "swinglens_ceri_normalization_total",
            dataset=str(payload.get("dataset") or "all"),
            result="coalesced",
        )
        require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
        return values

    started_at = _utcnow()
    processing_run = CeriProcessingRun(
        **durable_causality_fields(),
        job_type=CERI_NORMALIZE,
        status="RUNNING",
        deterministic_request_key=request_key,
        scope_json=payload.get("scope") or {},
        config_version=payload.get("config_version"),
        config_hash=payload.get("config_hash"),
        actor=payload.get("actor"),
        checkpoint_json={"phase": "phase_4_normalization_started"},
        started_at=started_at,
        scope_id=job.scope_id,
        refresh_cycle_id=job.refresh_cycle_id,
        acquisition_plan_id=job.acquisition_plan_id,
    )
    db.add(processing_run)
    db.flush()
    normalization_service = normalization_service or CeriNormalizationService()
    result = normalization_service.normalize(
        db,
        processing_run=processing_run,
        ingestion_run_id=_optional_int(payload.get("ingestion_run_id")),
    )
    values = {"job_type": CERI_NORMALIZE, **result.as_dict()}
    feature_job_id = _enqueue_feature_rebuild_after_normalize(
        db, source_job=job, source_payload=payload, normalize_result=values
    )
    if feature_job_id is not None:
        values["feature_job_id"] = feature_job_id
    publish_after_commit(
        db,
        "increment",
        "swinglens_ceri_normalization_total",
        dataset=str(payload.get("dataset") or "all"),
        result="partial" if values.get("failed") else "success",
    )
    require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
    return values


@anchored_job_configuration
def execute_rebuild_features_job(
    db: Session,
    job: BackgroundJob,
    *,
    feature_service: CeriFeatureRebuildService | None = None,
) -> dict[str, Any]:
    if not ceri_flags().enabled:
        return _skipped_job(CERI_REBUILD_FEATURES, "ceri_disabled")
    payload = job.payload_json or {}
    semantic_authority = None
    if isinstance(db, Session):
        from app.services.scope_refresh_adoption import require_semantic_authority

        semantic_authority = require_semantic_authority(job)
    pipeline_owned = _is_pipeline_owned_ceri_job(job, payload)
    if pipeline_owned:
        require_parent_pipeline_active(db, job)
    if pipeline_owned:
        missing_context = [
            key
            for key in ("calculation_context_id", "cutoff_at", "as_of_session", "calendar_version")
            if payload.get(key) in (None, "")
        ]
        if missing_context:
            raise ValueError(
                "Pipeline-owned CERI feature job is missing frozen context fields: "
                + ", ".join(missing_context)
            )
    processing, created = _processing_run(
        db,
        CERI_REBUILD_FEATURES,
        payload,
        default_request_key=f"ceri:feature-rebuild:{_scope_key(payload, job.id)}",
    )
    if not created and processing.status == "COMPLETED":
        values = {
            "job_type": CERI_REBUILD_FEATURES,
            "processing_run_id": processing.id,
            "status": processing.status,
            "coalesced": True,
        }
        capture_job_id = (
            _enqueue_capture_after_features(db, job=job, payload=payload)
            if processing.status == "COMPLETED"
            else None
        )
        if capture_job_id is not None:
            values["capture_job_id"] = capture_job_id
        publish_after_commit(
            db, "increment", "swinglens_ceri_feature_rebuild_total", result="coalesced"
        )
        return values
    result = (feature_service or CeriFeatureRebuildService()).rebuild(
        db,
        CeriFeatureRebuildRequest(
            company_ids=_optional_int_tuple(payload.get("company_ids")),
            ticker=payload.get("ticker"),
            as_of_session=_optional_date(payload.get("as_of_session")),
            cutoff_at=_optional_datetime(payload.get("cutoff_at")),
            from_session=_optional_date(payload.get("from_session")),
            to_session=_optional_date(payload.get("to_session")),
            run_id=_optional_int(payload.get("run_id")),
            mode=str(payload.get("mode") or "AS_KNOWN"),
            calculation_context_id=_optional_int(payload.get("calculation_context_id")),
            calendar_version=(
                str(payload["calendar_version"]) if payload.get("calendar_version") else None
            ),
            ownership_mode=(
                CeriArtifactOwnership.PIPELINE.value
                if pipeline_owned
                else CeriArtifactOwnership.STANDALONE.value
            ),
            semantic_authority=semantic_authority,
        ),
        processing_run=processing,
    )
    CeriProcessingRunService().finish(
        db,
        processing,
        status="PARTIAL" if result.failed else "COMPLETED",
        counts={"features": result.features, "warnings": result.warnings, "failed": result.failed},
        checkpoint={
            "scope": payload.get("scope") or payload,
            "processed_companies": result.processed_companies,
        },
        errors={"records": list(result.errors)} if result.errors else None,
    )
    if result.failed:
        _set_job_outcome_status(job, JobStatus.PARTIAL)
    if pipeline_owned:
        require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
    values = {
        "job_type": CERI_REBUILD_FEATURES,
        "processing_run_id": processing.id,
        "status": processing.status,
        **result.as_dict(),
    }
    capture_job_id = (
        _enqueue_capture_after_features(db, job=job, payload=payload)
        if processing.status == "COMPLETED"
        else None
    )
    if capture_job_id is not None:
        values["capture_job_id"] = capture_job_id
    publish_after_commit(
        db,
        "increment",
        "swinglens_ceri_feature_rebuild_total",
        result="partial" if result.failed else "success",
    )
    return values


@anchored_job_configuration
def execute_capture_run_job(
    db: Session,
    job: BackgroundJob,
    *,
    capture_service: CeriRunCaptureService | None = None,
) -> dict[str, Any]:
    if not ceri_flags().run_capture:
        return _skipped_job(CERI_CAPTURE_RUN, "run_capture_disabled")
    payload = job.payload_json or {}
    if _is_pipeline_owned_ceri_job(job, payload):
        require_parent_pipeline_active(db, job)
    run_id = _required_int(payload, "run_id")
    market_cutoff = None
    if isinstance(db, Session) and not _is_pipeline_owned_ceri_job(job, payload):
        from app.services.market_clock_service import MarketClockService

        operation_at = _optional_datetime(payload.get("operation_cutoff_at"))
        if operation_at is None or operation_at.utcoffset() is None:
            raise ValueError("MUTATION_FROZEN_OPERATION_CUTOFF_REQUIRED")
        market_cutoff = MarketClockService().cutoff_for(
            operation_at, reason="NEW_DURABLE_CERI_CALCULATION"
        )
    if _is_pipeline_owned_ceri_job(job, payload):
        missing = [
            key
            for key in (
                "calculation_context_id",
                "cutoff_at",
                "as_of_session",
                "calendar_version",
            )
            if payload.get(key) in (None, "")
        ]
        if missing:
            raise ValueError(
                "Pipeline-owned CERI capture job is missing frozen context fields: "
                + ", ".join(missing)
            )
        pipeline_id = _optional_int(payload.get("pipeline_run_id"))
        workflow_key = str(job.workflow_key or payload.get("workflow_key") or "")
        pipeline = db.get(PipelineRun, pipeline_id) if pipeline_id is not None else None
        retained_ceri_context_id = (
            (pipeline.result_json or {}).get("ceri_calculation_context_id")
            if pipeline is not None
            else None
        )
        resolver = (
            resolve_pipeline_ceri_context
            if workflow_key.startswith("ceri:pipeline:")
            and pipeline_id is not None
            and int(retained_ceri_context_id or 0)
            == int(_optional_int(payload.get("calculation_context_id")) or 0)
            else resolve_pipeline_market_context
        )
        resolver_kwargs = {
            "calculation_context_id": _optional_int(payload.get("calculation_context_id")),
            "upload_run_id": run_id,
            "expected_cutoff_at": _optional_datetime(payload.get("cutoff_at")),
            "expected_latest_completed_session": _optional_date(payload.get("as_of_session")),
            "expected_calendar_version": str(payload["calendar_version"]),
        }
        if resolver is resolve_pipeline_ceri_context:
            retained_key = (pipeline.result_json or {}).get("ceri_provider_workflow_key")
            if (
                job.workflow_key != workflow_key
                or retained_key != workflow_key
                or payload.get("workflow_key", workflow_key) != workflow_key
                or job.related_run_id != run_id
            ):
                raise ValueError("CERI_CAPTURE_WORKFLOW_OWNER_MISMATCH")
        if pipeline_id is not None:
            resolver_kwargs["pipeline_run_id"] = pipeline_id
        market_cutoff = resolver(db, **resolver_kwargs)
    processing, created = _processing_run(
        db,
        CERI_CAPTURE_RUN,
        payload,
        default_request_key=f"ceri:capture-run:{run_id}",
    )
    if not created and processing.status == "COMPLETED":
        values = {
            "job_type": CERI_CAPTURE_RUN,
            "processing_run_id": processing.id,
            "status": processing.status,
            "coalesced": True,
        }
        change_job_id = _enqueue_change_after_capture(
            db,
            job=job,
            run_id=run_id,
        )
        if change_job_id is not None:
            values["change_job_id"] = change_job_id
        publish_after_commit(db, "increment", "swinglens_ceri_scoring_total", result="coalesced")
        return values
    with job_phase("capture_calculation_and_persistence"):
        capture = capture_service or CeriRunCaptureService()
        control_plane = getattr(job, "_control_plane_progress", None)

        def capture_progress(ticker: str, processed: int, total: int) -> None:
            checkpoint_at = datetime.now(UTC)
            metadata = dict(job.operational_metadata_json or {})
            prior = dict(metadata.get("ceri_capture") or {})
            attempt_started_at = dict(metadata.get("last_attempt") or {}).get("started_at")
            try:
                previous_at = (
                    datetime.fromisoformat(str(attempt_started_at))
                    if attempt_started_at
                    else job.locked_at or job.started_at
                )
            except ValueError:
                previous_at = job.locked_at or job.started_at
            if prior.get("updated_at"):
                try:
                    previous_at = datetime.fromisoformat(str(prior["updated_at"]))
                except ValueError:
                    pass
            if previous_at is not None and previous_at.tzinfo is None:
                previous_at = previous_at.replace(tzinfo=UTC)
            checkpoint_gap = (
                max(0.0, (checkpoint_at - previous_at).total_seconds())
                if previous_at is not None
                else 0.0
            )
            metadata["ceri_capture"] = {
                "processed": processed,
                "total": total,
                "ticker": ticker,
                "updated_at": checkpoint_at.isoformat(),
                "max_checkpoint_gap_seconds": max(
                    float(prior.get("max_checkpoint_gap_seconds") or 0.0),
                    checkpoint_gap,
                ),
            }
            if callable(control_plane):
                with db.no_autoflush:
                    require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
                if control_plane(
                    stage=CERI_CAPTURE_PROGRESS_STAGE,
                    current_item=ticker,
                    last_completed_item=ticker if processed else None,
                    processed=processed,
                    total=total,
                    checkpoint_version=f"ceri-capture:{processed}:{ticker}",
                    only_if_advanced=False,
                    operational_metadata_patch={"ceri_capture": metadata["ceri_capture"]},
                ):
                    raise CancelRequested("CERI capture cancelled.")
                set_committed_value(job, "operational_metadata_json", metadata)
            elif job.id is not None and job.execution_token:
                job.operational_metadata_json = metadata
                record_job_progress(
                    db,
                    job_id=job.id,
                    execution_token=str(job.execution_token),
                    stage=CERI_CAPTURE_PROGRESS_STAGE,
                    current_item=ticker,
                    last_completed_item=ticker if processed else None,
                    processed=processed,
                    total=total,
                    checkpoint_version=f"ceri-capture:{processed}:{ticker}",
                    # Preparation and persistence checkpoints intentionally
                    # retain their item count while phase identity advances.
                    only_if_advanced=False,
                )
                heartbeat = getattr(job, "_heartbeat", None)
                if callable(heartbeat):
                    require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
                    heartbeat()
            else:
                job.operational_metadata_json = metadata

        capture_kwargs: dict[str, Any] = {}
        if market_cutoff is not None:
            capture_kwargs["market_cutoff"] = market_cutoff
        if isinstance(capture, CeriRunCaptureService):
            capture_kwargs["progress_callback"] = capture_progress
            capture_kwargs["expected_pipeline_id"] = _optional_int(payload.get("pipeline_run_id"))
        result = capture.capture_run(db, run_id, **capture_kwargs)
    values = result.as_dict()
    CeriProcessingRunService().finish(
        db,
        processing,
        status="PARTIAL" if values.get("failed") else "COMPLETED",
        counts={
            "score_snapshots": values.get("score_snapshots", 0),
            "change_events": values.get("change_events", 0),
            "alerts": values.get("alerts", 0),
            "failed": values.get("failed", 0),
            "warnings": values.get("stale", 0) + values.get("conflicted", 0),
        },
        checkpoint={"run_id": run_id},
    )
    if _is_pipeline_owned_ceri_job(job, payload):
        require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
    change_job_id = (
        _enqueue_change_after_capture(db, job=job, run_id=run_id)
        if processing.status == "COMPLETED" or bool(job.workflow_key)
        else None
    )
    if change_job_id is not None:
        values["change_job_id"] = change_job_id
    publish_after_commit(
        db,
        "increment",
        "swinglens_ceri_scoring_total",
        result="partial" if values.get("failed") else "success",
    )
    if values.get("failed"):
        _set_job_outcome_status(job, JobStatus.PARTIAL)
    return {
        "job_type": CERI_CAPTURE_RUN,
        "processing_run_id": processing.id,
        "status": processing.status,
        **values,
    }


@anchored_job_configuration
def execute_change_detection_job(
    db: Session,
    job: BackgroundJob,
    *,
    change_service: CeriChangeRebuildService | None = None,
) -> dict[str, Any]:
    if not ceri_flags().enabled:
        return _skipped_job(CERI_CHANGE_DETECTION, "ceri_disabled")
    payload = job.payload_json or {}
    if _is_pipeline_owned_ceri_job(job, payload):
        require_parent_pipeline_active(db, job)
    _verify_tail_population(db, job, payload)
    semantic_authority = None
    if isinstance(db, Session):
        from app.services.scope_refresh_adoption import require_semantic_authority

        semantic_authority = require_semantic_authority(job)
    processing, created = _processing_run(
        db,
        CERI_CHANGE_DETECTION,
        payload,
        default_request_key=f"ceri:change-rebuild:{_scope_key(payload, job.id)}",
    )
    if not created and processing.status == "COMPLETED":
        change_ids = tuple(
            int(value) for value in (processing.checkpoint_json or {}).get("change_ids", [])
        )
        values = {
            "job_type": CERI_CHANGE_DETECTION,
            "processing_run_id": processing.id,
            "status": processing.status,
            "coalesced": True,
            "change_ids": list(change_ids),
        }
        alert_job_id = _enqueue_alert_after_change(
            db,
            job=job,
            payload=payload,
            change_ids=change_ids,
        )
        if alert_job_id is not None:
            values["alert_job_id"] = alert_job_id
        else:
            _release_pipeline_after_ceri(db, job)
        return values
    request = CeriChangeRebuildRequest(
        score_ids=_optional_int_tuple(payload.get("score_ids")),
        company_ids=_optional_int_tuple(payload.get("company_ids")),
        ticker=payload.get("ticker"),
        run_id=_optional_int(payload.get("run_id")),
        from_session=_optional_date(payload.get("from_session")),
        to_session=_optional_date(payload.get("to_session")),
        changed_since=_optional_datetime(payload.get("changed_since")),
        as_of_session=_optional_date(payload.get("as_of_session")),
        cutoff_at=_optional_datetime(payload.get("cutoff_at")),
        semantic_authority=semantic_authority,
    )
    service = change_service or CeriChangeRebuildService()
    with job_phase("change_calculation_and_persistence"):
        if isinstance(db, Session):
            execution_token = str(job.execution_token or "")
            control_plane = getattr(job, "_control_plane_progress", None)

            def should_cancel() -> bool:
                if callable(control_plane):
                    return bool(control_plane())
                heartbeat_job(db, job, execution_token=execution_token)
                return is_cancel_requested(db, job.id)

            def report_progress(
                processed: int,
                total: int,
                company_ids: tuple[int, ...],
            ) -> None:
                if callable(control_plane):
                    control_plane(
                        stage=CERI_CHANGE_DETECTION_PROGRESS_STAGE,
                        current_item=f"companies:{company_ids[0]}-{company_ids[-1]}",
                        last_completed_item=str(company_ids[-1]),
                        processed=processed,
                        total=total,
                        checkpoint_version="ceri-change-company-chunks-v1",
                        only_if_advanced=True,
                    )
                    return
                heartbeat_job(db, job, execution_token=execution_token)
                record_job_progress(
                    db,
                    job_id=job.id,
                    execution_token=execution_token,
                    stage=CERI_CHANGE_DETECTION_PROGRESS_STAGE,
                    current_item=f"companies:{company_ids[0]}-{company_ids[-1]}",
                    last_completed_item=str(company_ids[-1]),
                    processed=processed,
                    total=total,
                    checkpoint_version="ceri-change-company-chunks-v1",
                    only_if_advanced=True,
                )

            try:
                result = service.rebuild(
                    db,
                    request,
                    should_cancel=should_cancel,
                    progress_callback=report_progress,
                )
            except CeriChangeRebuildCancelled as exc:
                raise CancelRequested(str(exc)) from exc
        else:
            result = service.rebuild(db, request)
    raw_change_ids = getattr(result, "change_ids", None)
    change_ids = tuple(int(value) for value in (raw_change_ids or ()))
    CeriProcessingRunService().finish(
        db,
        processing,
        status="PARTIAL" if result.failed else "COMPLETED",
        counts={
            "change_events": result.changes,
            "warnings": result.warnings,
            "failed": result.failed,
        },
        checkpoint={
            "scope": payload.get("scope") or payload,
            "change_count": result.changes,
            "change_ids": list(change_ids),
        },
        errors={"records": list(result.errors)} if result.errors else None,
    )
    if result.failed:
        _set_job_outcome_status(job, JobStatus.PARTIAL)
    if _is_pipeline_owned_ceri_job(job, payload):
        require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
    values = {
        "job_type": CERI_CHANGE_DETECTION,
        "processing_run_id": processing.id,
        "status": processing.status,
        **result.as_dict(),
    }
    alert_job_id = (
        _enqueue_alert_after_change(
            db,
            job=job,
            payload=payload,
            change_ids=change_ids,
        )
        if (change_ids or (raw_change_ids is None and result.changes) or job.workflow_key)
        and processing.status == "COMPLETED"
        else None
    )
    if alert_job_id is not None:
        values["alert_job_id"] = alert_job_id
    else:
        _release_pipeline_after_ceri(db, job)
    return values


@anchored_job_configuration
def execute_backfill_job(
    db: Session,
    job: BackgroundJob,
    *,
    backfill_service: CeriBackfillService | None = None,
) -> dict[str, Any]:
    if not ceri_flags().backfill:
        return _skipped_job(CERI_BACKFILL, "backfill_disabled")
    payload = job.payload_json or {}
    from app.services.scope_refresh_adoption import require_semantic_authority

    authority = require_semantic_authority(job) if isinstance(db, Session) else None
    result = (backfill_service or CeriBackfillService()).run(
        db,
        CeriBackfillRequest(
            provider=str(payload.get("provider") or "manual"),
            dataset=str(payload.get("dataset") or "estimates"),
            ticker=payload.get("ticker"),
            start=_optional_date(payload.get("start")),
            end=_optional_date(payload.get("end")),
            mode=str(payload.get("mode") or "AS_KNOWN"),
            actor=payload.get("actor"),
            tickers=tuple(
                str(ticker) for ticker in payload.get("tickers", []) if str(ticker).strip()
            ),
            refresh_cycle_key=payload.get("refresh_cycle_key"),
            semantic_authority=authority,
        ),
    )
    if result.status == "PARTIAL":
        _set_job_outcome_status(job, JobStatus.PARTIAL)
    return {"job_type": CERI_BACKFILL, **result.as_dict()}


@anchored_job_configuration
def execute_alert_rebuild_job(db: Session, job: BackgroundJob) -> dict[str, Any]:
    if not ceri_flags().alerts:
        values = _skipped_job(CERI_ALERT_REBUILD, "alerts_disabled")
        _release_pipeline_after_ceri(db, job)
        return values
    payload = job.payload_json or {}
    if _is_pipeline_owned_ceri_job(job, payload):
        require_parent_pipeline_active(db, job)
    _verify_tail_population(db, job, payload)
    processing, created = _processing_run(
        db,
        CERI_ALERT_REBUILD,
        payload,
        default_request_key=f"ceri:alert-rebuild:{_scope_key(payload, job.id)}",
    )
    if not created and processing.status == "COMPLETED":
        values = {
            "job_type": CERI_ALERT_REBUILD,
            "status": processing.status,
            "processing_run_id": processing.id,
            "coalesced": True,
        }
        _release_pipeline_after_ceri(db, job)
        return values
    alerts_enabled = parse_explicit_bool(payload.get("alerts_enabled"), default=ceri_flags().alerts)
    from app.services.configuration_delivery import current_delivery, delivered_configuration

    if current_delivery() is not None:
        alerts_enabled = delivered_configuration("decision.alerts.ceri").values["enabled"]
    service = CeriAlertService(alerts_enabled=bool(alerts_enabled))
    alert_count = duplicate_count = skipped_count = eligible_change_count = 0
    for changes in _eligible_change_batches(db, payload):
        company_ids = sorted({int(change.company_id) for change in changes})
        ticker_by_company = (
            {
                int(company.id): company.ticker
                for company in db.scalars(
                    select(CeriCompany).where(CeriCompany.id.in_(company_ids))
                )
            }
            if isinstance(db, Session)
            else {
                company.id: company.ticker
                for company in _load_rows(db, CeriCompany)
                if company.id in set(company_ids)
            }
        )
        batch_result = service.rebuild_alerts(
            db,
            changes=changes,
            ticker_by_company=ticker_by_company,
        )
        eligible_change_count += len(changes)
        alert_count += batch_result.alerts
        duplicate_count += batch_result.duplicates
        skipped_count += batch_result.skipped
    CeriProcessingRunService().finish(
        db,
        processing,
        status="COMPLETED",
        counts={
            "alerts": alert_count,
            "warnings": 0,
            "failed": 0,
        },
        checkpoint={
            "duplicates": duplicate_count,
            "skipped": skipped_count,
            "eligible_change_count": eligible_change_count,
            "alerts_enabled": bool(alerts_enabled),
        },
    )
    values = {
        "job_type": CERI_ALERT_REBUILD,
        "processing_run_id": processing.id,
        "status": processing.status,
        "alerts_status": "REBUILT" if alerts_enabled else "SKIPPED_DISABLED",
        "alerts": alert_count,
        "duplicates": duplicate_count,
        "skipped": skipped_count,
    }
    _release_pipeline_after_ceri(db, job)
    return values


@anchored_job_configuration
def execute_purge_licensed_data_job(db: Session, job: BackgroundJob) -> dict[str, Any]:
    if not ceri_flags().admin:
        return _skipped_job(CERI_PURGE_LICENSED_DATA, "admin_disabled")
    payload = job.payload_json or {}
    execute = parse_explicit_bool(payload.get("execute"), default=False)
    preview_hash = str(payload.get("preview_manifest_hash") or "")
    processing_key = preview_hash or f"scope:{_scope_key(payload, job.id)}"
    processing, created = _processing_run(
        db,
        CERI_PURGE_LICENSED_DATA,
        payload,
        default_request_key=f"ceri:purge:{processing_key}",
    )
    if not created and processing.status == "COMPLETED":
        return {
            "job_type": CERI_PURGE_LICENSED_DATA,
            "status": processing.status,
            "processing_run_id": processing.id,
            "coalesced": True,
        }
    service = CeriPurgeService()
    if execute:
        audit = service.execute(
            db,
            CeriPurgeExecuteRequest(
                provider=str(payload.get("provider") or "manual"),
                license_scope=str(payload.get("license_scope") or "manual"),
                actor=str(payload.get("actor") or "system"),
                reason=str(payload.get("reason") or "licensed data purge execution"),
                confirmation_token=str(payload.get("confirmation_token") or ""),
                preview_manifest_hash=preview_hash,
            ),
            job_id=job.id,
            processing_run_id=processing.id,
        )
    else:
        audit = service.preview(
            db,
            CeriPurgePreviewRequest(
                provider=str(payload.get("provider") or "manual"),
                license_scope=str(payload.get("license_scope") or "manual"),
                actor=str(payload.get("actor") or "system"),
                reason=str(payload.get("reason") or "licensed data purge preview"),
                preview_manifest_hash=preview_hash or None,
            ),
            job_id=job.id,
            processing_run_id=processing.id,
        )
    affected_counts = audit.affected_counts_json or {}
    CeriProcessingRunService().finish(
        db,
        processing,
        status="COMPLETED",
        counts={
            "read": int(affected_counts.get("source_records") or 0),
            "warnings": 0,
            "failed": 0,
        },
        checkpoint={
            "purge_audit_id": audit.id,
            "preview_manifest_hash": audit.preview_manifest_hash,
            "purge_status": audit.status,
        },
    )
    return {
        "job_type": CERI_PURGE_LICENSED_DATA,
        "processing_run_id": processing.id,
        "purge_audit_id": audit.id,
        "status": audit.status,
    }


def _ingestion_service_from_payload(
    payload: dict[str, Any],
    dataset: CeriDataset,
) -> CeriIngestionService:
    config = load_ceri_config()
    providers = None
    manual_path = payload.get("manual_path")
    if manual_path:
        providers = {
            "manual": ManualCeriProvider.from_path(
                Path(str(manual_path)),
                dataset=dataset,
                provider_terms_version=config.retention.provider_terms_version,
            )
        }
    return CeriIngestionService(
        config=config,
        registry=CeriProviderRegistry(providers=providers, config=config),
    )


def _finish_processing_job(
    db: Session,
    job: BackgroundJob,
    job_type: str,
    *,
    feature_count: int = 0,
    change_count: int = 0,
) -> dict[str, Any]:
    payload = job.payload_json or {}
    run, created = _processing_run(
        db,
        job_type,
        payload,
        default_request_key=f"ceri:{job_type.lower()}:{job.id}",
    )
    if not created and run.status == "COMPLETED":
        return {
            "job_type": job_type,
            "processing_run_id": run.id,
            "status": run.status,
            "coalesced": True,
        }
    CeriProcessingRunService().finish(
        db,
        run,
        status="COMPLETED",
        counts={"features": feature_count, "change_events": change_count},
        checkpoint={"phase": job_type.lower()},
    )
    return {"job_type": job_type, "processing_run_id": run.id, "status": run.status}


def _processing_run(
    db: Session,
    job_type: str,
    payload: dict[str, Any],
    *,
    default_request_key: str,
) -> tuple[CeriProcessingRun, bool]:
    config = load_ceri_config()
    semantic_authority = None
    if all(payload.get(key) for key in ("scope_id", "refresh_cycle_id", "acquisition_plan_id")):
        from app.services.scope_refresh_adoption import SemanticWorkAuthority

        semantic_authority = SemanticWorkAuthority(
            scope_id=str(payload["scope_id"]),
            refresh_cycle_id=str(payload["refresh_cycle_id"]),
            acquisition_plan_id=str(payload["acquisition_plan_id"]),
        )
    return CeriProcessingRunService().create_or_get(
        db,
        job_type=job_type,
        request_key=str(payload.get("request_key") or default_request_key),
        scope=payload.get("scope") or payload,
        config_version=str(payload.get("config_version") or config.engine.config_version),
        config_hash=str(payload.get("config_hash") or config.config_hash),
        actor=payload.get("actor"),
        cutoff_at=_optional_datetime(payload.get("cutoff_at")),
        semantic_authority=semantic_authority,
    )


def _verify_tail_population(db: Session, job: BackgroundJob, payload: dict[str, Any]) -> None:
    if not isinstance(db, Session) or not payload.get("pipeline_run_id"):
        return
    from app.services.ceri.score_population import certified_scores

    if not payload.get("score_ids") or job.related_run_id != payload.get("run_id"):
        raise ValueError("CERI_CERTIFIED_CAPTURE_RECEIPT_MISSING")
    owner = db.get(PipelineRun, payload["pipeline_run_id"])
    if owner is None or owner.upload_run_id != job.related_run_id:
        raise ValueError("CERI_CAPTURE_OWNER_MISMATCH")
    from app.services.configuration_delivery import binding_reference

    if payload.get("effective_configuration_anchor") != binding_reference(
        db, pipeline_run_id=owner.id
    ):
        raise ValueError("CERI_CAPTURE_CONFIGURATION_ANCHOR_MISMATCH")
    if (owner.result_json or {}).get("ceri_calculation_context_id") is not None:
        if (owner.result_json or {}).get("ceri_provider_workflow_key") != job.workflow_key:
            raise ValueError("CERI_CAPTURE_WORKFLOW_OWNER_MISMATCH")
    certified_scores(
        db, owner.id, payload.get("calculation_context_id"), expected_ids=payload["score_ids"]
    )


def _eligible_changes(
    db: Session,
    payload: dict[str, Any],
    *,
    after: tuple[datetime, int] | None = None,
    limit: int | None = None,
) -> list[CeriChangeEvent]:
    if isinstance(db, Session):
        statement = select(CeriChangeEvent)
        ids = sorted(
            {int(value) for value in payload.get("change_ids", []) if str(value).isdigit()}
        )
        has_authoritative_scope = bool(ids)
        if payload.get("score_ids") is not None:
            scope = payload["score_ids"]
            if ids:
                # Revision/guidance events can be independent of a score change.
                companies = select(CeriScoreSnapshot.company_id).where(
                    CeriScoreSnapshot.id.in_(scope)
                )
                statement = statement.where(
                    CeriChangeEvent.company_id.in_(companies),
                    or_(
                        CeriChangeEvent.to_snapshot_id.is_(None),
                        CeriChangeEvent.to_snapshot_id.in_(scope),
                    ),
                )
            else:
                statement = statement.where(CeriChangeEvent.to_snapshot_id.in_(scope))
        if ids:
            statement = statement.where(CeriChangeEvent.id.in_(ids))
        else:
            run_id = _optional_int(payload.get("run_id"))
            if run_id is not None:
                has_authoritative_scope = True
                run_snapshot_ids = select(CeriScoreSnapshot.id).where(
                    CeriScoreSnapshot.run_id == run_id
                )
                statement = statement.where(
                    or_(
                        CeriChangeEvent.from_snapshot_id.in_(run_snapshot_ids),
                        CeriChangeEvent.to_snapshot_id.in_(run_snapshot_ids),
                    )
                )
        company_ids = set(_optional_int_tuple(payload.get("company_ids")) or ())
        if company_ids:
            has_authoritative_scope = True
            statement = statement.where(CeriChangeEvent.company_id.in_(sorted(company_ids)))
        ticker = str(payload.get("ticker") or "").strip()
        if ticker:
            has_authoritative_scope = True
            statement = statement.where(
                CeriChangeEvent.company_id.in_(
                    select(CeriCompany.id).where(CeriCompany.ticker == ticker.upper())
                )
            )
        since = _optional_datetime(payload.get("changed_since"))
        if since is not None:
            has_authoritative_scope = True
            statement = statement.where(CeriChangeEvent.created_at >= since)
        if not has_authoritative_scope:
            raise ValueError("CERI_ALERT_REBUILD_SCOPE_REQUIRED")
        if after is not None:
            after_created, after_id = after
            statement = statement.where(
                or_(
                    CeriChangeEvent.created_at > after_created,
                    and_(
                        CeriChangeEvent.created_at == after_created,
                        CeriChangeEvent.id > after_id,
                    ),
                )
            )
        statement = statement.order_by(CeriChangeEvent.created_at, CeriChangeEvent.id)
        if limit is not None:
            statement = statement.limit(limit)
        return list(db.scalars(statement))

    # Lightweight unit-test adapters do not execute SQL expressions.  Preserve
    # their fixture behavior while the production path above remains SQL-scoped.
    changes = _load_rows(db, CeriChangeEvent)
    ids = {int(value) for value in payload.get("change_ids", []) if str(value).isdigit()}
    if ids:
        changes = [change for change in changes if change.id in ids]
    run_id = _optional_int(payload.get("run_id"))
    if run_id is not None and not ids:
        snapshots = {
            snapshot.id
            for snapshot in _load_rows(db, CeriScoreSnapshot)
            if snapshot.run_id == run_id
        }
        changes = [
            change
            for change in changes
            if change.from_snapshot_id in snapshots or change.to_snapshot_id in snapshots
        ]
    company_ids = set(_optional_int_tuple(payload.get("company_ids")) or ())
    if company_ids:
        changes = [change for change in changes if change.company_id in company_ids]
    if payload.get("ticker"):
        company_ids_for_ticker = {
            company.id
            for company in _load_rows(db, CeriCompany)
            if company.ticker.upper() == str(payload["ticker"]).upper()
        }
        changes = [change for change in changes if change.company_id in company_ids_for_ticker]
    since = _optional_datetime(payload.get("changed_since"))
    if since is not None:
        changes = [change for change in changes if change.created_at >= since]
    return sorted(changes, key=lambda change: (change.created_at, change.id or 0))


def _eligible_change_batches(
    db: Session,
    payload: dict[str, Any],
    *,
    batch_size: int = ALERT_REBUILD_BATCH_SIZE,
):
    if batch_size <= 0:
        raise ValueError("alert rebuild batch_size must be positive")
    if not isinstance(db, Session):
        rows = _eligible_changes(db, payload)
        for start in range(0, len(rows), batch_size):
            yield rows[start : start + batch_size]
        return
    ids = sorted({int(value) for value in payload.get("change_ids", []) if str(value).isdigit()})
    if ids:
        for start in range(0, len(ids), batch_size):
            scoped_payload = {**payload, "change_ids": ids[start : start + batch_size]}
            rows = _eligible_changes(db, scoped_payload)
            if rows:
                yield rows
        return
    cursor: tuple[datetime, int] | None = None
    while True:
        rows = _eligible_changes(db, payload, after=cursor, limit=batch_size)
        if not rows:
            return
        yield rows
        tail = rows[-1]
        cursor = (tail.created_at, int(tail.id))


def _load_rows(db: Session, model: Any) -> list[Any]:
    if isinstance(db, Session):
        raise TypeError(
            "predicate-free CERI model loading is fixture-only; production reads require SQL scope"
        )
    scalars = getattr(db, "scalars", None)
    if not callable(scalars):
        return []
    result = scalars(select(model))
    return list(result.all() if hasattr(result, "all") else result)


def _scope_key(payload: dict[str, Any], fallback: int) -> str:
    import hashlib
    import json

    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()[:24] or str(fallback)


def _child_priority(job: BackgroundJob) -> int:
    """Run dependent work before returning to the wider provider backlog.

    Background jobs sort smaller numeric priorities first. CERI previously
    added ten at each stage, which inverted the intended dependency order and
    starved normalize/feature/capture jobs behind every provider request.
    """

    return max(0, int(job.priority or 100) - 10)


def _enqueue_normalize_job(
    db: Session,
    *,
    source_job: BackgroundJob,
    source_payload: dict[str, Any],
    ingestion_request_key: str,
    ingestion_result: dict[str, Any],
) -> int | None:
    if not ingestion_result.get("ingestion_run_id"):
        return None
    if not any(
        ingestion_result.get(key, 0)
        for key in ("inserted", "deduplicated", "corrected", "quarantined")
    ):
        return None

    request_key = f"ceri:normalize:{ingestion_request_key}"
    existing = _maybe_scalar(
        db,
        select(BackgroundJob)
        .where(BackgroundJob.job_type == CERI_NORMALIZE)
        .where(BackgroundJob.payload_json["request_key"].astext == request_key),
    )
    if existing is not None:
        _bind_semantic_child(source_job, existing)
        return existing.id

    job = enqueue_job(
        db,
        CERI_NORMALIZE,
        {
            "request_key": request_key,
            "ingestion_run_id": ingestion_result["ingestion_run_id"],
            "provider": ingestion_result["provider"],
            "dataset": ingestion_result["dataset"],
            "scope": source_payload.get("scope") or {"ticker": source_payload.get("ticker")},
            "ticker": source_payload.get("ticker"),
            "run_id": source_payload.get("run_id") or source_job.related_run_id,
            "config_version": source_payload.get("config_version"),
            "config_hash": source_payload.get("config_hash"),
            "actor": source_payload.get("actor"),
            **_temporal_context_payload(source_payload),
        },
        related_run_id=source_job.related_run_id,
        priority=_child_priority(source_job),
        max_retries=source_job.max_retries or 3,
        request_key=request_key,
    )
    _bind_semantic_child(source_job, job)
    return job.id


def _enqueue_feature_rebuild_after_normalize(
    db: Session,
    *,
    source_job: BackgroundJob,
    source_payload: dict[str, Any],
    normalize_result: dict[str, Any],
) -> int | None:
    if normalize_result.get("status") != "COMPLETED":
        return None
    ticker = source_payload.get("ticker")
    if not ticker:
        return None
    upstream_id = normalize_result.get("processing_run_id") or source_job.id
    request_key = f"ceri:feature-rebuild:upstream:{upstream_id}"
    job = enqueue_job(
        db,
        CERI_REBUILD_FEATURES,
        {
            "request_key": request_key,
            "ticker": str(ticker).upper(),
            "run_id": source_payload.get("run_id") or source_job.related_run_id,
            "scope": source_payload.get("scope") or {"ticker": str(ticker).upper()},
            "mode": "AS_KNOWN",
            **_temporal_context_payload(source_payload),
        },
        related_run_id=source_payload.get("run_id") or source_job.related_run_id,
        priority=_child_priority(source_job),
        max_retries=source_job.max_retries or 3,
        request_key=request_key,
    )
    _bind_semantic_child(source_job, job)
    return job.id


def _enqueue_capture_after_features(
    db: Session, *, job: BackgroundJob, payload: dict[str, Any]
) -> int | None:
    if not ceri_flags().run_capture:
        return None
    run_id = _optional_int(payload.get("run_id") or job.related_run_id)
    if run_id is None:
        return None
    require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
    # A provider run rebuilds features independently for each ticker/dataset.
    # Use the completed feature job as part of the capture identity so later
    # feature arrivals can capture newly eligible tickers. CeriRunCaptureService
    # remains idempotent and skips snapshots already stored for this run/version.
    upstream_id = job.id or payload.get("request_key") or "unknown"
    request_key = f"ceri:capture-run:{run_id}:upstream:{upstream_id}"
    capture_job = enqueue_job(
        db,
        CERI_CAPTURE_RUN,
        {
            "request_key": request_key,
            "run_id": run_id,
            **_temporal_context_payload(payload),
        },
        related_run_id=run_id,
        priority=_child_priority(job),
        max_retries=job.max_retries or 3,
        request_key=request_key,
    )
    _bind_semantic_child(job, capture_job)
    return capture_job.id


def _enqueue_change_after_capture(db: Session, *, job: BackgroundJob, run_id: int) -> int | None:
    require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
    request_key = (
        f"{job.workflow_key}:change" if job.workflow_key else f"ceri:change-rebuild:run:{run_id}"
    )
    score_scope = {}
    if isinstance(db, Session) and (job.payload_json or {}).get("pipeline_run_id"):
        from app.services.ceri.score_population import certified_scores

        payload = job.payload_json
        scores = certified_scores(db, payload["pipeline_run_id"], payload["calculation_context_id"])
        score_scope["score_ids"] = [row.id for row in scores]
    change_job = enqueue_job(
        db,
        CERI_CHANGE_DETECTION,
        {
            "request_key": request_key,
            "run_id": run_id,
            "workflow_key": job.workflow_key,
            **_temporal_context_payload(job.payload_json or {}),
            **score_scope,
        },
        related_run_id=run_id,
        priority=_child_priority(job),
        max_retries=job.max_retries or 3,
        request_key=request_key,
        workflow_key=job.workflow_key,
    )
    _bind_semantic_child(job, change_job)
    return change_job.id


def _enqueue_alert_after_change(
    db: Session,
    *,
    job: BackgroundJob,
    payload: dict[str, Any],
    change_ids: tuple[int, ...] = (),
) -> int | None:
    require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
    if not ceri_flags().alerts:
        return None
    upstream_id = payload.get("run_id") or job.related_run_id or job.id
    request_key = (
        f"{job.workflow_key}:alert"
        if job.workflow_key
        else f"ceri:alert-rebuild:upstream:{upstream_id}"
    )
    alert_job = enqueue_job(
        db,
        CERI_ALERT_REBUILD,
        {
            "request_key": request_key,
            "run_id": payload.get("run_id"),
            "workflow_key": job.workflow_key,
            "change_ids": list(change_ids),
            **_temporal_context_payload(payload),
        },
        related_run_id=job.related_run_id,
        priority=_child_priority(job),
        max_retries=job.max_retries or 3,
        request_key=request_key,
        workflow_key=job.workflow_key,
    )
    _bind_semantic_child(job, alert_job)
    return alert_job.id


def _release_pipeline_after_ceri(db: Session, job: BackgroundJob) -> None:
    if not _is_pipeline_owned_ceri_job(job, job.payload_json or {}):
        return
    require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
    from app.services.pipeline_service import enqueue_pipeline_after_ceri_completion

    enqueue_pipeline_after_ceri_completion(db, job)


def _skipped_job(job_type: str, reason: str) -> dict[str, Any]:
    return {"job_type": job_type, "status": "SKIPPED", "skipped": 1, "reason": reason}


def _is_pipeline_owned_ceri_job(job: BackgroundJob, payload: dict[str, Any]) -> bool:
    workflow_key = str(payload.get("workflow_key") or job.workflow_key or "")
    return workflow_key.startswith("ceri:pipeline:") or any(
        payload.get(key) not in (None, "")
        for key in (
            "calculation_context_id",
            "cutoff_at",
            "as_of_session",
            "calendar_version",
        )
    )


def _temporal_context_payload(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        key: payload[key]
        for key in (
            "pipeline_run_id",
            "score_ids",
            "calculation_context_id",
            "cutoff_at",
            "as_of_session",
            "calendar_version",
            "scope_id",
            "refresh_cycle_id",
            "acquisition_plan_id",
        )
        if payload.get(key) not in (None, "")
    }


def _bind_semantic_child(source: BackgroundJob, child: BackgroundJob) -> None:
    from app.services.scope_refresh_adoption import (
        LegacySemanticAuthorityError,
        bind_semantic_authority,
        require_semantic_authority,
    )

    try:
        authority = require_semantic_authority(source)
    except LegacySemanticAuthorityError:
        return
    bind_semantic_authority(child, authority, required_for_parent_completion=True)


def _safe_job_error(exc: Exception) -> str:
    return redact_text(str(exc)).replace("\n", " ").strip()[:500] or exc.__class__.__name__


def _set_job_outcome_status(job: BackgroundJob, status: str) -> None:
    set_job_result_status(job, status)


def _heartbeat_and_check_cancel(db: Session, job: BackgroundJob) -> bool:
    require_parent_pipeline_active(db, job, lock_for_checkpoint=True)
    heartbeat = getattr(job, "_heartbeat", None)
    if callable(heartbeat):
        heartbeat()
    return is_cancel_requested(db, job.id)


def _dataset(payload: dict[str, Any]) -> CeriDataset:
    value = payload.get("dataset")
    if value is None:
        raise ValueError(f"{CERI_PROVIDER_INGEST} job payload is missing dataset.")
    try:
        return CeriDataset(str(value))
    except ValueError as exc:
        raise ValueError(f"Unsupported CERI dataset: {value}") from exc


def _required_text(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if not value:
        raise ValueError(f"{CERI_PROVIDER_INGEST} job payload is missing {key}.")
    return str(value)


def _required_int(payload: dict[str, Any], key: str) -> int:
    value = payload.get(key)
    if value in (None, ""):
        raise ValueError(f"job payload is missing {key}.")
    return int(value)


def _optional_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    return int(value)


def _optional_int_tuple(value: Any) -> tuple[int, ...] | None:
    if value in (None, ""):
        return None
    if isinstance(value, (str, int)):
        value = [value]
    return tuple(int(item) for item in value if str(item).strip())


def _optional_datetime(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(str(value).replace("Z", "+00:00"))


def _optional_date(value: Any) -> date | None:
    if value in (None, ""):
        return None
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value)[:10])


def _maybe_scalar(db: Session, statement):
    scalar = getattr(db, "scalar", None)
    if callable(scalar):
        return scalar(statement)
    return None


def _utcnow() -> datetime:
    return datetime.now(UTC)
