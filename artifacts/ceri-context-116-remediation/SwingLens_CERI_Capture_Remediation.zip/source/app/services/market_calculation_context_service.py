from __future__ import annotations

import logging
from datetime import UTC, date, datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.tables import (
    BackgroundJob,
    ExecutionConfigurationBinding,
    MarketCalculationContext,
    PipelineRun,
    PipelineStep,
)
from app.observability.transaction_metrics import publish_after_commit
from app.services.calculation_identity import (
    PIPELINE_CONTEXT_COMPATIBILITY,
    AlgorithmIdentity,
    CalculationContextIdentity,
    CalculationIdentity,
    CalculationIdentityCompatibilityValidator,
    CalculationOwnership,
    CalculationSubject,
    CalendarIdentity,
    ConfigurationIdentity,
    DigestIdentity,
    GenerationIdentity,
    IdentityDimension,
    TemporalIdentity,
    VersionIdentity,
)
from app.services.canonical_evidence import CanonicalEvidenceSerializer
from app.services.market_clock_service import (
    EXCHANGE_TIMEZONE,
    MarketCalculationCutoff,
    MarketClockService,
    require_current_execution_calendar,
)

logger = logging.getLogger(__name__)
_DERIVE_CONTEXT_FINGERPRINT = object()


class PipelineCalculationContextError(ValueError):
    """A pipeline-owned operation cannot prove its frozen market context."""


class CeriContextIntegrityError(PipelineCalculationContextError):
    """A durable CERI work item cannot prove its post-acquisition authority."""

    def __init__(
        self,
        code: str,
        message: str,
        *,
        diagnostics: dict[str, object] | None = None,
    ) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code
        self.diagnostics = dict(diagnostics or {})


_CERI_CONTEXT_RESULT_KEYS = frozenset(
    {
        "ceri_calculation_context_id",
        "ceri_calculation_cutoff_at",
        "ceri_calculation_as_of_session",
        "ceri_calculation_calendar_version",
        "ceri_calculation_bar_readiness_version",
        "ceri_calculation_context_reason",
    }
)


def create_pipeline_market_context(
    db: Session,
    pipeline: PipelineRun,
    *,
    cutoff_at: datetime | None = None,
    clock: MarketClockService | None = None,
    reason: str = "FULL_PIPELINE_FROZEN_AT_ENQUEUE",
) -> MarketCalculationCutoff:
    existing = pipeline.market_calculation_context
    if existing is not None:
        return cutoff_from_row(existing)
    if isinstance(db, Session):
        from app.services.source_mutation_authority import _source_value

        with db.no_autoflush:
            _source_value(db, pipeline)
            bound = db.scalar(
                select(ExecutionConfigurationBinding.binding_key)
                .where(ExecutionConfigurationBinding.pipeline_run_id == pipeline.id)
                .limit(1)
            )
            delivered = db.scalar(
                select(BackgroundJob.id)
                .where(BackgroundJob.payload_json["pipeline_run_id"].as_integer() == pipeline.id)
                .limit(1)
            )
            advanced = db.scalar(
                select(PipelineStep.id)
                .where(
                    PipelineStep.pipeline_run_id == pipeline.id,
                    PipelineStep.status.not_in(("PENDING", "QUEUED")),
                )
                .limit(1)
            )
        if bound is not None or delivered is not None or advanced is not None:
            db.rollback()
            raise PipelineCalculationContextError(
                "PIPELINE_FROZEN_CONTEXT_REQUIRED: authority creation is limited to "
                "a new undelivered calculation; existing delivery cannot be repaired "
                "with a new current cutoff."
            )
    cutoff = (clock or MarketClockService()).cutoff_for(
        cutoff_at or datetime.now(UTC), reason=reason
    )
    row = MarketCalculationContext(
        pipeline_run_id=pipeline.id,
        upload_run_id=pipeline.upload_run_id,
        cutoff_at=cutoff.cutoff_at,
        exchange_timezone=cutoff.exchange_timezone,
        latest_completed_session=cutoff.latest_completed_session,
        daily_bar_ready_at=cutoff.daily_bar_ready_at,
        calendar_version=cutoff.calendar_version,
        bar_readiness_version=cutoff.bar_readiness_version,
        cutoff_reason=cutoff.cutoff_reason,
    )
    db.add(row)
    db.flush()
    if isinstance(db, Session):
        publish_after_commit(
            db,
            "increment",
            "swinglens_market_calculation_cutoffs_total",
            scope="pipeline",
        )
    return cutoff.with_context_id(row.id)


def reserve_preflight_market_context(
    db: Session,
    *,
    upload_run_id: int,
    cutoff_at: datetime | None = None,
    clock: MarketClockService | None = None,
) -> MarketCalculationCutoff:
    """Persist an unowned immutable context for a durable transition preflight."""

    cutoff = (clock or MarketClockService()).cutoff_for(
        cutoff_at or datetime.now(UTC), reason="TRANSITION_PREFLIGHT_RESERVED"
    )
    row = MarketCalculationContext(
        pipeline_run_id=None,
        upload_run_id=upload_run_id,
        cutoff_at=cutoff.cutoff_at,
        exchange_timezone=cutoff.exchange_timezone,
        latest_completed_session=cutoff.latest_completed_session,
        daily_bar_ready_at=cutoff.daily_bar_ready_at,
        calendar_version=cutoff.calendar_version,
        bar_readiness_version=cutoff.bar_readiness_version,
        cutoff_reason=cutoff.cutoff_reason,
    )
    db.add(row)
    db.flush()
    return cutoff.with_context_id(row.id)


def attach_reserved_market_context(
    db: Session,
    pipeline: PipelineRun,
    *,
    context_id: int,
) -> MarketCalculationCutoff:
    """Atomically transfer one reserved context to its eventual pipeline."""

    row = db.scalar(
        select(MarketCalculationContext)
        .where(MarketCalculationContext.id == context_id)
        .with_for_update()
    )
    if row is None:
        raise PipelineCalculationContextError(
            f"Reserved market calculation context {context_id} was not found."
        )
    if row.upload_run_id != pipeline.upload_run_id:
        raise PipelineCalculationContextError(
            f"Reserved context {context_id} belongs to upload run {row.upload_run_id}, "
            f"not {pipeline.upload_run_id}."
        )
    if row.pipeline_run_id not in {None, pipeline.id}:
        raise PipelineCalculationContextError(
            f"Reserved context {context_id} is already owned by pipeline {row.pipeline_run_id}."
        )
    existing_context_id = db.scalar(
        select(MarketCalculationContext.id).where(
            MarketCalculationContext.pipeline_run_id == pipeline.id
        )
    )
    if existing_context_id not in {None, row.id}:
        raise PipelineCalculationContextError(
            f"Pipeline {pipeline.id} already owns context {existing_context_id}."
        )
    row.pipeline_run_id = pipeline.id
    db.flush()
    return cutoff_from_row(row)


def market_context_for_pipeline(db: Session, pipeline: PipelineRun) -> MarketCalculationCutoff:
    if not isinstance(db, Session):
        return standalone_market_context(reason="PIPELINE_TEST_SESSION_COMPATIBILITY")
    row = db.scalar(
        select(MarketCalculationContext).where(
            MarketCalculationContext.pipeline_run_id == pipeline.id
        )
    )
    if row is None:
        raise PipelineCalculationContextError(
            "PIPELINE_FROZEN_CONTEXT_REQUIRED: existing pipeline has no retained context; "
            "start a new calculation instead of reconstructing authority at execution."
        )
    cutoff = cutoff_from_row(row)
    _require_execution_calendar(cutoff)
    return cutoff


def create_or_get_pipeline_ceri_context(
    db: Session,
    *,
    pipeline_run_id: int,
    clock: MarketClockService | None = None,
) -> MarketCalculationCutoff:
    """Freeze the CERI context after provider acquisition and normalization.

    A pipeline's market context remains immutable.  CERI provider observations
    acquired later receive a separate explicitly-authorized context, retained
    on the pipeline before any feature or capture side effect.  This preserves
    both identities instead of moving the original cutoff forward.
    """

    pipeline = db.scalar(
        select(PipelineRun)
        .where(PipelineRun.id == int(pipeline_run_id))
        .with_for_update()
        .execution_options(populate_existing=True)
    )
    if pipeline is None:
        raise PipelineCalculationContextError(
            f"Pipeline {pipeline_run_id} was not found for CERI context freeze."
        )
    retained = dict(pipeline.result_json or {})
    existing_id = retained.get("ceri_calculation_context_id")
    if existing_id is not None:
        return resolve_pipeline_ceri_context(
            db,
            calculation_context_id=int(existing_id),
            upload_run_id=int(pipeline.upload_run_id),
            pipeline_run_id=int(pipeline.id),
        )

    from app.services.pipeline_state_machine import TERMINAL_PIPELINE_STATES

    if pipeline.status in TERMINAL_PIPELINE_STATES or pipeline.status == "CANCEL_REQUESTED":
        raise PipelineCalculationContextError(
            f"CERI_CONTEXT_PARENT_NOT_ACTIVE:pipeline={pipeline.id}:status={pipeline.status}"
        )
    cutoff = (clock or MarketClockService()).cutoff_for(
        datetime.now(UTC), reason="CERI_POST_ACQUISITION_FROZEN"
    )
    row = MarketCalculationContext(
        pipeline_run_id=None,
        upload_run_id=pipeline.upload_run_id,
        cutoff_at=cutoff.cutoff_at,
        exchange_timezone=cutoff.exchange_timezone,
        latest_completed_session=cutoff.latest_completed_session,
        daily_bar_ready_at=cutoff.daily_bar_ready_at,
        calendar_version=cutoff.calendar_version,
        bar_readiness_version=cutoff.bar_readiness_version,
        cutoff_reason=cutoff.cutoff_reason,
    )
    db.add(row)
    db.flush()
    pipeline.result_json = {
        **retained,
        "ceri_calculation_context_id": row.id,
        "ceri_calculation_cutoff_at": CanonicalEvidenceSerializer.canonicalize(cutoff.cutoff_at),
        "ceri_calculation_as_of_session": cutoff.latest_completed_session.isoformat(),
        "ceri_calculation_calendar_version": cutoff.calendar_version,
        "ceri_calculation_bar_readiness_version": cutoff.bar_readiness_version,
        "ceri_calculation_context_reason": cutoff.cutoff_reason,
    }
    db.flush()
    publish_after_commit(
        db,
        "increment",
        "swinglens_market_calculation_cutoffs_total",
        scope="pipeline_ceri_post_acquisition",
    )
    return cutoff.with_context_id(row.id)


def resolve_pipeline_ceri_context(
    db: Session,
    *,
    calculation_context_id: int | None,
    upload_run_id: int,
    pipeline_run_id: int,
    expected_cutoff_at: datetime | None = None,
    expected_latest_completed_session: date | None = None,
    expected_calendar_version: str | None = None,
) -> MarketCalculationCutoff:
    """Resolve the separate post-acquisition CERI context retained by a pipeline."""

    if calculation_context_id is None:
        raise PipelineCalculationContextError("Pipeline CERI context ID is required.")
    pipeline = db.get(PipelineRun, int(pipeline_run_id))
    if pipeline is None or int(pipeline.upload_run_id) != int(upload_run_id):
        raise PipelineCalculationContextError("Pipeline CERI context owner mismatch.")
    retained_id = (pipeline.result_json or {}).get("ceri_calculation_context_id")
    if int(retained_id or 0) != int(calculation_context_id):
        raise PipelineCalculationContextError(
            "Supplied CERI calculation context is not retained by the pipeline."
        )
    row = db.get(MarketCalculationContext, int(calculation_context_id))
    if row is None or row.pipeline_run_id is not None or row.upload_run_id != upload_run_id:
        raise PipelineCalculationContextError("Retained CERI calculation context is invalid.")
    cutoff = cutoff_from_row(row)
    if expected_cutoff_at is not None and cutoff.cutoff_at != expected_cutoff_at:
        raise PipelineCalculationContextError("CERI payload cutoff does not match its context.")
    if (
        expected_latest_completed_session is not None
        and cutoff.latest_completed_session != expected_latest_completed_session
    ):
        raise PipelineCalculationContextError("CERI payload session does not match its context.")
    if (
        expected_calendar_version is not None
        and cutoff.calendar_version != expected_calendar_version
    ):
        raise PipelineCalculationContextError("CERI payload calendar does not match its context.")
    _require_execution_calendar(cutoff)
    return cutoff


def freeze_or_validate_pipeline_ceri_authority(
    db: Session,
    *,
    job: BackgroundJob,
    payload: dict[str, object],
) -> dict[str, object]:
    """Atomically retain one post-acquisition context for every feature batch.

    The caller owns the commit boundary.  This function deliberately updates
    the context, pipeline authority, and every feature-work reference in the
    same SQLAlchemy transaction so a crash can expose all of them or none of
    them, never a durable JSON reference to an uncommitted context row.
    """

    from app.services.ceri.batched_workflow import CERI_FEATURE_BATCH

    pipeline_run_id = int(payload.get("pipeline_run_id") or 0)
    workflow_key = str(job.workflow_key or payload.get("workflow_key") or "")
    if pipeline_run_id <= 0 or not workflow_key.startswith("ceri:pipeline:"):
        return payload

    pipeline = db.scalar(
        select(PipelineRun)
        .where(PipelineRun.id == pipeline_run_id)
        .with_for_update()
        .execution_options(populate_existing=True)
    )
    if pipeline is None:
        raise CeriContextIntegrityError(
            "CERI_CONTEXT_OWNER_MISMATCH",
            f"pipeline {pipeline_run_id} was not found",
            diagnostics={"pipeline_run_id": pipeline_run_id, "job_id": job.id},
        )
    if int(job.related_run_id or 0) != int(pipeline.upload_run_id):
        raise CeriContextIntegrityError(
            "CERI_CONTEXT_OWNER_MISMATCH",
            "feature job upload run does not match its pipeline",
            diagnostics={
                "pipeline_run_id": pipeline_run_id,
                "upload_run_id": pipeline.upload_run_id,
                "job_id": job.id,
                "job_upload_run_id": job.related_run_id,
            },
        )

    feature_jobs = list(
        db.scalars(
            select(BackgroundJob)
            .where(
                BackgroundJob.workflow_key == workflow_key,
                BackgroundJob.job_type == CERI_FEATURE_BATCH,
            )
            .order_by(BackgroundJob.id)
            .with_for_update()
        )
    )
    if job.job_type == CERI_FEATURE_BATCH and all(row.id != job.id for row in feature_jobs):
        feature_jobs.append(job)

    retained = dict(pipeline.result_json or {})
    retained_id = _optional_positive_int(retained.get("ceri_calculation_context_id"))
    payload_id = _optional_positive_int(payload.get("calculation_context_id"))
    authority: MarketCalculationCutoff | None = None

    if retained_id is not None:
        authority = _resolve_ceri_authority_or_none(
            db,
            pipeline=pipeline,
            calculation_context_id=retained_id,
        )
        if authority is None:
            artifacts = _ceri_context_artifacts(
                db,
                calculation_context_id=retained_id,
                feature_job_ids=[row.id for row in feature_jobs if row.id is not None],
            )
            if artifacts:
                raise _dangling_ceri_context_error(
                    job=job,
                    pipeline=pipeline,
                    calculation_context_id=retained_id,
                    artifacts=artifacts,
                )
            pipeline.result_json = {
                key: value
                for key, value in retained.items()
                if key not in _CERI_CONTEXT_RESULT_KEYS
            }
            db.flush()
            retained_id = None

    if payload_id is not None and authority is None:
        authority = _resolve_ceri_authority_or_none(
            db,
            pipeline=pipeline,
            calculation_context_id=payload_id,
            payload=payload,
        )
        if authority is None:
            artifacts = _ceri_context_artifacts(
                db,
                calculation_context_id=payload_id,
                feature_job_ids=[job.id] if job.id is not None else [],
            )
            if artifacts:
                raise _dangling_ceri_context_error(
                    job=job,
                    pipeline=pipeline,
                    calculation_context_id=payload_id,
                    artifacts=artifacts,
                )

    if authority is None:
        authority = create_or_get_pipeline_ceri_context(db, pipeline_run_id=pipeline.id)

    authoritative_id = int(authority.context_id or 0)
    if authoritative_id <= 0:
        raise CeriContextIntegrityError(
            "CERI_CONTEXT_AUTHORITY_REQUIRED",
            "post-acquisition context has no durable identity",
            diagnostics={"pipeline_run_id": pipeline.id, "job_id": job.id},
        )

    all_jobs = [*feature_jobs]
    if all(row.id != job.id for row in all_jobs):
        all_jobs.append(job)
    scope_identity = _ceri_scope_identity(payload, job)
    frozen_for_current: dict[str, object] | None = None
    for row in all_jobs:
        row_payload = dict(row.payload_json or {})
        _validate_ceri_scope_identity(
            expected=scope_identity,
            observed=_ceri_scope_identity(row_payload, row),
            pipeline_run_id=pipeline.id,
            job_id=row.id,
        )
        row_context_id = _optional_positive_int(row_payload.get("calculation_context_id"))
        if row_context_id is not None and row_context_id != authoritative_id:
            artifacts = _ceri_context_artifacts(
                db,
                calculation_context_id=row_context_id,
                feature_job_ids=[row.id] if row.id is not None else [],
            )
            if artifacts or db.get(MarketCalculationContext, row_context_id) is not None:
                raise CeriContextIntegrityError(
                    "CERI_CONTEXT_COMPETING_AUTHORITY",
                    "feature batches for one workflow reference different authorities",
                    diagnostics={
                        "pipeline_run_id": pipeline.id,
                        "job_id": row.id,
                        "feature_batch": row_payload.get("batch_index"),
                        "calculation_context_id": row_context_id,
                        "authoritative_context_id": authoritative_id,
                        "artifacts": artifacts,
                    },
                )
        frozen = {
            **row_payload,
            "calculation_context_id": authoritative_id,
            "cutoff_at": authority.cutoff_at.isoformat(),
            "as_of_session": authority.latest_completed_session.isoformat(),
            "calendar_version": authority.calendar_version,
        }
        row.payload_json = frozen
        if row.id == job.id:
            frozen_for_current = frozen

    if frozen_for_current is None:
        frozen_for_current = {
            **payload,
            "calculation_context_id": authoritative_id,
            "cutoff_at": authority.cutoff_at.isoformat(),
            "as_of_session": authority.latest_completed_session.isoformat(),
            "calendar_version": authority.calendar_version,
        }
        job.payload_json = frozen_for_current
    db.flush()
    return frozen_for_current


def _resolve_ceri_authority_or_none(
    db: Session,
    *,
    pipeline: PipelineRun,
    calculation_context_id: int,
    payload: dict[str, object] | None = None,
) -> MarketCalculationCutoff | None:
    row = db.get(MarketCalculationContext, calculation_context_id)
    if row is None:
        return None
    retained_id = _optional_positive_int(
        (pipeline.result_json or {}).get("ceri_calculation_context_id")
    )
    if retained_id is None:
        # A context row without the pipeline's retained authority is not enough
        # to authorize a retry; silently adopting it would rewrite lineage.
        return None
    try:
        return resolve_pipeline_ceri_context(
            db,
            calculation_context_id=calculation_context_id,
            upload_run_id=int(pipeline.upload_run_id),
            pipeline_run_id=int(pipeline.id),
            expected_cutoff_at=(
                _optional_datetime(payload.get("cutoff_at")) if payload is not None else None
            ),
            expected_latest_completed_session=(
                _optional_date(payload.get("as_of_session")) if payload is not None else None
            ),
            expected_calendar_version=(
                str(payload.get("calendar_version"))
                if payload is not None and payload.get("calendar_version") not in (None, "")
                else None
            ),
        )
    except PipelineCalculationContextError as exc:
        raise CeriContextIntegrityError(
            "CERI_CONTEXT_IDENTITY_MISMATCH",
            str(exc),
            diagnostics={
                "pipeline_run_id": pipeline.id,
                "upload_run_id": pipeline.upload_run_id,
                "calculation_context_id": calculation_context_id,
            },
        ) from exc


def _ceri_context_artifacts(
    db: Session,
    *,
    calculation_context_id: int,
    feature_job_ids: list[int],
) -> dict[str, int]:
    from app.models.ceri_tables import (
        CeriDerivedFeature,
        CeriFeatureBuildState,
        CeriFeatureSourceManifest,
        CeriPriceResponseFeature,
        CeriRevisionFeature,
        CeriScoreSnapshot,
    )

    models = (
        CeriFeatureSourceManifest,
        CeriFeatureBuildState,
        CeriRevisionFeature,
        CeriPriceResponseFeature,
        CeriDerivedFeature,
        CeriScoreSnapshot,
    )
    found: dict[str, int] = {}
    for model in models:
        artifact_id = db.scalar(
            select(model.id).where(model.calculation_context_id == calculation_context_id).limit(1)
        )
        if artifact_id is not None:
            found[model.__tablename__] = int(artifact_id)
    if feature_job_ids:
        manifest_id = db.scalar(
            select(CeriFeatureSourceManifest.id)
            .where(CeriFeatureSourceManifest.background_job_id.in_(feature_job_ids))
            .limit(1)
        )
        if manifest_id is not None:
            found.setdefault(CeriFeatureSourceManifest.__tablename__, int(manifest_id))
    return found


def _dangling_ceri_context_error(
    *,
    job: BackgroundJob,
    pipeline: PipelineRun,
    calculation_context_id: int,
    artifacts: dict[str, int],
) -> CeriContextIntegrityError:
    return CeriContextIntegrityError(
        "CERI_CONTEXT_DANGLING",
        "durable feature authority references a missing calculation context",
        diagnostics={
            "job_id": job.id,
            "feature_batch": (job.payload_json or {}).get("batch_index"),
            "calculation_context_id": calculation_context_id,
            "pipeline_run_id": pipeline.id,
            "upload_run_id": pipeline.upload_run_id,
            "artifacts": artifacts,
        },
    )


def _ceri_scope_identity(payload: dict[str, object], job: BackgroundJob) -> dict[str, str | None]:
    return {
        "workflow_key": _optional_text(job.workflow_key or payload.get("workflow_key")),
        "pipeline_run_id": _optional_text(payload.get("pipeline_run_id")),
        "upload_run_id": _optional_text(payload.get("run_id") or job.related_run_id),
        "scope_id": _optional_text(payload.get("scope_id") or job.scope_id),
        "refresh_cycle_id": _optional_text(payload.get("refresh_cycle_id") or job.refresh_cycle_id),
        "acquisition_plan_id": _optional_text(
            payload.get("acquisition_plan_id") or job.acquisition_plan_id
        ),
    }


def _validate_ceri_scope_identity(
    *,
    expected: dict[str, str | None],
    observed: dict[str, str | None],
    pipeline_run_id: int,
    job_id: int | None,
) -> None:
    mismatched = {
        key: {"expected": expected[key], "observed": observed[key]}
        for key in expected
        if expected[key] != observed[key]
    }
    if mismatched:
        raise CeriContextIntegrityError(
            "CERI_CONTEXT_SCOPE_MISMATCH",
            "feature batches for one workflow do not share semantic scope",
            diagnostics={
                "pipeline_run_id": pipeline_run_id,
                "job_id": job_id,
                "mismatched_scope": mismatched,
            },
        )


def _optional_positive_int(value: object) -> int | None:
    try:
        parsed = int(value) if value not in (None, "") else 0
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def _optional_datetime(value: object) -> datetime | None:
    if value in (None, ""):
        return None
    parsed = value if isinstance(value, datetime) else datetime.fromisoformat(str(value))
    return parsed.replace(tzinfo=UTC) if parsed.tzinfo is None else parsed


def _optional_date(value: object) -> date | None:
    if value in (None, ""):
        return None
    return (
        value
        if isinstance(value, date) and not isinstance(value, datetime)
        else date.fromisoformat(str(value))
    )


def _optional_text(value: object) -> str | None:
    return str(value) if value not in (None, "") else None


def market_context_for_upload_run(
    db: Session, upload_run_id: int
) -> MarketCalculationCutoff | None:
    # Some pure calculation callers use the intentionally narrow session
    # protocol (execute/add/flush) and cannot perform ORM scalar lookups.  Such
    # callers receive an explicit standalone cutoff from their owning service.
    if not isinstance(db, Session):
        return None
    row = db.scalar(
        select(MarketCalculationContext)
        .where(
            MarketCalculationContext.upload_run_id == upload_run_id,
            MarketCalculationContext.pipeline_run_id.is_not(None),
        )
        .order_by(MarketCalculationContext.id.desc())
        .limit(1)
    )
    return cutoff_from_row(row) if row is not None else None


def resolve_pipeline_market_context(
    db: Session,
    *,
    calculation_context_id: int | None,
    upload_run_id: int,
    pipeline_run_id: int | None = None,
    expected_cutoff_at: datetime | None = None,
    expected_latest_completed_session: date | None = None,
    expected_calendar_version: str | None = None,
) -> MarketCalculationCutoff:
    """Resolve and validate the authoritative context for pipeline-owned work.

    Durable jobs may repeat cutoff/session fields for auditability, but the
    persisted context ID remains authoritative.  A missing or inconsistent
    identity fails closed instead of deriving a replacement from wall time.
    """

    if calculation_context_id is None:
        raise PipelineCalculationContextError(
            "Pipeline-owned operation is missing calculation_context_id."
        )
    from app.services.source_mutation_authority import prefetched_source_rows

    prefetched = prefetched_source_rows(db, MarketCalculationContext, [int(calculation_context_id)])
    row = (
        prefetched[0]
        if prefetched is not None
        else db.get(MarketCalculationContext, int(calculation_context_id))
    )
    if row is None:
        raise PipelineCalculationContextError(
            f"Market calculation context {calculation_context_id} was not found."
        )
    if row.pipeline_run_id is None:
        raise PipelineCalculationContextError(
            f"Market calculation context {row.id} is not owned by a pipeline."
        )
    if pipeline_run_id is not None and row.pipeline_run_id != pipeline_run_id:
        raise PipelineCalculationContextError(
            f"Market calculation context {row.id} belongs to pipeline "
            f"{row.pipeline_run_id}, not pipeline {pipeline_run_id}."
        )
    if row.upload_run_id != upload_run_id:
        raise PipelineCalculationContextError(
            f"Market calculation context {row.id} belongs to upload run "
            f"{row.upload_run_id}, not upload run {upload_run_id}."
        )
    prefetched_pipeline = prefetched_source_rows(db, PipelineRun, [row.pipeline_run_id])
    pipeline = (
        prefetched_pipeline[0]
        if prefetched_pipeline is not None
        else db.get(PipelineRun, row.pipeline_run_id)
    )
    if pipeline is None or pipeline.upload_run_id != upload_run_id:
        raise PipelineCalculationContextError(
            f"Pipeline {row.pipeline_run_id} does not own upload run {upload_run_id}."
        )
    authoritative_id = (
        row.id
        if prefetched is not None
        # pipeline_run_id is UNIQUE. The exact locked row and native owner
        # checks above prove the same membership as the scalar lookup.
        else db.scalar(
            select(MarketCalculationContext.id).where(
                MarketCalculationContext.pipeline_run_id == row.pipeline_run_id
            )
        )
    )
    if authoritative_id != row.id:
        raise PipelineCalculationContextError(
            f"Market calculation context {row.id} is not pipeline "
            f"{row.pipeline_run_id}'s authoritative context."
        )

    cutoff = cutoff_from_row(row)
    if expected_cutoff_at is not None and cutoff.cutoff_at != expected_cutoff_at:
        raise PipelineCalculationContextError(
            f"Payload cutoff_at does not match market calculation context {row.id}."
        )
    if (
        expected_latest_completed_session is not None
        and cutoff.latest_completed_session != expected_latest_completed_session
    ):
        raise PipelineCalculationContextError(
            f"Payload as_of_session does not match market calculation context {row.id}."
        )
    if (
        expected_calendar_version is not None
        and cutoff.calendar_version != expected_calendar_version
    ):
        raise PipelineCalculationContextError(
            f"Payload calendar_version does not match market calculation context {row.id}."
        )
    return cutoff


def assert_pipeline_calculation_context(
    db: Session,
    *,
    pipeline_run_id: int,
    upload_run_id: int,
    supplied_context: MarketCalculationCutoff | None,
    context_role: str = "MAIN",
) -> MarketCalculationCutoff:
    if context_role not in {"MAIN", "CERI"}:
        raise PipelineCalculationContextError("Unknown pipeline calculation context role.")
    if supplied_context is None:
        raise PipelineCalculationContextError(
            "Pipeline-owned operation is missing its frozen market calculation context."
        )
    dedicated_ceri = (
        context_role == "CERI" and supplied_context.cutoff_reason == "CERI_POST_ACQUISITION_FROZEN"
    )
    resolver = resolve_pipeline_ceri_context if dedicated_ceri else resolve_pipeline_market_context
    authoritative = resolver(
        db,
        calculation_context_id=supplied_context.context_id,
        upload_run_id=upload_run_id,
        pipeline_run_id=pipeline_run_id,
        expected_cutoff_at=supplied_context.cutoff_at,
        expected_latest_completed_session=supplied_context.latest_completed_session,
        expected_calendar_version=supplied_context.calendar_version,
    )
    if dedicated_ceri:
        from app.services.ceri.score_ownership import bound_pipeline_id

        if (
            db.scalar(select(bound_pipeline_id(upload_run_id, supplied_context.context_id)))
            != pipeline_run_id
        ):
            raise PipelineCalculationContextError("Dedicated CERI context owner binding mismatch.")
    if (
        supplied_context.exchange_timezone != authoritative.exchange_timezone
        or supplied_context.daily_bar_ready_at != authoritative.daily_bar_ready_at
        or supplied_context.bar_readiness_version != authoritative.bar_readiness_version
    ):
        raise PipelineCalculationContextError(
            "Supplied market calculation context does not match the persisted pipeline context."
        )
    return authoritative


def validate_pipeline_job_market_context(
    db: Session,
    *,
    pipeline_run_id: int,
    payload: dict,
) -> MarketCalculationCutoff:
    """Fail closed when a durable job repeats a different frozen boundary."""

    pipeline = db.get(PipelineRun, pipeline_run_id)
    if pipeline is None:
        raise PipelineCalculationContextError(f"Pipeline {pipeline_run_id} was not found.")
    context_id = payload.get("market_calculation_context_id")
    cutoff_text = payload.get("market_cutoff_at")
    session_text = payload.get("input_as_of_session")
    calendar_version = payload.get("market_calendar_version")
    bar_readiness_version = payload.get("bar_readiness_version")
    if not all(
        value is not None
        for value in (
            context_id,
            cutoff_text,
            session_text,
            calendar_version,
            bar_readiness_version,
        )
    ):
        raise PipelineCalculationContextError(
            "FULL_PIPELINE job payload is missing its frozen market context envelope."
        )
    authoritative = resolve_pipeline_market_context(
        db,
        calculation_context_id=int(context_id),
        upload_run_id=pipeline.upload_run_id,
        pipeline_run_id=pipeline_run_id,
    )
    try:
        supplied = MarketCalculationCutoff(
            cutoff_at=datetime.fromisoformat(str(cutoff_text)),
            exchange_timezone=EXCHANGE_TIMEZONE,
            latest_completed_session=date.fromisoformat(str(session_text)),
            daily_bar_ready_at=None,
            calendar_version=str(calendar_version),
            bar_readiness_version=str(bar_readiness_version),
            cutoff_reason="FULL_PIPELINE_JOB_PAYLOAD",
            context_id=int(context_id),
        )
    except (TypeError, ValueError) as exc:
        raise PipelineCalculationContextError(
            f"FULL_PIPELINE job payload has an invalid market context: {exc}"
        ) from exc
    expected_identity = calculation_identity_from_market_context(
        authoritative,
        run_id=int(pipeline.upload_run_id),
        pipeline_id=int(pipeline_run_id),
    )
    actual_identity = calculation_identity_from_market_context(
        supplied,
        run_id=int(pipeline.upload_run_id),
        pipeline_id=int(pipeline_run_id),
        context_fingerprint=None,
    )
    compatibility = CalculationIdentityCompatibilityValidator.compare(
        expected_identity,
        actual_identity,
        policy=PIPELINE_CONTEXT_COMPATIBILITY,
    )
    logger.info(
        "pipeline calculation identity compatibility",
        extra={
            "calculation_identity_fingerprint": compatibility.actual_fingerprint,
            "calculation_identity_expected_fingerprint": compatibility.expected_fingerprint,
            "calculation_identity_policy": compatibility.policy,
            "calculation_identity_result": compatibility.status.value,
        },
    )
    if not compatibility.accepted:
        raise PipelineCalculationContextError(compatibility.diagnostic())
    _require_execution_calendar(authoritative)
    return authoritative


def _require_execution_calendar(cutoff: MarketCalculationCutoff) -> None:
    try:
        require_current_execution_calendar(cutoff)
    except ValueError as exc:
        raise PipelineCalculationContextError(str(exc)) from exc


def standalone_market_context(
    *, reason: str, cutoff_at: datetime | None = None
) -> MarketCalculationCutoff:
    return MarketClockService().cutoff_for(cutoff_at or datetime.now(UTC), reason=reason)


def prospective_pipeline_market_context(
    *, cutoff_at: datetime | None = None, clock: MarketClockService | None = None
) -> MarketCalculationCutoff:
    """Build, but do not persist, the context a pipeline enqueued now would freeze."""

    return (clock or MarketClockService()).cutoff_for(
        cutoff_at or datetime.now(UTC),
        reason="FULL_PIPELINE_FROZEN_AT_ENQUEUE",
    )


def cutoff_from_row(row: MarketCalculationContext) -> MarketCalculationCutoff:
    return MarketCalculationCutoff(
        cutoff_at=row.cutoff_at,
        exchange_timezone=row.exchange_timezone,
        latest_completed_session=row.latest_completed_session,
        daily_bar_ready_at=row.daily_bar_ready_at,
        calendar_version=row.calendar_version,
        bar_readiness_version=row.bar_readiness_version,
        cutoff_reason=row.cutoff_reason,
        context_id=row.id,
    )


def market_calculation_context_fingerprint(value: MarketCalculationCutoff) -> str:
    """Hash every persisted semantic field of a frozen market context."""

    return CanonicalEvidenceSerializer.fingerprint(
        {
            "context_id": value.context_id,
            "cutoff_at": value.cutoff_at,
            "exchange_timezone": value.exchange_timezone,
            "latest_completed_session": value.latest_completed_session,
            "daily_bar_ready_at": value.daily_bar_ready_at,
            "calendar_version": value.calendar_version,
            "bar_readiness_version": value.bar_readiness_version,
            "cutoff_reason": value.cutoff_reason,
        }
    )


def calculation_identity_from_market_context(
    value: MarketCalculationCutoff,
    *,
    run_id: int,
    pipeline_id: int,
    ticker: str | None = None,
    company_id: int | None = None,
    context_fingerprint: str | None | object = _DERIVE_CONTEXT_FINGERPRINT,
) -> CalculationIdentity:
    """Build a semantic identity from an explicit frozen market context.

    This adapter never consults current time or a latest context. Dimensions not
    established by MarketCalculationContext are marked NOT_APPLICABLE rather than
    fabricated. Passing ``context_fingerprint=None`` represents a payload that only
    carries the context ID and repeated temporal fields.
    """

    not_applicable = IdentityDimension.not_applicable()
    fingerprint = (
        market_calculation_context_fingerprint(value)
        if context_fingerprint is _DERIVE_CONTEXT_FINGERPRINT
        else context_fingerprint
    )
    return CalculationIdentity(
        ownership=CalculationOwnership(
            run_id=IdentityDimension.known(run_id),
            pipeline_id=IdentityDimension.known(pipeline_id),
        ),
        subject=CalculationSubject(
            ticker=(
                IdentityDimension.known(ticker.upper()) if ticker is not None else not_applicable
            ),
            company_id=(
                IdentityDimension.known(company_id) if company_id is not None else not_applicable
            ),
        ),
        calculation_context=CalculationContextIdentity(
            market_calculation_context_id=(
                IdentityDimension.known(value.context_id)
                if value.context_id is not None
                else IdentityDimension.unknown()
            ),
            context_fingerprint=(
                IdentityDimension.known(
                    DigestIdentity(
                        algorithm="sha256",
                        digest=str(fingerprint),
                        proof_boundary="complete persisted MarketCalculationContext semantics",
                    )
                )
                if fingerprint is not None
                else IdentityDimension.unknown()
            ),
        ),
        temporal=TemporalIdentity(
            as_of_session=IdentityDimension.known(value.latest_completed_session),
            calculation_cutoff=IdentityDimension.known(value.cutoff_at),
            calendar=IdentityDimension.known(
                CalendarIdentity(
                    calendar_id="SWINGLENS_US_EQUITIES",
                    calendar_version=value.calendar_version,
                    exchange_timezone=value.exchange_timezone,
                    bar_readiness_version=IdentityDimension.known(
                        VersionIdentity(
                            namespace="market-bar-readiness",
                            version=value.bar_readiness_version,
                        )
                    ),
                )
            ),
        ),
        configuration=ConfigurationIdentity(not_applicable),
        algorithm=AlgorithmIdentity(
            not_applicable,
            not_applicable,
            not_applicable,
            not_applicable,
            not_applicable,
        ),
        source_lineage=not_applicable,
        generation=GenerationIdentity(
            not_applicable,
            not_applicable,
            not_applicable,
            not_applicable,
        ),
    )
