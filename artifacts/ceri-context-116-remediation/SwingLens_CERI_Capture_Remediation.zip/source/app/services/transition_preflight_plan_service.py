from __future__ import annotations

import logging
from collections.abc import Mapping
from contextlib import nullcontext
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.ceri_tables import CeriScoreSnapshot
from app.models.tables import (
    MarketCalculationContext,
    MarketRegimeSnapshot,
    PipelineRun,
    RawCompanyRow,
    SectorRotationSnapshot,
    TechnicalScore,
    TransitionDecisionHandoffManifest,
    TransitionPreflightPlan,
    UploadRun,
)
from app.services.canonical_evidence import CanonicalEvidenceSerializer
from app.services.ceri.evidence_eligibility import eligible_snapshot_select
from app.services.ceri.score_population import source_lineage_failures
from app.services.decision_handoff_contract import (
    REQUIRED_HANDOFF_CONTEXT_ARTIFACTS,
    RequiredHandoffArtifactError,
    handoff_artifact_identity,
    validate_required_handoff_context_artifact,
)
from app.services.market_calculation_context_service import (
    attach_reserved_market_context,
    cutoff_from_row,
    reserve_preflight_market_context,
)
from app.services.market_clock_service import MarketCalculationCutoff
from app.services.price_bar_repository import invalid_price_bar_rows_for_context
from app.services.setup_lifecycle.decision_manifest import (
    build_transition_decision_manifest,
    candidate_type_for,
)
from app.services.setup_lifecycle.transition_candidate_service import (
    TransitionCandidateDiscoveryService,
    TransitionCandidateResult,
    _prospective_inputs_are_complete,
    _technical_reconstruction_fingerprint,
    aggregate_evidence_fingerprint,
)

DEFAULT_PREFLIGHT_TTL = timedelta(minutes=30)
RUN_START_ANCHOR_CONTRACT = "transition-run-start-anchor-v1"
DECISION_HANDOFF_CONTRACT = "transition-decision-handoff-v1"
logger = logging.getLogger(__name__)


class TransitionPreflightPlanStatus(StrEnum):
    RESERVED = "RESERVED"
    CONSUMED = "CONSUMED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"
    STALE = "STALE"


PREFLIGHT_STATE_TRANSITIONS = {
    (TransitionPreflightPlanStatus.RESERVED, "CONSUME"): TransitionPreflightPlanStatus.CONSUMED,
    (TransitionPreflightPlanStatus.RESERVED, "CANCEL"): TransitionPreflightPlanStatus.CANCELLED,
    (TransitionPreflightPlanStatus.RESERVED, "EXPIRE"): TransitionPreflightPlanStatus.EXPIRED,
    (TransitionPreflightPlanStatus.RESERVED, "INVALIDATE"): TransitionPreflightPlanStatus.STALE,
}


class TransitionPreflightError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code


def _combined_source_evidence_pins(evidence: Any) -> dict[str, int] | None:
    """Return canonical immutable source pins or reject a malformed envelope."""

    if evidence is None:
        return None
    raw_pins = getattr(evidence, "source_evidence_ids_json", None)
    if not isinstance(raw_pins, Mapping):
        raise TransitionPreflightError(
            "DECISION_LINEAGE_MISMATCH",
            "combined evidence source pins must be a mapping",
        )
    pins: dict[str, int] = {}
    for role, evidence_id in raw_pins.items():
        if (
            not isinstance(role, str)
            or not role.strip()
            or not isinstance(evidence_id, int)
            or isinstance(evidence_id, bool)
            or evidence_id <= 0
        ):
            raise TransitionPreflightError(
                "DECISION_LINEAGE_MISMATCH",
                "combined evidence source pins contain an invalid role or evidence ID",
            )
        pins[role] = evidence_id
    return pins


@dataclass(frozen=True)
class VerifiedTransitionPreflight:
    plan: TransitionPreflightPlan
    market_cutoff: MarketCalculationCutoff
    results: tuple[TransitionCandidateResult, ...]


def create_transition_preflight_plan(
    db: Session,
    *,
    upload_run_id: int,
    idempotency_key: str,
    tickers: set[str] | None = None,
    cutoff_at: datetime | None = None,
    expires_in: timedelta = DEFAULT_PREFLIGHT_TTL,
    discovery: TransitionCandidateDiscoveryService | None = None,
) -> TransitionPreflightPlan:
    """Freeze and persist a retryable preflight contract without business writes."""

    normalized_key = idempotency_key.strip()
    if not normalized_key:
        raise ValueError("idempotency_key is required")
    existing = db.scalar(
        select(TransitionPreflightPlan).where(
            TransitionPreflightPlan.idempotency_key == normalized_key
        )
    )
    if existing is not None:
        if existing.upload_run_id != upload_run_id:
            raise TransitionPreflightError(
                "IDEMPOTENCY_CONFLICT",
                "the idempotency key is already bound to a different upload run",
            )
        if tickers is not None and sorted(ticker.strip().upper() for ticker in tickers) != sorted(
            existing.tickers_json
        ):
            raise TransitionPreflightError(
                "IDEMPOTENCY_CONFLICT",
                "the idempotency key is already bound to a different ticker set",
            )
        if cutoff_at is not None:
            existing_context = db.get(
                MarketCalculationContext,
                existing.market_calculation_context_id,
            )
            if existing_context is None or existing_context.cutoff_at != _aware(cutoff_at):
                raise TransitionPreflightError(
                    "IDEMPOTENCY_CONFLICT",
                    "the idempotency key is already bound to a different cutoff instant",
                )
        return existing

    market_cutoff = reserve_preflight_market_context(
        db,
        upload_run_id=upload_run_id,
        cutoff_at=cutoff_at,
    )
    results = (discovery or TransitionCandidateDiscoveryService()).discover_for_run(
        db,
        upload_run_id,
        market_cutoff=market_cutoff,
        tickers=tickers,
    )
    evidence_fingerprint = aggregate_evidence_fingerprint(results)
    technical_fingerprint = _aggregate_technical_fingerprint(results)
    run_start_anchor = build_run_start_anchor_manifest(
        db,
        upload_run_id=upload_run_id,
        market_cutoff=market_cutoff,
        results=results,
    )
    run_start_anchor_fingerprint = CanonicalEvidenceSerializer.fingerprint(run_start_anchor)
    now = _utcnow()
    plan = TransitionPreflightPlan(
        market_calculation_context_id=market_cutoff.context_id,
        upload_run_id=upload_run_id,
        pipeline_run_id=None,
        status="RESERVED",
        idempotency_key=normalized_key,
        candidate_classification=_aggregate_classification(results),
        tickers_json=sorted(row.ticker for row in results),
        selection_keys_json=sorted(row.prospective_new_key for row in results),
        expected_pointers_json={
            row.ticker: {
                "latest_snapshot_id": row.current_pointer_snapshot_id,
                "latest_revision": row.expected_latest_pointer_revision,
                "exact_snapshot_id": row.expected_exact_pointer_snapshot_id,
                "exact_revision": row.expected_exact_pointer_revision,
            }
            for row in results
        },
        predicted_snapshot_identities_json={
            row.ticker: {
                "selection_key": row.prospective_new_key,
                "latest_reconstructable_session": CanonicalEvidenceSerializer.canonicalize(
                    row.latest_reconstructable_session
                ),
                "technical_reconstruction_fingerprint": (row.technical_reconstruction_fingerprint),
                "evidence_fingerprint": row.evidence_fingerprint,
            }
            for row in results
        },
        candidate_results_json=[_run_start_candidate_dict(row) for row in results],
        evidence_fingerprint=evidence_fingerprint,
        technical_reconstruction_fingerprint=technical_fingerprint,
        run_start_anchor_json=run_start_anchor,
        run_start_anchor_fingerprint=run_start_anchor_fingerprint,
        created_at=now,
        expires_at=now + expires_in,
    )
    db.add(plan)
    db.flush()
    return plan


def pipeline_for_consumed_preflight(db: Session, plan_id: int) -> PipelineRun | None:
    plan = db.get(TransitionPreflightPlan, plan_id)
    if plan is None or plan.status != "CONSUMED" or plan.pipeline_run_id is None:
        return None
    return db.get(PipelineRun, plan.pipeline_run_id)


def verify_transition_preflight_for_enqueue(
    db: Session,
    *,
    plan_id: int,
    upload_run_id: int,
    discovery: TransitionCandidateDiscoveryService | None = None,
    now: datetime | None = None,
) -> VerifiedTransitionPreflight:
    plan = db.scalar(
        select(TransitionPreflightPlan)
        .where(TransitionPreflightPlan.id == plan_id)
        .with_for_update()
    )
    if plan is None:
        raise TransitionPreflightError("STALE_PREFLIGHT", f"plan {plan_id} was not found")
    if plan.upload_run_id != upload_run_id:
        raise TransitionPreflightError("STALE_PREFLIGHT", "plan belongs to a different upload run")
    if plan.status == "CONSUMED":
        raise TransitionPreflightError("DUPLICATE_ENQUEUE", "plan already has a pipeline")
    if plan.status == "CANCELLED":
        raise TransitionPreflightError("PLAN_CANCELLED", "plan was cancelled")
    if plan.status == "EXPIRED":
        raise TransitionPreflightError("PLAN_EXPIRED", "plan has expired")
    if plan.status != "RESERVED":
        raise TransitionPreflightError("STALE_PREFLIGHT", f"plan status is {plan.status}")
    observed_at = now or _utcnow()
    if _aware(plan.expires_at) <= _aware(observed_at):
        raise TransitionPreflightError("PLAN_EXPIRED", "plan has expired")

    context_row = db.get(MarketCalculationContext, plan.market_calculation_context_id)
    if context_row is None or context_row.pipeline_run_id is not None:
        raise TransitionPreflightError(
            "CONTEXT_MISMATCH", "reserved market context is missing or already owned"
        )
    market_cutoff = cutoff_from_row(context_row)
    results = (discovery or TransitionCandidateDiscoveryService()).discover_for_run(
        db,
        upload_run_id,
        market_cutoff=market_cutoff,
        tickers=set(plan.tickers_json),
    )
    observed_selection_keys = sorted(row.prospective_new_key for row in results)
    if observed_selection_keys != sorted(plan.selection_keys_json):
        raise _rejection(
            plan,
            code="SELECTION_KEY_MISMATCH",
            category="selection_keys",
            message="candidate selection keys changed after preflight",
        )
    observed_pointers = {
        row.ticker: {
            "latest_snapshot_id": row.current_pointer_snapshot_id,
            "latest_revision": row.expected_latest_pointer_revision,
            "exact_snapshot_id": row.expected_exact_pointer_snapshot_id,
            "exact_revision": row.expected_exact_pointer_revision,
        }
        for row in results
    }
    if observed_pointers != plan.expected_pointers_json:
        raise _rejection(
            plan,
            code="PRECONDITION_CHANGED",
            category="canonical_pointer",
            message="canonical pointer state changed after preflight",
        )
    observed_evidence = aggregate_evidence_fingerprint(results)
    if observed_evidence != plan.evidence_fingerprint:
        raise _rejection(
            plan,
            code="PRECONDITION_CHANGED",
            category="pit_evidence",
            message="required PIT evidence changed after preflight",
            expected_fingerprint=plan.evidence_fingerprint,
            actual_fingerprint=observed_evidence,
        )
    observed_technical = _aggregate_technical_fingerprint(results)
    if observed_technical != plan.technical_reconstruction_fingerprint:
        raise _rejection(
            plan,
            code="PRECONDITION_CHANGED",
            category="technical_reconstruction",
            message="technical reconstruction changed after preflight",
            expected_fingerprint=plan.technical_reconstruction_fingerprint,
            actual_fingerprint=observed_technical,
        )
    if not plan.run_start_anchor_json or not plan.run_start_anchor_fingerprint:
        raise _rejection(
            plan,
            code="MALFORMED_DECISION_MANIFEST",
            category="run_start_anchor",
            message="preflight is missing its immutable run-start anchor",
        )
    observed_anchor = build_run_start_anchor_manifest(
        db,
        upload_run_id=upload_run_id,
        market_cutoff=market_cutoff,
        results=results,
    )
    observed_anchor_fingerprint = CanonicalEvidenceSerializer.fingerprint(observed_anchor)
    if (
        observed_anchor != plan.run_start_anchor_json
        or observed_anchor_fingerprint != plan.run_start_anchor_fingerprint
    ):
        raise _rejection(
            plan,
            code="DECISION_MANIFEST_MISMATCH",
            category="run_start_anchor",
            message="immutable run-start anchor changed after preflight",
            expected_fingerprint=plan.run_start_anchor_fingerprint,
            actual_fingerprint=observed_anchor_fingerprint,
        )
    if not results or not any(row.confidence == "HIGH" for row in results):
        candidate_diagnostics = [
            {
                "ticker": row.ticker,
                "confidence": row.confidence,
                "reason": row.reason,
                "latest_reconstructable_session": str(row.latest_reconstructable_session),
                "current_pointer_target_session": (
                    str(row.current_pointer_target_session)
                    if row.current_pointer_target_session is not None
                    else None
                ),
                "technical": dict((row.decision_manifest or {}).get("technical") or {}),
                "required_feature_coverage": dict(
                    (row.decision_manifest or {}).get("lifecycle_semantics") or {}
                ).get("required_feature_coverage"),
                "warning_flags": dict(
                    (row.decision_manifest or {}).get("lifecycle_semantics") or {}
                ).get("warning_flags"),
            }
            for row in results
        ]
        raise TransitionPreflightError(
            "STALE_PREFLIGHT",
            f"candidate set no longer contains a HIGH result; candidates={candidate_diagnostics}",
        )
    return VerifiedTransitionPreflight(plan, market_cutoff, tuple(results))


def verify_transition_decision_manifests_before_mutation(
    db: Session,
    *,
    upload_run_id: int,
    market_cutoff: MarketCalculationCutoff,
    built_rows,
    repository,
    checkpoint_callback=None,
) -> None:
    """Compare post-upstream artifacts with the persisted handoff contract."""

    plan = db.scalar(
        select(TransitionPreflightPlan).where(
            TransitionPreflightPlan.market_calculation_context_id == market_cutoff.context_id,
            TransitionPreflightPlan.upload_run_id == upload_run_id,
            TransitionPreflightPlan.status == "CONSUMED",
        )
    )
    if plan is None:
        return

    handoff = db.scalar(
        select(TransitionDecisionHandoffManifest).where(
            TransitionDecisionHandoffManifest.preflight_plan_id == plan.id
        )
    )
    if handoff is None:
        raise _rejection(
            plan,
            code="MALFORMED_DECISION_MANIFEST",
            category="decision_handoff",
            message="post-upstream decision handoff manifest was not persisted",
        )
    expected_plan_authority = _transition_plan_verification_authority(plan)
    expected_handoff_authority = _transition_handoff_verification_authority(handoff)

    expected_tickers = set(plan.tickers_json or ())
    actual = reconstruct_transition_decision_manifests(
        db,
        market_cutoff=market_cutoff,
        built_rows=built_rows,
        repository=repository,
        tickers=expected_tickers,
        checkpoint_callback=checkpoint_callback,
    )
    historical_ids = [row["id"] for row in handoff.manifest_json["ceri_score_snapshots"]]
    ceri_market_cutoff = _decision_ceri_context(db, plan, market_cutoff)
    _validate_handoff_temporal_lineage(
        db,
        upload_run_id=upload_run_id,
        market_cutoff=market_cutoff,
        ceri_market_cutoff=ceri_market_cutoff,
        historical_ids=historical_ids,
        built_rows=built_rows,
        checkpoint_callback=checkpoint_callback,
    )
    observed_anchor = build_run_start_anchor_manifest(
        db,
        upload_run_id=upload_run_id,
        market_cutoff=market_cutoff,
        decision_manifests=actual,
    )
    observed_anchor_fingerprint = CanonicalEvidenceSerializer.fingerprint(observed_anchor)
    if (
        not plan.run_start_anchor_json
        or not plan.run_start_anchor_fingerprint
        or observed_anchor != plan.run_start_anchor_json
        or observed_anchor_fingerprint != plan.run_start_anchor_fingerprint
    ):
        raise _rejection(
            plan,
            code="DECISION_MANIFEST_MISMATCH",
            category="run_start_anchor",
            message="run-start anchor no longer matches at decision handoff",
            expected_fingerprint=plan.run_start_anchor_fingerprint,
            actual_fingerprint=observed_anchor_fingerprint,
        )
    observed = _build_decision_handoff_payload(
        db,
        plan=plan,
        market_cutoff=market_cutoff,
        ceri_market_cutoff=ceri_market_cutoff,
        historical_ids=historical_ids,
        built_rows=built_rows,
        decision_manifests=actual,
        checkpoint_callback=checkpoint_callback,
    )
    observed_fingerprint = CanonicalEvidenceSerializer.fingerprint(observed)
    plan, handoff = _lock_transition_verification_authority(
        db,
        plan_id=plan.id,
        handoff_id=handoff.id,
        expected_plan_authority=expected_plan_authority,
        expected_handoff_authority=expected_handoff_authority,
    )
    if (
        set(actual) != expected_tickers
        or observed != handoff.manifest_json
        or observed_fingerprint != handoff.manifest_fingerprint
        or handoff.run_start_anchor_fingerprint != plan.run_start_anchor_fingerprint
    ):
        differing = sorted(
            ticker
            for ticker in expected_tickers | set(actual)
            if actual.get(ticker)
            != ((handoff.manifest_json or {}).get("decision_manifests") or {}).get(ticker)
        )
        raise _rejection(
            plan,
            code="DECISION_MANIFEST_MISMATCH",
            category="production_execution_manifest",
            message=(
                "production lifecycle inputs differ from the immutable preflight manifest; "
                f"tickers={','.join(differing)}"
            ),
            expected_fingerprint=handoff.manifest_fingerprint,
            actual_fingerprint=observed_fingerprint,
        )


def _transition_plan_verification_authority(plan: TransitionPreflightPlan) -> dict:
    return CanonicalEvidenceSerializer.canonicalize(
        {
            column.name: getattr(plan, column.name)
            for column in TransitionPreflightPlan.__table__.columns
        }
    )


def _transition_handoff_verification_authority(
    handoff: TransitionDecisionHandoffManifest,
) -> dict:
    return CanonicalEvidenceSerializer.canonicalize(
        {
            column.name: getattr(handoff, column.name)
            for column in TransitionDecisionHandoffManifest.__table__.columns
        }
    )


def _lock_transition_verification_authority(
    db: Session,
    *,
    plan_id: int,
    handoff_id: int,
    expected_plan_authority: dict,
    expected_handoff_authority: dict,
) -> tuple[TransitionPreflightPlan, TransitionDecisionHandoffManifest]:
    """Re-lock unchanged authority only after expensive read-only reconstruction."""

    with db.no_autoflush:
        plan = db.scalar(
            select(TransitionPreflightPlan)
            .where(TransitionPreflightPlan.id == plan_id)
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        handoff = db.scalar(
            select(TransitionDecisionHandoffManifest)
            .where(TransitionDecisionHandoffManifest.id == handoff_id)
            .with_for_update()
            .execution_options(populate_existing=True)
        )
    if plan is None or handoff is None:
        raise TransitionPreflightError(
            "DECISION_MANIFEST_MISMATCH",
            "decision handoff authority disappeared during read-only reconstruction",
        )
    if (
        _transition_plan_verification_authority(plan) != expected_plan_authority
        or _transition_handoff_verification_authority(handoff) != expected_handoff_authority
    ):
        raise _rejection(
            plan,
            code="DECISION_MANIFEST_MISMATCH",
            category="verification_authority",
            message="decision handoff authority changed during read-only reconstruction",
        )
    return plan, handoff


def freeze_transition_decision_handoff_manifest(
    db: Session,
    *,
    upload_run_id: int,
    market_cutoff: MarketCalculationCutoff,
    checkpoint_callback=None,
) -> TransitionDecisionHandoffManifest | None:
    """Persist the actual decision inputs after upstream stages have committed."""

    def checkpoint(phase: str, processed: int, total: int, current_item: str) -> None:
        if checkpoint_callback is not None:
            checkpoint_callback(
                phase=phase,
                processed=processed,
                total=total,
                current_item=current_item,
                last_completed_item=current_item if processed else None,
            )

    plan = db.scalar(
        select(TransitionPreflightPlan)
        .where(
            TransitionPreflightPlan.market_calculation_context_id == market_cutoff.context_id,
            TransitionPreflightPlan.upload_run_id == upload_run_id,
            TransitionPreflightPlan.status == "CONSUMED",
        )
        .with_for_update()
    )
    prepared_inputs: dict[str, Any] = {}
    if plan is None:
        plan = _create_pipeline_decision_handoff_plan(
            db,
            upload_run_id=upload_run_id,
            market_cutoff=market_cutoff,
            checkpoint_callback=checkpoint_callback,
            prepared_inputs=prepared_inputs,
        )
    checkpoint("PLAN_LOADED", 1, 1, f"plan:{plan.id}")
    if not plan.run_start_anchor_json or not plan.run_start_anchor_fingerprint:
        raise _rejection(
            plan,
            code="MALFORMED_DECISION_MANIFEST",
            category="run_start_anchor",
            message="preflight is missing its immutable run-start anchor",
        )

    from app.services.setup_lifecycle.repository import SetupLifecycleRepository
    from app.services.setup_lifecycle.snapshot_builder import (
        SetupLifecycleSnapshotBuilder,
        build_run_context_snapshots,
    )
    from app.services.setup_lifecycle.source_loader import SetupLifecycleSourceLoader

    repository = SetupLifecycleRepository()
    reuse_prepared = (
        bool(prepared_inputs)
        and prepared_inputs["transaction"] is db.get_transaction()
        and prepared_inputs["nested_transaction"]
        is getattr(db, "get_nested_transaction", lambda: None)()
        and not any(row is not plan for row in db.dirty)
        and not any(row is not plan for row in getattr(db, "new", ()))
        and not getattr(db, "deleted", ())
    )
    if reuse_prepared:
        run_context = prepared_inputs["run_context"]
    else:
        run_context = SetupLifecycleSourceLoader().load_run_context(
            db,
            upload_run_id,
            market_cutoff=market_cutoff,
            tickers=set(plan.tickers_json or ()),
            **(
                {"checkpoint_callback": checkpoint_callback}
                if checkpoint_callback is not None
                else {}
            ),
        )
    # JSON columns do not track nested in-place changes in Session.dirty. Reuse
    # only loaded sources, never the derived DTOs across the PLAN_LOADED callback:
    # rebuilding keeps raw-input fingerprints and the run-start anchor sensitive
    # to a changed nested source, even when SQLAlchemy reports a clean Session.
    built_rows = build_run_context_snapshots(
        db,
        run_context,
        builder=SetupLifecycleSnapshotBuilder(),
        repository=repository,
        checkpoint_callback=checkpoint_callback,
    )
    ticker_total = len(getattr(run_context, "tickers", ()) or plan.tickers_json or ())
    checkpoint("RUN_CONTEXT_LOADED", ticker_total, ticker_total, "run-context")
    # Reconstruct pointer-dependent decisions again: source preparation can be
    # reused, but the run-start anchor must still reject a changed setup pointer.
    actual = reconstruct_transition_decision_manifests(
        db,
        market_cutoff=market_cutoff,
        built_rows=built_rows,
        repository=repository,
        tickers=set(plan.tickers_json or ()),
        checkpoint_callback=checkpoint_callback,
    )
    if set(actual) != set(plan.tickers_json or ()):
        raise _rejection(
            plan,
            code="DECISION_LINEAGE_MISMATCH",
            category="ticker_population",
            message="handoff ticker population differs from the run-start anchor",
        )
    ceri_market_cutoff = _decision_ceri_context(db, plan, market_cutoff)
    _validate_handoff_temporal_lineage(
        db,
        upload_run_id=upload_run_id,
        market_cutoff=market_cutoff,
        ceri_market_cutoff=ceri_market_cutoff,
        built_rows=built_rows,
        checkpoint_callback=checkpoint_callback,
    )
    observed_anchor = build_run_start_anchor_manifest(
        db,
        upload_run_id=upload_run_id,
        market_cutoff=market_cutoff,
        decision_manifests=actual,
    )
    observed_anchor_fingerprint = CanonicalEvidenceSerializer.fingerprint(observed_anchor)
    if (
        observed_anchor != plan.run_start_anchor_json
        or observed_anchor_fingerprint != plan.run_start_anchor_fingerprint
    ):
        raise _rejection(
            plan,
            code="DECISION_MANIFEST_MISMATCH",
            category="run_start_anchor",
            message="run-start anchor changed before handoff",
            expected_fingerprint=plan.run_start_anchor_fingerprint,
            actual_fingerprint=observed_anchor_fingerprint,
        )
    checkpoint("RUN_START_ANCHOR_VERIFIED", ticker_total, ticker_total, "run-start-anchor")

    payload = _build_decision_handoff_payload(
        db,
        plan=plan,
        market_cutoff=market_cutoff,
        ceri_market_cutoff=ceri_market_cutoff,
        built_rows=built_rows,
        decision_manifests=actual,
        checkpoint_callback=checkpoint_callback,
    )
    fingerprint = CanonicalEvidenceSerializer.fingerprint(payload)
    existing = db.scalar(
        select(TransitionDecisionHandoffManifest).where(
            TransitionDecisionHandoffManifest.preflight_plan_id == plan.id
        )
    )
    if existing is not None:
        if existing.manifest_fingerprint != fingerprint or existing.manifest_json != payload:
            raise _rejection(
                plan,
                code="IMMUTABLE_EVIDENCE_MISMATCH",
                category="decision_handoff",
                message="an immutable handoff manifest already exists with different evidence",
                expected_fingerprint=existing.manifest_fingerprint,
                actual_fingerprint=fingerprint,
            )
        checkpoint("MANIFEST_REUSED", ticker_total, ticker_total, f"manifest:{existing.id}")
        return existing
    manifest = TransitionDecisionHandoffManifest(
        preflight_plan_id=plan.id,
        market_calculation_context_id=market_cutoff.context_id,
        upload_run_id=upload_run_id,
        pipeline_run_id=plan.pipeline_run_id,
        run_start_anchor_fingerprint=plan.run_start_anchor_fingerprint,
        manifest_json=payload,
        manifest_fingerprint=fingerprint,
    )
    db.add(manifest)
    db.flush()
    checkpoint("MANIFEST_STAGED", ticker_total, ticker_total, f"manifest:{manifest.id}")
    return manifest


def _create_pipeline_decision_handoff_plan(
    db: Session,
    *,
    upload_run_id: int,
    market_cutoff: MarketCalculationCutoff,
    checkpoint_callback=None,
    prepared_inputs: dict[str, Any] | None = None,
) -> TransitionPreflightPlan:
    """Anchor a fresh pipeline's post-upstream decision set before consumers run.

    A transition preflight supplied by an operator remains the stronger run-start
    contract. Fresh full pipelines cannot prove a HIGH lifecycle transition before
    their upstream calculations exist, so they freeze the exact calculated source
    set at the existing handoff boundary instead of running Winner without a gate.
    """

    if market_cutoff.context_id is None:
        raise TransitionPreflightError(
            "CONTEXT_MISMATCH",
            "pipeline decision handoff requires a persisted market context",
        )
    context = db.get(MarketCalculationContext, market_cutoff.context_id)
    if context is None or context.upload_run_id != upload_run_id or context.pipeline_run_id is None:
        raise TransitionPreflightError(
            "CONTEXT_MISMATCH",
            "pipeline decision handoff context is missing or not pipeline-owned",
        )

    from app.services.setup_lifecycle.repository import SetupLifecycleRepository
    from app.services.setup_lifecycle.snapshot_builder import (
        SetupLifecycleSnapshotBuilder,
        build_run_context_snapshots,
    )
    from app.services.setup_lifecycle.source_loader import SetupLifecycleSourceLoader

    repository = SetupLifecycleRepository()
    downstream_tickers = _pipeline_downstream_tickers(db, pipeline_run_id=context.pipeline_run_id)
    if downstream_tickers == set():
        raise TransitionPreflightError(
            "NO_DOWNSTREAM_ELIGIBLE_TICKERS",
            "all requested instruments have explicit terminal exclusions; "
            "no decision handoff is eligible",
        )
    run_context = SetupLifecycleSourceLoader().load_run_context(
        db,
        upload_run_id,
        market_cutoff=market_cutoff,
        tickers=downstream_tickers,
        **({"checkpoint_callback": checkpoint_callback} if checkpoint_callback is not None else {}),
    )
    built_rows = build_run_context_snapshots(
        db,
        run_context,
        builder=SetupLifecycleSnapshotBuilder(),
        repository=repository,
        checkpoint_callback=checkpoint_callback,
    )
    decision_manifests = reconstruct_transition_decision_manifests(
        db,
        market_cutoff=market_cutoff,
        built_rows=built_rows,
        repository=repository,
        tickers=downstream_tickers,
        checkpoint_callback=checkpoint_callback,
    )
    if not decision_manifests:
        raise TransitionPreflightError(
            "DECISION_LINEAGE_MISMATCH",
            "pipeline decision handoff has no source-backed ticker manifests",
        )
    ceri_market_cutoff = _resolve_decision_ceri_context(
        db,
        pipeline_run_id=context.pipeline_run_id,
        upload_run_id=upload_run_id,
        market_cutoff=market_cutoff,
    )
    if prepared_inputs is None:
        # A standalone creation validates here. The enclosing freeze operation
        # validates after its pointer reconstruction, before staging a manifest.
        _validate_handoff_temporal_lineage(
            db,
            upload_run_id=upload_run_id,
            market_cutoff=market_cutoff,
            ceri_market_cutoff=ceri_market_cutoff,
            built_rows=built_rows,
            checkpoint_callback=checkpoint_callback,
        )
    anchor = build_run_start_anchor_manifest(
        db,
        upload_run_id=upload_run_id,
        market_cutoff=market_cutoff,
        decision_manifests=decision_manifests,
    )
    anchor_fingerprint = CanonicalEvidenceSerializer.fingerprint(anchor)
    tickers = sorted(decision_manifests)
    candidate_payloads = {
        ticker: dict(wrapper.get("decision_manifest") or {}).get("candidate") or {}
        for ticker, wrapper in decision_manifests.items()
    }
    confidence = next(
        (
            value
            for value in ("HIGH", "MEDIUM", "LOW")
            if any(
                str(candidate.get("confidence") or "").upper() == value
                for candidate in candidate_payloads.values()
            )
        ),
        "LOW",
    )
    now = _utcnow()
    plan = TransitionPreflightPlan(
        market_calculation_context_id=market_cutoff.context_id,
        upload_run_id=upload_run_id,
        pipeline_run_id=context.pipeline_run_id,
        status=TransitionPreflightPlanStatus.CONSUMED.value,
        idempotency_key=(
            f"pipeline-decision-handoff:{context.pipeline_run_id}:{market_cutoff.context_id}"
        ),
        candidate_classification=confidence,
        tickers_json=tickers,
        selection_keys_json=sorted(
            str(candidate.get("selection_key"))
            for candidate in candidate_payloads.values()
            if candidate.get("selection_key") is not None
        ),
        expected_pointers_json={
            ticker: (dict(wrapper.get("decision_manifest") or {}).get("expected_pointer") or {})
            for ticker, wrapper in decision_manifests.items()
        },
        predicted_snapshot_identities_json={
            ticker: {
                "selection_key": candidate_payloads[ticker].get("selection_key"),
                "decision_manifest_fingerprint": wrapper.get("decision_manifest_fingerprint"),
            }
            for ticker, wrapper in decision_manifests.items()
        },
        candidate_results_json=[
            {
                "ticker": ticker,
                **wrapper,
            }
            for ticker, wrapper in sorted(decision_manifests.items())
        ],
        evidence_fingerprint=CanonicalEvidenceSerializer.fingerprint(decision_manifests),
        technical_reconstruction_fingerprint=CanonicalEvidenceSerializer.fingerprint(
            {
                ticker: (
                    dict(wrapper.get("decision_manifest") or {})
                    .get("source_ids", {})
                    .get("technical_score_id")
                )
                for ticker, wrapper in decision_manifests.items()
            }
        ),
        run_start_anchor_json=anchor,
        run_start_anchor_fingerprint=anchor_fingerprint,
        created_at=now,
        expires_at=now + DEFAULT_PREFLIGHT_TTL,
        consumed_at=now,
    )
    db.add(plan)
    db.flush()
    if prepared_inputs is not None:
        prepared_inputs.update(
            transaction=db.get_transaction(),
            nested_transaction=getattr(db, "get_nested_transaction", lambda: None)(),
            run_context=run_context,
        )
    return plan


def _pipeline_downstream_tickers(
    db: Session,
    *,
    pipeline_run_id: int,
) -> set[str] | None:
    """Return the frozen admitted population, or None for legacy/preflight callers."""

    from app.services.market_data_session_readiness import load_current_session_readiness

    readiness = load_current_session_readiness(db, pipeline_run_id=pipeline_run_id)
    if readiness is None:
        return None
    rows = readiness.rows
    from app.services.market_data_availability_policy import (
        hard_readiness_blockers,
        parse_availability_policy,
        pipeline_availability_policy,
        processing_tickers,
    )

    pipeline = db.get(PipelineRun, pipeline_run_id)
    policy = (
        pipeline_availability_policy(pipeline)
        if pipeline is not None
        else (parse_availability_policy())
    )
    blockers = hard_readiness_blockers(rows, policy)
    if blockers:
        raise TransitionPreflightError(
            "MARKET_DATA_SESSION_READINESS_BLOCKED",
            "decision handoff cannot bypass unresolved market-data dispositions: "
            + ",".join(f"{row.ticker}={row.disposition}" for row in blockers),
        )
    return {ticker.upper() for ticker in processing_tickers(rows, policy)}


def reconstruct_transition_decision_manifests(
    db: Session,
    *,
    market_cutoff: MarketCalculationCutoff,
    built_rows,
    repository,
    tickers: set[str] | None = None,
    checkpoint_callback=None,
) -> dict[str, dict[str, object]]:
    """Reconstruct the exact manifest consumed by lifecycle persistence."""

    discovery = TransitionCandidateDiscoveryService(repository=repository)
    actual: dict[str, dict[str, object]] = {}
    selected_rows = [row for row in built_rows if tickers is None or row[0].ticker in tickers]
    total = len(selected_rows)
    for index, (ticker_context, built) in enumerate(selected_rows, start=1):
        latest_pointer, exact_pointer, latest_revision, exact_revision = discovery._pointers(
            db,
            ticker=built.dto.ticker,
            timeframe=built.dto.timeframe,
            data_as_of_date=built.dto.data_as_of_date,
        )
        assessed = discovery.assess(
            built,
            prospective=market_cutoff,
            latest_pointer=latest_pointer,
            exact_pointer=exact_pointer,
            all_required_pit_inputs=_prospective_inputs_are_complete(
                ticker_context, built, market_cutoff
            ),
            latest_pointer_revision=latest_revision,
            exact_pointer_revision=exact_revision,
        )
        technical_fingerprint = _technical_reconstruction_fingerprint(
            ticker_context.technical_score
        )
        manifest = build_transition_decision_manifest(
            built=built,
            context=ticker_context,
            market_cutoff=market_cutoff,
            technical_reconstruction_fingerprint=technical_fingerprint,
            current_pointer_snapshot_id=assessed.current_pointer_snapshot_id,
            current_pointer_revision=assessed.expected_latest_pointer_revision,
            exact_pointer_snapshot_id=assessed.expected_exact_pointer_snapshot_id,
            exact_pointer_revision=assessed.expected_exact_pointer_revision,
            candidate_type=candidate_type_for(assessed),
            candidate_reason=assessed.reason,
            candidate_confidence=assessed.confidence,
            predicted_pointer_advance=assessed.predicted_pointer_advance,
            predicted_current_state_advance=assessed.predicted_current_state_advance,
        )
        actual[ticker_context.ticker] = {
            "decision_manifest": manifest.as_dict(),
            "decision_manifest_fingerprint": manifest.fingerprint,
        }
        if checkpoint_callback is not None and (index % 10 == 0 or index == total):
            checkpoint_callback(
                phase="DECISION_MANIFESTS_RECONSTRUCTED",
                processed=index,
                total=total,
                current_item=ticker_context.ticker,
                last_completed_item=ticker_context.ticker,
            )
    return actual


def consume_transition_preflight(
    db: Session,
    *,
    verified: VerifiedTransitionPreflight,
    pipeline: PipelineRun,
) -> MarketCalculationCutoff:
    if verified.plan.status != "RESERVED":
        raise TransitionPreflightError("ALREADY_CONSUMED", "plan is no longer reserved")
    market_cutoff = attach_reserved_market_context(
        db,
        pipeline,
        context_id=verified.plan.market_calculation_context_id,
    )
    verified.plan.status = "CONSUMED"
    verified.plan.pipeline_run_id = pipeline.id
    verified.plan.consumed_at = _utcnow()
    db.flush()
    logger.info(
        "transition_preflight_consumed plan_id=%s context_id=%s upload_run_id=%s "
        "pipeline_id=%s candidate_type=%s selection_keys=%s cutoff=%s session=%s",
        verified.plan.id,
        verified.plan.market_calculation_context_id,
        verified.plan.upload_run_id,
        pipeline.id,
        verified.plan.candidate_classification,
        ",".join(verified.plan.selection_keys_json),
        CanonicalEvidenceSerializer.canonicalize(market_cutoff.cutoff_at),
        market_cutoff.latest_completed_session.isoformat(),
    )
    return market_cutoff


def cancel_transition_preflight(db: Session, plan_id: int) -> TransitionPreflightPlan:
    plan = db.scalar(
        select(TransitionPreflightPlan)
        .where(TransitionPreflightPlan.id == plan_id)
        .with_for_update()
    )
    if plan is None:
        raise ValueError(f"Transition preflight plan {plan_id} was not found.")
    if plan.status == "RESERVED":
        plan.status = "CANCELLED"
        plan.cancelled_at = _utcnow()
        db.flush()
    return plan


def expire_abandoned_preflights(db: Session, *, now: datetime | None = None) -> int:
    observed_at = now or _utcnow()
    rows = list(
        db.scalars(
            select(TransitionPreflightPlan)
            .where(TransitionPreflightPlan.status == "RESERVED")
            .where(TransitionPreflightPlan.expires_at <= observed_at)
            .with_for_update(skip_locked=True)
        )
    )
    for plan in rows:
        plan.status = "EXPIRED"
        plan.stale_reason = "TTL_EXPIRED"
    if rows:
        db.flush()
    return len(rows)


def build_run_start_anchor_manifest(
    db: Session,
    *,
    upload_run_id: int,
    market_cutoff: MarketCalculationCutoff,
    results: list[TransitionCandidateResult] | None = None,
    decision_manifests: dict[str, dict[str, object]] | None = None,
) -> dict[str, Any]:
    """Build only facts that already exist and are immutable at run start."""

    run = db.get(UploadRun, upload_run_id)
    if run is None:
        raise TransitionPreflightError("MALFORMED_DECISION_MANIFEST", "upload run is missing")
    raw_rows = list(
        db.scalars(
            select(RawCompanyRow)
            .where(RawCompanyRow.run_id == upload_run_id)
            .order_by(RawCompanyRow.row_number, RawCompanyRow.id)
        )
    )
    manifests = decision_manifests or {
        row.ticker: {
            "decision_manifest": row.decision_manifest or {},
            "decision_manifest_fingerprint": row.decision_manifest_fingerprint,
        }
        for row in results or ()
    }
    per_ticker: dict[str, Any] = {}
    for ticker, wrapper in sorted(manifests.items()):
        manifest = dict(wrapper.get("decision_manifest") or {})
        lifecycle = dict(manifest.get("lifecycle_semantics") or {})
        candidate = dict(manifest.get("candidate") or {})
        per_ticker[ticker] = {
            "ticker": ticker,
            "selection_key": candidate.get("selection_key"),
            "raw_row_id": (manifest.get("source_ids") or {}).get("raw_row_id"),
            "expected_pointer": manifest.get("expected_pointer"),
            "eligible_price_bars": manifest.get("eligible_price_bars") or [],
            "producer_signatures": {
                "setup_engine_version": lifecycle.get("engine_version"),
                "setup_config_version": lifecycle.get("config_version"),
                "setup_config_hash": lifecycle.get("config_hash"),
                "setup_schema_version": lifecycle.get("schema_version"),
                "decision_manifest_builder": "transition-decision-manifest-v1",
            },
        }
    raw_payloads = [_semantic_model_payload(row) for row in raw_rows]
    payload = {
        "contract": RUN_START_ANCHOR_CONTRACT,
        "run": {
            "id": run.id,
            "filename": run.filename,
            "uploaded_at": run.uploaded_at,
            "processed_at": run.processed_at,
            "row_count": run.row_count,
            "status": run.status,
            "pine_engine_version": run.pine_engine_version,
            "python_engine_version": run.python_engine_version,
            "raw_row_count": len(raw_payloads),
            "raw_rows_fingerprint": CanonicalEvidenceSerializer.fingerprint(raw_payloads),
        },
        "ticker_population": sorted(per_ticker),
        "market_context": _market_context_payload(market_cutoff),
        "source_cutoffs": {
            "market_cutoff_at": market_cutoff.cutoff_at,
            "latest_completed_session": market_cutoff.latest_completed_session,
            "price_observed_at_or_before": market_cutoff.cutoff_at,
            "source_document_known_at_or_before": market_cutoff.cutoff_at,
        },
        "immutable_source_lineage": per_ticker,
    }
    return CanonicalEvidenceSerializer.canonicalize(payload)


def _handoff_scores(db, upload_id, pipeline_id, cutoff, main_cutoff, historical_ids):
    pipeline = db.get(PipelineRun, pipeline_id) if pipeline_id else None
    receipt = (pipeline.result_json or {}).get("ceri_certified_score_ids") if pipeline else None
    if receipt is not None:
        from app.services.ceri.score_population import certified_scores

        return certified_scores(db, pipeline_id, cutoff.context_id, expected_ids=receipt)
    if historical_ids is not None and pipeline and pipeline.status in {"PARTIAL", "COMPLETED"}:
        # Verify immutable legacy membership as frozen before terminal dispositions.
        statement = select(CeriScoreSnapshot).where(CeriScoreSnapshot.id.in_(historical_ids))
    else:
        if cutoff.context_id != main_cutoff.context_id:
            raise ValueError("CERI_CERTIFIED_CAPTURE_RECEIPT_MISSING")
        statement = eligible_snapshot_select(name="effective_handoff_dispositions").where(
            CeriScoreSnapshot.calculation_context_id == cutoff.context_id,
            CeriScoreSnapshot.controlled_replay_id.is_(None),
        )
    rows = list(
        db.scalars(
            statement.where(CeriScoreSnapshot.run_id == upload_id).order_by(
                CeriScoreSnapshot.ticker, CeriScoreSnapshot.id
            )
        )
    )
    if historical_ids is not None and sorted(row.id for row in rows) != sorted(historical_ids):
        raise ValueError("CERI_HISTORICAL_MEMBERSHIP_MISMATCH")
    if historical_ids is None and pipeline and rows:
        from app.services.ceri.score_population import certified_scores

        return certified_scores(db, pipeline_id, cutoff.context_id)
    if (
        historical_ids is None
        and pipeline
        and "ceri_score_snapshots" in (pipeline.result_json or {})
    ):
        raise ValueError("CERI_CERTIFIED_CAPTURE_RECEIPT_MISSING")
    return rows


def _build_decision_handoff_payload(
    db: Session,
    *,
    plan: TransitionPreflightPlan,
    market_cutoff: MarketCalculationCutoff,
    ceri_market_cutoff: MarketCalculationCutoff,
    built_rows,
    decision_manifests: dict[str, dict[str, object]],
    checkpoint_callback=None,
    historical_ids=None,
) -> dict[str, Any]:
    artifacts: dict[str, Any] = {}
    shared_contexts: dict[tuple[type, int], tuple[Any, list[tuple[str, str]]]] = {}
    total = len(built_rows)
    for index, (context, built) in enumerate(built_rows, start=1):
        ticker = context.ticker
        for definition in REQUIRED_HANDOFF_CONTEXT_ARTIFACTS:
            validate_required_handoff_context_artifact(
                getattr(context, definition.key),
                definition=definition,
                ticker=ticker,
                upload_run_id=plan.upload_run_id,
                pipeline_run_id=plan.pipeline_run_id,
                calculation_context_id=market_cutoff.context_id,
                cutoff_at=market_cutoff.cutoff_at,
                input_as_of_session=market_cutoff.latest_completed_session,
                calendar_version=market_cutoff.calendar_version,
            )
        artifacts[ticker] = {
            "raw_row": _artifact_identity(context.raw_row),
            "fundamental_score": _artifact_identity(context.fundamental_score),
            "technical_score": _artifact_identity(context.technical_score),
            "combined_result": _artifact_identity(context.combined_result),
            "ranking_results": [
                _artifact_identity(row)
                for row in sorted(
                    context.ranking_results,
                    key=lambda row: (row.ranking_profile, row.profile_rank, row.id or 0),
                )
            ],
            "market_regime_snapshot": None,
            "sector_rotation_snapshot": None,
            "sector_rotation_row": _artifact_identity(context.sector_rotation_row),
            "eligible_price_bars": [
                {
                    "id": row.id,
                    "session": row.bar_date,
                    "timeframe": row.timeframe,
                    "what_to_show": row.what_to_show,
                    "revision_count": row.revision_count,
                    "data_hash": row.data_hash,
                }
                for row in context.price_bars
            ],
            "setup_signal_input_hash": built.source_data_hash,
        }
        for key in ("market_regime_snapshot", "sector_rotation_snapshot"):
            row = getattr(context, key)
            if row is not None:
                _, targets = shared_contexts.setdefault((type(row), id(row)), (row, []))
                targets.append((ticker, key))
        # Company-specific identities are complete; shared context hashes are
        # verified below before publishing completed lineage checkpoints.
        if checkpoint_callback is not None:
            checkpoint_callback(
                phase="ARTIFACT_COMPANY_INPUTS_SERIALIZED",
                processed=index,
                total=total,
                current_item=ticker,
                last_completed_item=ticker,
            )
    # Hash each shared global row after ticker callbacks have finished. This is
    # an invocation-local batch, not a successful-hash cache surviving mutation,
    # callbacks, transaction boundaries, or a subsequent freeze/verification.
    for row, targets in shared_contexts.values():
        identity = _artifact_identity(row, checkpoint_callback=checkpoint_callback)
        for ticker, key in targets:
            artifacts[ticker][key] = identity
    if checkpoint_callback is not None:
        for index, (context, _built) in enumerate(built_rows, start=1):
            checkpoint_callback(
                phase="ARTIFACT_LINEAGE_SERIALIZED",
                processed=index,
                total=total,
                current_item=context.ticker,
                last_completed_item=context.ticker,
            )
    ceri_rows = _handoff_scores(
        db,
        plan.upload_run_id,
        plan.pipeline_run_id,
        ceri_market_cutoff,
        market_cutoff,
        historical_ids,
    )
    payload = {
        "contract": DECISION_HANDOFF_CONTRACT,
        "binding": {
            "preflight_plan_id": plan.id,
            "run_start_anchor_fingerprint": plan.run_start_anchor_fingerprint,
        },
        "run": {
            "upload_run_id": plan.upload_run_id,
            "pipeline_run_id": plan.pipeline_run_id,
        },
        "market_context": _market_context_payload(market_cutoff),
        **(
            {"ceri_context": _market_context_payload(ceri_market_cutoff)}
            if ceri_market_cutoff.context_id != market_cutoff.context_id
            else {}
        ),
        "decision_manifests": decision_manifests,
        "artifact_lineage": artifacts,
        "ceri_score_snapshots": [_artifact_identity(row) for row in ceri_rows],
    }
    return CanonicalEvidenceSerializer.canonicalize(payload)


def _decision_ceri_context(
    db: Session,
    plan: TransitionPreflightPlan,
    market_cutoff: MarketCalculationCutoff,
) -> MarketCalculationCutoff:
    """Resolve the explicitly retained CERI context for a mixed-context handoff."""

    return _resolve_decision_ceri_context(
        db,
        pipeline_run_id=plan.pipeline_run_id,
        upload_run_id=int(plan.upload_run_id),
        market_cutoff=market_cutoff,
    )


def _resolve_decision_ceri_context(
    db: Session,
    *,
    pipeline_run_id: int | None,
    upload_run_id: int,
    market_cutoff: MarketCalculationCutoff,
) -> MarketCalculationCutoff:
    if pipeline_run_id is None:
        return market_cutoff
    pipeline = db.get(PipelineRun, int(pipeline_run_id))
    retained_id = (
        (pipeline.result_json or {}).get("ceri_calculation_context_id")
        if pipeline is not None
        else None
    )
    if retained_id is None:
        return market_cutoff
    from app.services.market_calculation_context_service import resolve_pipeline_ceri_context

    ceri_cutoff = resolve_pipeline_ceri_context(
        db,
        calculation_context_id=int(retained_id),
        upload_run_id=upload_run_id,
        pipeline_run_id=int(pipeline_run_id),
    )
    if _aware(ceri_cutoff.cutoff_at) < _aware(market_cutoff.cutoff_at):
        raise TransitionPreflightError(
            "DECISION_LINEAGE_MISMATCH",
            "the retained CERI context predates the pipeline market context",
        )
    return ceri_cutoff


def _validate_handoff_temporal_lineage(
    db: Session,
    *,
    upload_run_id: int,
    market_cutoff: MarketCalculationCutoff,
    ceri_market_cutoff: MarketCalculationCutoff | None = None,
    built_rows,
    checkpoint_callback=None,
    historical_ids=None,
) -> None:
    ceri_cutoff = ceri_market_cutoff or market_cutoff
    failures: list[str] = []
    price_bars = []
    calculation_context = db.get(MarketCalculationContext, market_cutoff.context_id)
    pipeline_run_id = getattr(calculation_context, "pipeline_run_id", None)
    total = len(built_rows)
    shared_context_pairs: dict[tuple[int, int], tuple[Any, Any, list[str]]] = {}
    for index, (context, _built) in enumerate(built_rows, start=1):
        ticker = context.ticker
        raw = context.raw_row
        fundamental = context.fundamental_score
        technical = context.technical_score
        combined = context.combined_result
        market = context.market_regime_snapshot
        sector = context.sector_rotation_snapshot
        if raw.run_id != upload_run_id:
            failures.append(f"{ticker}:raw_run")
        if fundamental is not None and (
            fundamental.run_id != upload_run_id or fundamental.ticker.upper() != ticker
        ):
            failures.append(f"{ticker}:fundamental_run")
        if technical is None:
            failures.append(f"{ticker}:technical_missing")
        elif not _temporal_artifact_matches(technical, market_cutoff, upload_run_id):
            failures.append(f"{ticker}:technical_cutoff")
        if combined is not None:
            if combined.run_id != upload_run_id or combined.ticker.upper() != ticker:
                failures.append(f"{ticker}:combined_run")
            expected_sources = {
                "raw_row_id": raw.id,
                "fundamental_score_id": getattr(fundamental, "id", None),
                "technical_score_id": getattr(technical, "id", None),
            }
            observed_sources = dict((combined.debug_json or {}).get("source_ids") or {})
            if getattr(combined, "evidence_id", None) is not None or any(
                key.endswith("_evidence_id") for key in observed_sources
            ):
                from app.services.core_calculation_evidence import (
                    CoreEvidenceKind,
                    get_certified_evidence_for_row,
                )

                # Certified Combined proof pins immutable source evidence; score
                # projection IDs can change on an exact retry. Verify both the
                # retained graph and the supplied upstream evidence pointers.
                evidence = get_certified_evidence_for_row(
                    db, kind=CoreEvidenceKind.COMBINED, current_row=combined
                )
                from app.models.tables import CoreCalculationEvidence

                if isinstance(evidence, CoreCalculationEvidence):
                    from app.services.core_mutation_authority import (
                        _validate_evidence,
                        validate_source_values,
                    )

                    _validate_evidence(evidence)
                    validate_source_values(combined, evidence, db=db)
                    # Native blocked-input decisions can clear compatibility
                    # score IDs. The immutable graph retains the actual upstream
                    # evidence, including inputs evaluated and then blocked.
                    observed_sources = dict(
                        (evidence.payload_json.get("debug_json") or {}).get("source_ids") or {}
                    )
                expected_pins = {
                    role: source.evidence_id
                    for role, source in (("fundamental", fundamental), ("technical", technical))
                    if source is not None and source.evidence_id is not None
                }
                expected_sources = {
                    "raw_row_id": raw.id,
                    **{role + "_evidence_id": address for role, address in expected_pins.items()},
                }
                if _combined_source_evidence_pins(evidence) != expected_pins:
                    failures.append(f"{ticker}:combined_evidence_sources")
            if observed_sources != expected_sources:
                failures.append(f"{ticker}:combined_sources")
        for ranking in context.ranking_results:
            if (
                ranking.run_id != upload_run_id
                or ranking.ticker.upper() != ticker
                or ranking.raw_row_id != raw.id
            ):
                failures.append(f"{ticker}:ranking_sources")
        for definition in REQUIRED_HANDOFF_CONTEXT_ARTIFACTS:
            try:
                validate_required_handoff_context_artifact(
                    getattr(context, definition.key),
                    definition=definition,
                    ticker=ticker,
                    upload_run_id=upload_run_id,
                    pipeline_run_id=pipeline_run_id,
                    calculation_context_id=market_cutoff.context_id,
                    cutoff_at=market_cutoff.cutoff_at,
                    input_as_of_session=market_cutoff.latest_completed_session,
                    calendar_version=market_cutoff.calendar_version,
                )
            except RequiredHandoffArtifactError as exc:
                failures.append(str(exc))
        if sector is not None and market is not None:
            _, _, pair_tickers = shared_context_pairs.setdefault(
                (id(sector), id(market)), (sector, market, [])
            )
            pair_tickers.append(ticker)
        if context.sector_rotation_row is not None and (
            sector is None or context.sector_rotation_row.snapshot_id != sector.id
        ):
            failures.append(f"{ticker}:sector_row_parent")
        price_bars.extend(context.price_bars)
        if checkpoint_callback is not None and (index % 10 == 0 or index == total):
            checkpoint_callback(
                phase="TEMPORAL_TICKER_LINEAGE_VALIDATED",
                processed=index,
                total=total,
                current_item=ticker,
                last_completed_item=ticker,
            )

    # Validate shared context after all per-ticker callbacks. Hoisting the native
    # validation retains its source/child locks and full integrity checks while
    # avoiding 159 hashes of the same global evidence. Nothing is reused across
    # validation calls, transactions, or different ORM source objects.
    for sector, market, pair_tickers in shared_context_pairs.values():
        if not _sector_market_parent_matches(
            db, sector, market, checkpoint_callback=checkpoint_callback
        ):
            failures.extend(f"{ticker}:sector_market_parent" for ticker in pair_tickers)

    for bar in invalid_price_bar_rows_for_context(
        db,
        price_bars,
        max_session=market_cutoff.latest_completed_session,
        as_of=market_cutoff.cutoff_at,
        calculation_context_id=market_cutoff.context_id,
    ):
        failures.append(f"{bar.ticker.upper()}:post_cutoff_bar")

    ceri_rows = _handoff_scores(
        db, upload_run_id, pipeline_run_id, ceri_cutoff, market_cutoff, historical_ids
    )
    for row in ceri_rows:
        if (
            row.calculation_context_id != ceri_cutoff.context_id
            or _canonical_time(row.cutoff_at) != _canonical_time(ceri_cutoff.cutoff_at)
            or row.as_of_session > ceri_cutoff.latest_completed_session
            or row.calendar_version != ceri_cutoff.calendar_version
        ):
            failures.append(f"{row.ticker}:ceri_cutoff")
    failures.extend(source_lineage_failures(db, ceri_rows, ceri_cutoff))
    if failures:
        raise TransitionPreflightError(
            "DECISION_LINEAGE_MISMATCH",
            "decision artifacts do not descend from the frozen cutoff: "
            + ",".join(sorted(set(failures))[:25]),
        )
    if checkpoint_callback is not None:
        checkpoint_callback(
            phase="TEMPORAL_LINEAGE_VALIDATED",
            processed=total,
            total=total,
            current_item="temporal-lineage",
            last_completed_item="temporal-lineage",
        )


def _sector_market_parent_matches(db: Session, sector, market, *, checkpoint_callback=None) -> bool:
    if sector.market_regime_snapshot_id == market.id:
        return True
    if sector.market_regime_snapshot_id is not None:
        return False

    # Sector clears the compatibility parent when Regime is policy-omitted.
    # Its sealed graph must still pin the exact selected source and the frozen
    # omission must agree with that source's certified readiness and policy.
    from app.models.tables import CoreCalculationEvidence
    from app.services.contextual_consumer_eligibility import (
        REGIME_TO_SECTOR,
        contextual_decision_input,
    )
    from app.services.core_calculation_evidence import (
        CoreEvidenceKind,
        get_certified_evidence_for_row,
    )
    from app.services.core_mutation_authority import (
        _validate_evidence,
        sector_evidence_read_scope,
        validate_source_values,
    )

    sector_evidence = get_certified_evidence_for_row(
        db, kind=CoreEvidenceKind.SECTOR, current_row=sector
    )
    market_evidence = get_certified_evidence_for_row(
        db, kind=CoreEvidenceKind.REGIME, current_row=market
    )
    progress_scope = (
        sector_evidence_read_scope(
            db, checkpoint_callback=_handoff_hash_checkpoint(checkpoint_callback)
        )
        if checkpoint_callback is not None and isinstance(db, Session)
        else nullcontext()
    )
    with progress_scope:
        for row, evidence in ((sector, sector_evidence), (market, market_evidence)):
            if not isinstance(evidence, CoreCalculationEvidence):
                return False
            _validate_evidence(evidence)
            validate_source_values(row, evidence, db=db)
    pins = sector_evidence.source_evidence_ids_json or {}
    if pins.get("regime") != market_evidence.id:
        return False
    frozen = (
        (sector_evidence.payload_json.get("debug") or {}).get("contextual_consumer_eligibility")
        or {}
    ).get("regime")
    admitted, permission = contextual_decision_input(market, REGIME_TO_SECTOR)
    if admitted is not None or not isinstance(frozen, dict) or frozen.get("included") is not False:
        return False
    return all(
        CanonicalEvidenceSerializer.dumps(frozen.get(key))
        == CanonicalEvidenceSerializer.dumps(permission.get(key))
        for key in ("included", "decision", "producer_readiness")
    )


def _temporal_artifact_matches(
    row: TechnicalScore | MarketRegimeSnapshot | SectorRotationSnapshot,
    market_cutoff: MarketCalculationCutoff,
    upload_run_id: int,
) -> bool:
    return bool(
        row.run_id == upload_run_id
        and row.calculation_context_id == market_cutoff.context_id
        and _canonical_time(row.calculation_cutoff_at) == _canonical_time(market_cutoff.cutoff_at)
        and row.input_as_of_session == market_cutoff.latest_completed_session
        and row.calendar_version == market_cutoff.calendar_version
    )


def _market_context_payload(market_cutoff: MarketCalculationCutoff) -> dict[str, Any]:
    return {
        "id": market_cutoff.context_id,
        "cutoff_at": market_cutoff.cutoff_at,
        "exchange_timezone": market_cutoff.exchange_timezone,
        "latest_completed_session": market_cutoff.latest_completed_session,
        "daily_bar_ready_at": market_cutoff.daily_bar_ready_at,
        "calendar_version": market_cutoff.calendar_version,
        "bar_readiness_version": market_cutoff.bar_readiness_version,
        "cutoff_reason": market_cutoff.cutoff_reason,
    }


def _semantic_model_payload(row: Any) -> dict[str, Any]:
    excluded = {"created_at", "updated_at", "last_seen_at", "calculated_at"}
    return {
        column.name: getattr(row, column.name, None)
        for column in row.__table__.columns
        if column.name not in excluded
    }


def _artifact_identity(row: Any | None, *, checkpoint_callback=None) -> dict[str, Any] | None:
    if row is None or checkpoint_callback is None:
        return handoff_artifact_identity(row)
    from app.services.sector_serialization import sector_hash_progress

    return {
        "id": getattr(row, "id", None),
        "semantic_hash": CanonicalEvidenceSerializer.fingerprint_streaming(
            _semantic_model_payload(row),
            progress_callback=sector_hash_progress(
                _handoff_hash_checkpoint(checkpoint_callback),
                f"artifact:{type(row).__name__}:{row.id}",
            ),
        ),
    }


def _handoff_hash_checkpoint(checkpoint_callback):
    if checkpoint_callback is None:
        return None

    def checkpoint(*, current_item, last_completed_item, **_metrics):
        # The label carries a strictly advancing count of bytes actually hashed.
        # The pipeline callback has no metrics argument; don't discard progress
        # or accidentally pass Sector-writer-only keyword arguments through it.
        checkpoint_callback(
            phase="HANDOFF_EVIDENCE_HASHED",
            processed=0,
            total=1,
            current_item=current_item,
            last_completed_item=last_completed_item,
        )

    return checkpoint


def _canonical_time(value: datetime | None) -> Any:
    return CanonicalEvidenceSerializer.canonicalize(value) if value is not None else None


def _run_start_candidate_dict(row: TransitionCandidateResult) -> dict[str, object]:
    payload = row.as_dict()
    payload.pop("decision_manifest", None)
    payload.pop("decision_manifest_fingerprint", None)
    return payload


def _aggregate_classification(results: list[TransitionCandidateResult]) -> str:
    for classification in ("HIGH", "MEDIUM", "LOW"):
        if any(row.confidence == classification for row in results):
            return classification
    return "LOW"


def _aggregate_technical_fingerprint(results: list[TransitionCandidateResult]) -> str:
    payload = [
        (row.ticker, row.technical_reconstruction_fingerprint)
        for row in sorted(results, key=lambda item: item.ticker)
    ]
    return CanonicalEvidenceSerializer.fingerprint(payload)


def _rejection(
    plan: TransitionPreflightPlan,
    *,
    code: str,
    category: str,
    message: str,
    expected_fingerprint: str | None = None,
    actual_fingerprint: str | None = None,
) -> TransitionPreflightError:
    logger.warning(
        "transition_preflight_rejected code=%s category=%s plan_id=%s context_id=%s "
        "upload_run_id=%s pipeline_id=%s candidate_type=%s selection_keys=%s "
        "expected_fingerprint=%s actual_fingerprint=%s",
        code,
        category,
        plan.id,
        plan.market_calculation_context_id,
        plan.upload_run_id,
        plan.pipeline_run_id,
        plan.candidate_classification,
        ",".join(plan.selection_keys_json),
        expected_fingerprint,
        actual_fingerprint,
    )
    return TransitionPreflightError(code, message)


def _aware(value: datetime) -> datetime:
    if value.tzinfo is None or value.utcoffset() is None:
        raise TransitionPreflightError(
            "INVARIANT_VIOLATION", "preflight timestamps must be timezone-aware"
        )
    return value


def _utcnow() -> datetime:
    return datetime.now(UTC)
