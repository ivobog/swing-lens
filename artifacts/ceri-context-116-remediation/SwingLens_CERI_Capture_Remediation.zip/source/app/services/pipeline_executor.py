from __future__ import annotations

import logging
from collections.abc import Callable
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field, replace
from datetime import UTC, datetime
from decimal import Decimal
from inspect import Parameter, signature
from time import perf_counter
from typing import TYPE_CHECKING, Any

from sqlalchemy import distinct, func, select
from sqlalchemy.orm import Session

from app.models.tables import (
    BackgroundJob,
    CombinedResult,
    CoreCalculationEvidence,
    FundamentalScore,
    IBFetchItem,
    IBFetchRun,
    MarketCalculationContext,
    MarketRegimeSnapshot,
    PipelineRun,
    PipelineStep,
    RankingResult,
    RawCompanyRow,
    SectorRotationSnapshot,
    TechnicalScore,
    TransitionDecisionHandoffManifest,
    UploadRun,
    WorkScopeRecord,
)
from app.observability.logging import log_event
from app.observability.transaction_metrics import publish_after_commit
from app.services.background_job_service import JobLeaseLost, enqueue_job
from app.services.bar_cache_service import DEFAULT_WHAT_TO_SHOW
from app.services.calculation_identity import CalculationIdentity, IdentityState
from app.services.canonical_evidence import CanonicalEvidenceSerializer
from app.services.ceri.constants import (
    CERI_PIPELINE_CAPTURE_STEP,
    CERI_PIPELINE_PROVIDER_INGEST_STEP,
)
from app.services.ceri.feature_flags import ceri_flags
from app.services.ceri.job_handlers import CERI_PROVIDER_INGEST
from app.services.ceri.sec.pipeline_preflight import validate_sec_pipeline_preflight
from app.services.combined_decision import refresh_combined_results
from app.services.configuration_delivery import pipeline_configuration_delivery
from app.services.core_calculation_evidence import (
    CoreEvidenceKind,
    EvidenceUnavailableError,
    calculation_evidence_payload,
    get_certified_evidence_for_row,
)
from app.services.decision_handoff_contract import (
    REQUIRED_HANDOFF_CONTEXT_ARTIFACTS,
    RequiredHandoffArtifactError,
    RequiredHandoffContextArtifact,
    validate_required_handoff_context_artifact,
)
from app.services.domain_write_fence import ControlPlaneLockTimeout
from app.services.fundamental_score_service import recalculate_run_fundamentals
from app.services.ib_fetch_executor import execute_fetch_plan
from app.services.ib_fetch_job_service import (
    IB_FETCH_JOB_TYPE,
    FetchJobOptions,
    _admit_fetch_authority,
    _subset_fetch_plan,
)
from app.services.ib_fetch_plan_service import (
    FetchAction,
    FetchPlan,
    build_fetch_plan,
    fetch_plan_from_dict,
    fetch_plan_to_dict,
)
from app.services.ib_gateway_health_service import (
    IBGatewayHealthStatus,
    is_api_ready_status,
)
from app.services.ib_gateway_health_service import (
    check_status as check_ib_gateway_status,
)
from app.services.ib_historical_capability import (
    IBHistoricalCapabilityStatus,
    check_historical_data_capability,
)
from app.services.market_calculation_context_service import market_context_for_pipeline
from app.services.market_clock_service import MarketCalculationCutoff
from app.services.market_data_availability_policy import (
    availability_diagnostics,
    fetch_execution_hazards,
    hard_readiness_blockers,
    pipeline_availability_policy,
    processing_tickers,
    required_dependency,
)
from app.services.market_data_prewarm_service import (
    record_pipeline_prewarm_reuse,
    resolve_pipeline_prewarm_context,
)
from app.services.market_data_session_readiness import (
    MarketDataDisposition,
    evaluate_and_persist_session_readiness,
    load_current_session_readiness,
)
from app.services.market_regime_command_center import MarketRegimeCommandCenterService
from app.services.market_regime_dtos import MarketRegimeCommandCenterDto
from app.services.operational_metrics import operational_metrics
from app.services.pipeline_performance import PipelinePerformanceTracker
from app.services.pipeline_prerequisites import (
    CeriBootstrapRequiredError,
    IBHistoricalCircuitOpenError,
    IBHistoricalDataUnavailableError,
    PipelineBlockedError,
)
from app.services.pipeline_service import (
    DECISION_HANDOFF_PIPELINE_STEP,
    MarketDataPolicy,
    PipelineStatus,
    PipelineStepStatus,
)
from app.services.pipeline_stage_registry import WINNER_CAPTURE_PIPELINE_STEP
from app.services.ranking_profile_service import (
    RankingPipelineResult,
    execute_ranking_pipeline_step,
)
from app.services.redaction import redact_sensitive
from app.services.scope_refresh_adoption import (
    SemanticWorkAuthority,
    bind_semantic_authority,
    require_semantic_authority,
)
from app.services.sector_rotation_dtos import SectorRotationSnapshotDto
from app.services.sector_rotation_service import SectorRotationService
from app.services.setup_lifecycle.constants import (
    SLSE_PIPELINE_CAPTURE_STEP,
    SLSE_PIPELINE_EVALUATION_STEP,
)
from app.services.technical_score_service import (
    TechnicalScoringError,
    TechnicalScoringOverlapCoordinator,
    score_run_technicals,
)
from app.services.us_market_calendar import latest_completed_us_trading_day
from app.settings import get_settings

logger = logging.getLogger(__name__)


class PipelineCancelled(Exception):
    pass


def close_pipeline_read_transaction(db: Session) -> bool:
    """Release a completed read phase before long CPU-only pipeline work.

    Frozen source rows must remain resident after the commit, so expiration is
    disabled only for this boundary. Refuse to checkpoint across pending domain
    mutations or a writer savepoint; those remain owned by their stage.
    """

    if not isinstance(db, Session) or not db.in_transaction():
        return False
    if db.in_nested_transaction() or db.new or db.dirty or db.deleted:
        raise RuntimeError("PIPELINE_READ_CHECKPOINT_REQUIRES_CLEAN_SESSION")
    expire_on_commit = db.expire_on_commit
    db.expire_on_commit = False
    try:
        db.commit()
    finally:
        db.expire_on_commit = expire_on_commit
    return True


def commit_pipeline_mutation_checkpoint(db: Session) -> bool:
    """Commit one completed, authority-validated pipeline mutation batch.

    Callers must invoke this only after the semantic writer has returned and
    flushed its complete batch.  Pending ORM state or a live writer savepoint
    means the batch is not a safe durable checkpoint and is rejected.
    """

    if not isinstance(db, Session) or not db.in_transaction():
        return False
    if db.in_nested_transaction() or db.new or db.dirty or db.deleted:
        raise RuntimeError("PIPELINE_MUTATION_CHECKPOINT_REQUIRES_FLUSHED_BATCH")
    expire_on_commit = db.expire_on_commit
    db.expire_on_commit = False
    try:
        db.commit()
    finally:
        db.expire_on_commit = expire_on_commit
    return True


class PipelineContinuationSuppressed(Exception):
    """A durable continuation lost authority before its resume transition."""

    def __init__(self, pipeline_id: int, status: str) -> None:
        self.pipeline_id = int(pipeline_id)
        self.status = str(status)
        super().__init__(f"PIPELINE_CONTINUATION_SUPPRESSED:pipeline={pipeline_id}:status={status}")


class IBGatewayUnavailable(Exception):
    code = "IB_GATEWAY_UNAVAILABLE"


def _call_market_sensitive(
    function: Callable[..., Any],
    db: Session,
    run_id: int,
    market_cutoff: MarketCalculationCutoff,
    *,
    pipeline_run_id: int | None = None,
    frozen_tickers: tuple[str, ...] | None = None,
    should_cancel: Callable[[], bool] | None = None,
    checkpoint_callback: Callable[..., None] | None = None,
) -> Any:
    """Pass the frozen cutoff without breaking narrow test doubles."""
    parameters = signature(function).parameters
    accepts_kwargs = any(item.kind is Parameter.VAR_KEYWORD for item in parameters.values())
    kwargs: dict[str, Any] = {}
    if "market_cutoff" in parameters or accepts_kwargs:
        kwargs["market_cutoff"] = market_cutoff
    if pipeline_run_id is not None and ("pipeline_run_id" in parameters or accepts_kwargs):
        kwargs["pipeline_run_id"] = pipeline_run_id
    if frozen_tickers is not None and ("frozen_tickers" in parameters or accepts_kwargs):
        kwargs["frozen_tickers"] = frozen_tickers
    if should_cancel is not None and ("should_cancel" in parameters or accepts_kwargs):
        kwargs["should_cancel"] = should_cancel
    if checkpoint_callback is not None and ("checkpoint_callback" in parameters or accepts_kwargs):
        kwargs["checkpoint_callback"] = checkpoint_callback
    if "effective_configuration" in parameters:
        from app.services.configuration_delivery import delivered_configuration
        from app.services.core_effective_configuration import CoreEffectiveConfiguration

        namespace = {
            "recalculate_run_fundamentals": "core.fundamental",
            "score_run_technicals": "core.technical",
            "refresh_combined_results": "core.combined",
        }.get(function.__name__)
        if namespace is not None:
            frozen = delivered_configuration(namespace)
            if frozen is None and isinstance(db, Session):
                raise ValueError("PIPELINE_FROZEN_WRITER_CONFIGURATION_REQUIRED")
            if frozen is not None:
                kwargs["effective_configuration"] = CoreEffectiveConfiguration(frozen.snapshot)
    if "source_evidence" in parameters and isinstance(db, Session):
        from sqlalchemy import select

        from app.models.tables import FundamentalScore, TechnicalScore
        from app.services.pipeline_partial_results import filter_pipeline_rows

        pins: dict[str, dict[str, int]] = {}
        for role, model in (("fundamental", FundamentalScore), ("technical", TechnicalScore)):
            sources = list(db.scalars(select(model).where(model.run_id == run_id)))
            for source in filter_pipeline_rows(db, sources, pipeline_run_id):
                if source.evidence_id is None:
                    raise ValueError("PIPELINE_CERTIFIED_SOURCE_REQUIRED: " + role)
                pins.setdefault(source.ticker.upper(), {})[role] = source.evidence_id
        kwargs["source_evidence"] = pins
    if kwargs:
        return function(db, run_id, **kwargs)
    return function(db, run_id)


def build_market_regime_snapshot_for_run(
    db: Session,
    run_id: int,
    *,
    market_cutoff: MarketCalculationCutoff | None = None,
) -> MarketRegimeCommandCenterDto:
    return MarketRegimeCommandCenterService().build_snapshot(
        db, run_id=run_id, market_cutoff=market_cutoff
    )


def build_sector_rotation_snapshot_for_run(
    db: Session,
    run_id: int,
    *,
    market_cutoff: MarketCalculationCutoff | None = None,
    checkpoint_callback: Callable[..., None] | None = None,
) -> SectorRotationSnapshotDto:
    return SectorRotationService().build_sector_rotation_snapshot(
        db,
        run_id=run_id,
        market_cutoff=market_cutoff,
        checkpoint_callback=checkpoint_callback,
    )


@dataclass(frozen=True)
class PipelineExecutionResult:
    pipeline_run_id: int
    upload_run_id: int
    status: str
    uploaded_rows: int
    fundamental_scores: int
    ib_planned_requests: int
    ib_executed_requests: int
    ib_success_count: int
    ib_failure_count: int
    ib_skipped_count: int
    technical_scores: int
    market_regime_snapshots: int
    market_regime: str | None
    market_risk_state: str | None
    market_regime_confidence: str | None
    market_regime_warning_count: int
    combined_results: int
    ranking_profiles: int
    ranking_results: int
    ranking_status: str
    ranking_reason: str | None
    sector_rotation_snapshots: int
    sector_rotation_sector_count: int
    sector_rotation_leading_sector: str | None
    sector_rotation_weakest_sector: str | None
    sector_rotation_warning_count: int
    ceri_score_snapshots: int
    ceri_change_events: int
    ceri_alerts: int
    ceri_unrated: int
    ceri_quarantined: int
    ceri_conflicted: int
    ceri_stale: int
    ceri_failed: int
    ceri_capture_skipped: int
    setup_lifecycle_snapshots_captured: int
    setup_lifecycle_canonical_snapshots: int
    setup_lifecycle_change_events: int
    setup_lifecycle_transitions: int
    setup_lifecycle_alerts: int
    setup_lifecycle_active_episodes: int
    setup_lifecycle_low_confidence: int
    setup_lifecycle_failed: int
    setup_lifecycle_capture_skipped: int
    setup_lifecycle_evaluation_skipped: int
    winner_prediction_inserted: int
    winner_prediction_duplicate: int
    winner_prediction_excluded: int
    winner_prediction_failed: int
    winner_prediction_pending_outcomes: int
    winner_prediction_decision_time_estimates: int
    winner_prediction_capture_skipped: int
    incomplete_rows: int
    warning_rows: int
    performance: dict[str, Any] = field(default_factory=dict)
    sec_coverage: dict[str, Any] | None = None
    sec_unresolved_count: int = 0
    sec_unresolved_tickers: list[dict[str, Any]] = field(default_factory=list)
    pipeline_outcome_summary: dict[str, Any] | None = None


@dataclass(frozen=True)
class PipelineExecutionDependencies:
    market_cutoff: MarketCalculationCutoff | None = None
    validate_pipeline_preflight: Callable[[Session, list[str]], dict[str, Any]] | None = None
    schedule_sec_readiness_repair: Callable[..., Any] | None = None
    validate_resume_checkpoint: Callable[[Session, int, str], dict[str, Any]] | None = None
    validate_sector_resume_checkpoint: Callable[..., dict[str, Any]] | None = None
    recalculate_fundamentals: Callable[[Session, int], list[Any]] = recalculate_run_fundamentals
    build_fetch_plan: Callable[..., FetchPlan] = build_fetch_plan
    execute_fetch_plan: Callable[..., IBFetchRun] = execute_fetch_plan
    score_technicals: Callable[[Session, int], list[Any]] = score_run_technicals
    build_market_regime_snapshot: Callable[[Session, int], MarketRegimeCommandCenterDto] = (
        build_market_regime_snapshot_for_run
    )
    refresh_combined: Callable[[Session, int], list[CombinedResult]] = refresh_combined_results
    refresh_rankings: Callable[[Session, int], RankingPipelineResult] = (
        execute_ranking_pipeline_step
    )
    build_sector_rotation_snapshot: Callable[[Session, int], SectorRotationSnapshotDto] = (
        build_sector_rotation_snapshot_for_run
    )
    freeze_decision_handoff: Callable[..., Any] | None = None
    capture_ceri_snapshot: Callable[[Session, int], Any] | None = None
    ceri_run_capture_enabled: bool | None = None
    ceri_provider_ingest_enabled: bool | None = None
    schedule_ceri_provider_ingest: Callable[[Session, int], Any] | None = None
    capture_setup_signals: Callable[[Session, int], Any] | None = None
    evaluate_setup_lifecycles: Callable[[Session, int], Any] | None = None
    setup_lifecycle_pipeline_step_enabled: bool | None = None
    setup_capture_handoff_enabled: bool | None = None
    fetch_technical_overlap_enabled: bool | None = None
    capture_winner_predictions: Callable[..., Any] | None = None
    winner_probability_capture_enabled: bool | None = None
    check_ib_gateway: Callable[[], IBGatewayHealthStatus] = check_ib_gateway_status
    check_ib_historical_capability: Callable[..., IBHistoricalCapabilityStatus] = (
        check_historical_data_capability
    )


@pipeline_configuration_delivery
def execute_full_pipeline(
    db: Session,
    pipeline_run_id: int,
    should_cancel: Callable[[], bool] | None = None,
    lease_guard: Callable[[], None] | None = None,
    dependencies: PipelineExecutionDependencies | None = None,
    resume_from_step: str | None = None,
    progress_callback: Callable[..., None] | None = None,
    memory_probe: Callable[..., None] | None = None,
    execution_token: str | None = None,
    execution_job_id: int | None = None,
) -> PipelineExecutionResult:
    dependencies = dependencies or PipelineExecutionDependencies()
    from app.services.configuration_delivery import current_delivery, delivered_configuration

    if isinstance(db, Session) and current_delivery() is not None:
        frozen_flags = delivered_configuration("execution.settings").values
        expected_flags = {
            "ceri_run_capture_enabled": frozen_flags["ceri_enabled"]
            and frozen_flags["ceri_run_capture_enabled"],
            "ceri_provider_ingest_enabled": frozen_flags["ceri_enabled"]
            and frozen_flags["ceri_provider_ingest_enabled"],
            "setup_lifecycle_pipeline_step_enabled": frozen_flags[
                "setup_lifecycle_pipeline_step_enabled"
            ],
            "setup_capture_handoff_enabled": frozen_flags["setup_capture_handoff_enabled"],
            "winner_probability_capture_enabled": (
                frozen_flags["winner_probability_enabled"]
                and frozen_flags["winner_probability_capture_in_pipeline"]
            ),
        }
        for name, expected in expected_flags.items():
            supplied = getattr(dependencies, name)
            if supplied is not None and supplied != expected:
                raise ValueError("PIPELINE_CONFIGURATION_FLAG_ANCHOR_MISMATCH: " + name)
    pipeline = _claim_pipeline_continuation_resume(db, _require_pipeline(db, pipeline_run_id))
    market_cutoff = dependencies.market_cutoff or market_context_for_pipeline(db, pipeline)
    if dependencies.market_cutoff is None:
        dependencies = replace(dependencies, market_cutoff=market_cutoff)
    pipeline._job_progress_callback = progress_callback
    upload_run = _require_upload_run(db, pipeline.upload_run_id)
    if resume_from_step not in {None, "VALIDATING_RUN", "FETCHING_MARKET_DATA"}:
        return _execute_resumed_pipeline(
            db,
            pipeline=pipeline,
            upload_run=upload_run,
            resume_from_step=resume_from_step,
            should_cancel=should_cancel or (lambda: False),
            lease_guard=lease_guard,
            dependencies=dependencies,
            progress_callback=progress_callback,
            memory_probe=memory_probe,
            execution_token=execution_token,
        )
    should_cancel = should_cancel or (lambda: False)
    performance = PipelinePerformanceTracker()
    cache_hits_before = operational_metrics.total(
        "swinglens_technical_artifact_cache_total", result="hit"
    )
    cache_misses_before = operational_metrics.total(
        "swinglens_technical_artifact_cache_total", result="miss"
    )
    cache_shadow_candidates_before = operational_metrics.total(
        "swinglens_technical_artifact_cache_total", result="shadow_candidate"
    )
    cache_shadow_misses_before = operational_metrics.total(
        "swinglens_technical_artifact_cache_total", result="shadow_miss"
    )
    cache_shadow_validations_before = operational_metrics.total(
        "swinglens_technical_artifact_cache_shadow_validations_total"
    )
    cache_shadow_mismatches_before = operational_metrics.total(
        "swinglens_technical_artifact_cache_shadow_validations_total",
        result="mismatch",
    )
    technical_durations_before = {
        name: operational_metrics.total(f"swinglens_technical_{name}_seconds")
        for name in ("input_load", "worker_span", "finalize")
    }

    result = _empty_result(pipeline, upload_run)
    recovering_market_data = resume_from_step == "FETCHING_MARKET_DATA"
    if recovering_market_data:
        pipeline = _claim_pipeline_continuation_resume(db, pipeline)
        result.update(_public_result(pipeline.result_json or {}))
        result.update(blocked_reason=None, blocked_diagnostics=None, failure_reason=None,
                      resumed_from_step=resume_from_step)
    market_data_policy = _market_data_policy(pipeline)
    availability_policy = pipeline_availability_policy(pipeline)
    result["market_data_policy"] = market_data_policy.value
    overlap_coordinator: TechnicalScoringOverlapCoordinator | None = None
    try:
        _mark_pipeline_running(db, pipeline, lease_guard=lease_guard)
        performance.set_metric(
            "pipeline_queue_delay_ms",
            _duration_ms(pipeline.created_at, pipeline.started_at),
        )
        _raise_if_cancelled(should_cancel)

        tickers = _pipeline_scope_tickers(db, pipeline)
        if recovering_market_data:
            result["market_data_resume_checkpoint"] = _validate_market_data_resume(
                db, pipeline, tickers, market_cutoff
            )
        else:
            with _pipeline_step(
                db,
                pipeline,
                "VALIDATING_RUN",
                lease_guard=lease_guard,
                performance=performance,
            ):
                tickers = _pipeline_scope_tickers(db, pipeline)
                if not tickers:
                    raise ValueError("No uploaded tickers are available for this run.")
                result["uploaded_rows"] = (
                    len(result["partial_scope"]["requested_tickers"])
                    if result.get("partial_scope")
                    else upload_run.row_count or len(tickers)
                )
                if _ceri_provider_ingest_enabled(dependencies):
                    validate = dependencies.validate_pipeline_preflight
                    result["sec_preflight"] = (
                        validate(db, tickers)
                        if validate is not None
                        else validate_sec_pipeline_preflight(db, tickers=tickers, pipeline=pipeline)
                    )
                    _retain_sec_preflight_coverage(result)

            _raise_if_cancelled(should_cancel)
            with _pipeline_step(
                db,
                pipeline,
                "SCORING_FUNDAMENTALS",
                lease_guard=lease_guard,
                performance=performance,
            ):
                fundamental_scores = _call_market_sensitive(
                    dependencies.recalculate_fundamentals,
                    db,
                    upload_run.id,
                    market_cutoff,
                    pipeline_run_id=pipeline.id,
                )
                result["fundamental_scores"] = len(fundamental_scores)
            # The step has committed. Later stages load their exact sealed
            # inputs; retaining the producer ORM cohort only increases residency.
            del fundamental_scores

        sector_checkpoint = _sector_checkpoint_callback(
            db,
            should_cancel=should_cancel,
            progress_callback=progress_callback,
        )
        _raise_if_cancelled(should_cancel)
        with _pipeline_step(
            db,
            pipeline,
            "FETCHING_MARKET_DATA",
            lease_guard=lease_guard,
            performance=performance,
        ):
            ib_health = dependencies.check_ib_gateway()
            _apply_ib_execution_status(result, ib_health)
            if market_data_policy is MarketDataPolicy.REQUIRE_IB and not is_api_ready_status(
                ib_health
            ):
                result["failure_reason"] = IBGatewayUnavailable.code
                result["market_data_mode"] = "BLOCKED"
                raise IBGatewayUnavailable(f"{IBGatewayUnavailable.code}: {ib_health.message}")
            cache_fallback = not is_api_ready_status(ib_health)
            if cache_fallback:
                result["market_data_mode"] = "CACHE_FALLBACK"
                result["degraded"] = True
            else:
                result["market_data_mode"] = "IB_GATEWAY"
            retained_plan = (pipeline.result_json or {}).get("ib_fetch_plan")
            retained_authority = (pipeline.result_json or {}).get("ib_fetch_authority")
            fetch_authority = None
            if isinstance(db, Session) and isinstance(retained_plan, dict):
                plan = fetch_plan_from_dict(retained_plan)
                if isinstance(retained_authority, dict):
                    fetch_authority = SemanticWorkAuthority(**retained_authority)
                else:
                    # Some interrupted pre-T15B checkpoints retained the exact
                    # immutable FetchPlan but not its child authority references.
                    # Re-admit only from that retained plan; never query current
                    # coverage or membership to fabricate the stage scope.
                    fetch_authority = _admit_fetch_authority(
                        db,
                        plan,
                        FetchJobOptions(include_benchmarks=True),
                        parent_scope_id=require_semantic_authority(pipeline).scope_id,
                    )
                    pipeline.result_json = {
                        **(pipeline.result_json or {}),
                        "ib_fetch_authority": fetch_authority.as_dict(),
                    }
            else:
                plan_kwargs = dict(
                    db=db, tickers=tickers, run_id=upload_run.id,
                    include_benchmarks=True, what_to_show_values=DEFAULT_WHAT_TO_SHOW,
                )
                if _accepts_keyword(dependencies.build_fetch_plan, "allow_history_gaps"):
                    plan_kwargs["allow_history_gaps"] = availability_policy.allow_history_gaps
                elif availability_policy.allow_history_gaps:
                    raise ValueError("MARKET_DATA_GAP_AWARE_PLANNER_REQUIRED")
                plan = dependencies.build_fetch_plan(**plan_kwargs)
                first_admission = (
                    recovering_market_data
                    and result["market_data_resume_checkpoint"].get("fetch_plan_state")
                    == "NOT_ADMITTED"
                )
                if first_admission:
                    _validate_first_market_data_plan(plan, pipeline, tickers, market_cutoff)
                    # Recheck durable absence immediately before admission. A
                    # missing checkpoint must never become a replacement plan.
                    _validate_unstarted_market_data_resume(db, pipeline, tickers, market_cutoff)
                if isinstance(db, Session):
                    fetch_authority = _admit_fetch_authority(
                        db,
                        plan,
                        FetchJobOptions(include_benchmarks=True),
                        parent_scope_id=require_semantic_authority(pipeline).scope_id,
                    )
                    pipeline.result_json = {
                        **(pipeline.result_json or {}),
                        "ib_fetch_plan": fetch_plan_to_dict(plan),
                        "ib_fetch_authority": fetch_authority.as_dict(),
                    }
                    if first_admission:
                        admitted_checkpoint = {
                            **result["market_data_resume_checkpoint"],
                            "first_plan_admitted": True,
                        }
                        pipeline.result_json = {
                            **pipeline.result_json,
                            "market_data_resume_checkpoint": admitted_checkpoint,
                        }
                        # Admission is durable before auxiliary lookups or broker
                        # coordination. A rollback must leave the local result
                        # unadmitted so failure reporting cannot invent a commit.
                        _save_progress(db, lease_guard=lease_guard)
                if first_admission:
                    result["market_data_resume_checkpoint"]["first_plan_admitted"] = True
            prewarm_context = resolve_pipeline_prewarm_context(db, tickers)
            prewarm_skipped_tickers = {
                ticker
                for ticker in prewarm_context.covered_tickers
                if _plan_skips_ticker(plan, ticker)
            }
            prewarm_reused_tickers = sorted(
                prewarm_skipped_tickers.intersection(prewarm_context.fetched_tickers)
            )
            performance.set_metric("prewarm_age_seconds", prewarm_context.age_seconds)
            performance.set_metric(
                "prewarm_covered_tickers",
                len(prewarm_context.covered_tickers),
            )
            performance.set_metric(
                "prewarm_reused_tickers",
                len(prewarm_reused_tickers),
            )
            performance.set_metric("prewarm_job_id", prewarm_context.job_id)
            if prewarm_context.job_id is not None:
                record_pipeline_prewarm_reuse(
                    db,
                    prewarm_context,
                    pipeline_run_id=pipeline.id,
                    reused_tickers=prewarm_reused_tickers,
                )
            result["ib_planned_requests"] = plan.estimated_request_count
            _apply_market_session_metadata(result, plan)
            if plan.estimated_request_count and not cache_fallback:
                capability_check = dependencies.check_ib_historical_capability
                from app.services.ib_acquisition_gate import coordinate_fetch

                @coordinate_fetch
                def probe(
                    db, plan, should_cancel, progress_callback, execution_token, execution_job_id
                ):
                    return (
                        capability_check(fetch_plan=plan)
                        if _accepts_keyword(capability_check, "fetch_plan")
                        else capability_check()
                    )

                historical_capability = probe(
                    db, plan, should_cancel, progress_callback, execution_token, execution_job_id
                )
                capability_payload = _historical_capability_payload(historical_capability)
                result["ib_historical_capability"] = capability_payload
                if not _is_historical_data_ready(historical_capability):
                    result["failure_reason"] = IBHistoricalDataUnavailableError.reason_code
                    if market_data_policy is MarketDataPolicy.REQUIRE_IB:
                        result["market_data_mode"] = "BLOCKED"
                        raise IBHistoricalDataUnavailableError(
                            historical_capability.message,
                            diagnostics=capability_payload,
                        )
                    cache_fallback = True
                    result["market_data_mode"] = "CACHE_FALLBACK"
                    result["degraded"] = True
            if _fetch_technical_overlap_enabled(dependencies):
                # Scoring may not begin from a per-ticker fetch callback. The
                # complete requested universe must first receive a durable
                # ticker/session disposition at the explicit readiness boundary.
                performance.add_fallback("technical_overlap_readiness_boundary")
                operational_metrics.increment(
                    "swinglens_pipeline_optimized_fallback_total",
                    component="technical_overlap",
                    reason="readiness_boundary",
                )
            fetch_run = None
            if plan.estimated_request_count and not cache_fallback:
                resumable_fetch_run_id = db.scalar(
                    select(IBFetchRun.id)
                    .where(IBFetchRun.run_id == upload_run.id)
                    .where(IBFetchRun.status.in_(("RUNNING", "PARTIAL", "FAILED")))
                    .where(
                        IBFetchRun.scope_id
                        == (fetch_authority.scope_id if fetch_authority is not None else None)
                    )
                    .where(
                        IBFetchRun.refresh_cycle_id
                        == (
                            fetch_authority.refresh_cycle_id
                            if fetch_authority is not None
                            else None
                        )
                    )
                    .where(
                        IBFetchRun.acquisition_plan_id
                        == (
                            fetch_authority.acquisition_plan_id
                            if fetch_authority is not None
                            else None
                        )
                    )
                    .order_by(IBFetchRun.id.desc())
                    .limit(1)
                )
                if recovering_market_data and resumable_fetch_run_id is not None:
                    # New attempt rows retain the original provider failures unchanged.
                    failed_keys = {
                        (item.ticker, item.what_to_show)
                        for item in db.scalars(
                            select(IBFetchItem).where(
                                IBFetchItem.fetch_run_id == resumable_fetch_run_id,
                                IBFetchItem.status == "FAILED",
                            )
                        )
                    }
                    if failed_keys:
                        plan = _subset_fetch_plan(plan, failed_keys)
                    result["ib_planned_requests"] = plan.estimated_request_count
                    result["market_data_resume_checkpoint"]["previous_fetch_run_id"] = (
                        resumable_fetch_run_id
                    )
                    resumable_fetch_run_id = None
                fetch_kwargs: dict[str, Any] = {
                    "db": db,
                    "plan": plan,
                    "include_benchmarks": True,
                    "should_cancel": should_cancel,
                    "fetch_run_id": resumable_fetch_run_id,
                    "progress_callback": progress_callback,
                    "memory_probe": memory_probe,
                    "execution_token": execution_token,
                }
                if _accepts_keyword(dependencies.execute_fetch_plan, "execution_job_id"):
                    fetch_kwargs["execution_job_id"] = execution_job_id
                if fetch_authority is not None and _accepts_keyword(
                    dependencies.execute_fetch_plan, "semantic_authority"
                ):
                    fetch_kwargs["semantic_authority"] = fetch_authority
                if overlap_coordinator is not None:
                    fetch_kwargs["on_ticker_ready"] = overlap_coordinator.on_ticker_ready
                fetch_run = dependencies.execute_fetch_plan(**fetch_kwargs)
                # This dictionary can own a bound coordinator callback and its
                # complete technical working set after fetching has finished.
                del fetch_kwargs
                if fetch_authority is not None:
                    bind_semantic_authority(fetch_run, fetch_authority)
                _apply_fetch_result(result, fetch_run)
                _apply_fetch_performance(performance, fetch_run)
                if fetch_run.status == "CANCELLED":
                    raise PipelineCancelled("Pipeline cancelled during market data fetch.")
                circuit = (fetch_run.decision_counts_json or {}).get("historical_circuit")
                if circuit:
                    result["failure_reason"] = IBHistoricalCircuitOpenError.reason_code
                    raise IBHistoricalCircuitOpenError(
                        fetch_run.message or "IB historical benchmark circuit opened.",
                        diagnostics=dict(circuit),
                    )
            else:
                result["ib_skipped_count"] = plan.estimated_skips
                if cache_fallback:
                    result["cache_used_count"] = _cached_ticker_count(plan)
            if overlap_coordinator is not None:
                overlap_coordinator.mark_fetch_complete()

            if isinstance(db, Session):
                if availability_policy.allow_history_gaps:
                    _require_market_data_dependencies(db, pipeline, plan, fetch_run, market_cutoff)
                readiness = evaluate_and_persist_session_readiness(
                    db,
                    pipeline_run_id=pipeline.id,
                    upload_run_id=upload_run.id,
                    tickers=tickers,
                    market_cutoff=market_cutoff,
                    fetch_run_id=fetch_run.id if fetch_run is not None else None,
                )
                result["market_data_session_readiness"] = readiness.as_dict()
                availability = availability_diagnostics(readiness.rows, availability_policy)
                result["market_data_availability"] = availability
                result["market_data_unavailable_count"] = len(availability["unavailable_tickers"])
                result["market_data_history_gap_count"] = len(availability["history_gap_tickers"])
                step = _require_step(db, pipeline.id, "FETCHING_MARKET_DATA")
                step.result_json = readiness.as_dict()
                if readiness.accepted_inactive_tickers:
                    step.message = "Accepted explicit terminal exclusions: " + ", ".join(
                        readiness.accepted_inactive_tickers
                    )
                hard_blockers = hard_readiness_blockers(readiness.rows, availability_policy)
                if hard_blockers:
                    diagnostics = readiness.as_dict()
                    transient_only = all(
                        row.disposition == MarketDataDisposition.TRANSIENT_FAILURE.value
                        for row in hard_blockers
                    )
                    reason_code = (
                        "MARKET_DATA_TRANSIENT_UNRESOLVED"
                        if transient_only
                        else "MARKET_DATA_SESSION_READINESS_BLOCKED"
                    )
                    raise PipelineBlockedError(
                        f"{reason_code}: "
                        + ",".join(
                            f"{row.ticker}={row.disposition}:{row.reason_code}"
                            for row in hard_blockers
                        ),
                        reason_code=reason_code,
                        diagnostics=diagnostics,
                    )
                technical_tickers = processing_tickers(readiness.rows, availability_policy)
                downstream_tickers = technical_tickers
            else:
                technical_tickers = tuple(tickers)
                downstream_tickers = tuple(tickers)

        del plan, fetch_run
        _raise_if_cancelled(should_cancel)
        with _pipeline_step(
            db,
            pipeline,
            "SCORING_TECHNICALS",
            lease_guard=lease_guard,
            performance=performance,
        ):
            if overlap_coordinator is not None:
                try:
                    technical_scores = overlap_coordinator.finalize()
                except TechnicalScoringError as exc:
                    if should_cancel():
                        raise PipelineCancelled(
                            "Pipeline cancelled during overlapped technical scoring."
                        ) from exc
                    raise
                performance.set_metric(
                    "technical_tickers_completed_during_fetch",
                    overlap_coordinator.completed_during_fetch,
                )
                if overlap_coordinator.fallback_reason is not None:
                    performance.add_fallback(
                        f"technical_overlap:{overlap_coordinator.fallback_reason}"
                    )
            else:
                try:
                    technical_scores = _call_market_sensitive(
                        dependencies.score_technicals,
                        db,
                        upload_run.id,
                        market_cutoff,
                        pipeline_run_id=pipeline.id,
                        frozen_tickers=technical_tickers,
                        should_cancel=should_cancel,
                        checkpoint_callback=lambda **progress: _technical_job_checkpoint(
                            db,
                            progress_callback=progress_callback,
                            lease_guard=lease_guard,
                            **progress,
                        ),
                    )
                except TechnicalScoringError as exc:
                    if should_cancel():
                        raise PipelineCancelled(
                            "Pipeline cancelled during technical scoring."
                        ) from exc
                    raise
            if result["market_data_mode"] == "CACHE_FALLBACK":
                _mark_technical_scores_degraded(technical_scores, result)
            performance.set_metric(
                "technical_cache_hits",
                operational_metrics.total("swinglens_technical_artifact_cache_total", result="hit")
                - cache_hits_before,
            )
            performance.set_metric(
                "technical_cache_misses",
                operational_metrics.total("swinglens_technical_artifact_cache_total", result="miss")
                - cache_misses_before,
            )
            performance.set_metric(
                "technical_cache_shadow_candidates",
                operational_metrics.total(
                    "swinglens_technical_artifact_cache_total",
                    result="shadow_candidate",
                )
                - cache_shadow_candidates_before,
            )
            performance.set_metric(
                "technical_cache_shadow_misses",
                operational_metrics.total(
                    "swinglens_technical_artifact_cache_total", result="shadow_miss"
                )
                - cache_shadow_misses_before,
            )
            performance.set_metric(
                "technical_cache_shadow_validations",
                operational_metrics.total(
                    "swinglens_technical_artifact_cache_shadow_validations_total"
                )
                - cache_shadow_validations_before,
            )
            performance.set_metric(
                "technical_cache_shadow_mismatches",
                operational_metrics.total(
                    "swinglens_technical_artifact_cache_shadow_validations_total",
                    result="mismatch",
                )
                - cache_shadow_mismatches_before,
            )
            for metric_name, performance_name in (
                ("input_load", "technical_input_load_ms"),
                ("worker_span", "technical_worker_span_ms"),
                ("finalize", "technical_finalize_ms"),
            ):
                performance.set_metric(
                    performance_name,
                    1000
                    * (
                        operational_metrics.total(f"swinglens_technical_{metric_name}_seconds")
                        - technical_durations_before[metric_name]
                    ),
                )
            settings = get_settings()
            performance.set_metric(
                "technical_worker_processes",
                getattr(settings, "technical_worker_processes", None),
            )
            performance.set_metric(
                "technical_max_in_flight",
                getattr(settings, "technical_max_in_flight", None),
            )
            _raise_if_cancelled(should_cancel)
            result["technical_scores"] = len(technical_scores)
            result["technical_error_count"] = _technical_error_count(technical_scores)

        del technical_scores
        # finalize() has already closed the executor. Its completed artifact and
        # input dictionaries must not remain live through ranking and Sector.
        overlap_coordinator = None

        _raise_if_cancelled(should_cancel)
        with _pipeline_step(
            db,
            pipeline,
            "MARKET_REGIME_SNAPSHOT",
            lease_guard=lease_guard,
            performance=performance,
        ):
            snapshot = _call_market_sensitive(
                dependencies.build_market_regime_snapshot, db, upload_run.id, market_cutoff
            )
            result["market_regime_snapshots"] = 1
            result["market_regime"] = snapshot.regime
            result["market_risk_state"] = snapshot.risk_state
            result["market_regime_confidence"] = snapshot.confidence
            result["market_regime_warning_count"] = len(snapshot.warnings)
            result["market_regime_low_confidence"] = int(snapshot.confidence == "low")
        del snapshot

        _raise_if_cancelled(should_cancel)
        with _pipeline_step(
            db,
            pipeline,
            "COMBINING_RESULTS",
            lease_guard=lease_guard,
            performance=performance,
        ):
            combined_results = _call_market_sensitive(
                dependencies.refresh_combined,
                db,
                upload_run.id,
                market_cutoff,
                pipeline_run_id=pipeline.id,
                checkpoint_callback=lambda **progress: _combined_job_checkpoint(
                    db,
                    progress_callback=progress_callback,
                    lease_guard=lease_guard,
                    **progress,
                ),
            )
            result["combined_results"] = len(combined_results)
            result["incomplete_rows"] = sum(not row.is_complete for row in combined_results)
            result["warning_rows"] = sum(row.has_warning for row in combined_results)
        del combined_results

        _raise_if_cancelled(should_cancel)
        with _pipeline_step(
            db,
            pipeline,
            "RANKING_PROFILES",
            lease_guard=lease_guard,
            performance=performance,
        ) as ranking_step:
            ranking = _call_market_sensitive(
                dependencies.refresh_rankings,
                db,
                upload_run.id,
                market_cutoff,
                pipeline_run_id=pipeline.id,
                checkpoint_callback=_ranking_checkpoint_callback(
                    db,
                    should_cancel=should_cancel,
                    progress_callback=progress_callback,
                    lease_guard=lease_guard,
                ),
            )
            result["ranking_profiles"] = ranking.profile_count
            result["ranking_results"] = ranking.result_count
            result["ranking_status"] = ranking.status
            result["ranking_reason"] = ranking.reason
            if ranking.status == PipelineStepStatus.SKIPPED:
                ranking_step.status = PipelineStepStatus.SKIPPED
                ranking_step.message = ranking.reason
            else:
                ranking_step.message = (
                    f"Persisted {ranking.result_count} ranking results across "
                    f"{ranking.profile_count} profiles."
                )
            publish_after_commit(
                db,
                "increment",
                "swinglens_ranking_pipeline_runs_total",
                status=ranking.status,
            )
            publish_after_commit(
                db,
                "increment",
                "swinglens_ranking_results_total",
                ranking.result_count,
                status=ranking.status,
            )
            pipeline.result_json = {
                **(pipeline.result_json or {}),
                **_public_result(result),
            }

        del ranking

        _raise_if_cancelled(should_cancel)
        with _pipeline_step(
            db,
            pipeline,
            "SECTOR_ROTATION_SNAPSHOT",
            lease_guard=lease_guard,
            performance=performance,
        ):
            sector_snapshot = _call_market_sensitive(
                dependencies.build_sector_rotation_snapshot,
                db,
                upload_run.id,
                market_cutoff,
                checkpoint_callback=sector_checkpoint,
            )
            result["sector_rotation_snapshots"] = 1
            result["sector_rotation_sector_count"] = int(
                sector_snapshot.summary.get("sector_count") or len(sector_snapshot.rows)
            )
            result["sector_rotation_leading_sector"] = sector_snapshot.summary.get("leading_sector")
            result["sector_rotation_weakest_sector"] = sector_snapshot.summary.get("weakest_sector")
            result["sector_rotation_warning_count"] = len(sector_snapshot.warnings)
        del sector_snapshot
        sector_checkpoint(
            phase="SNAPSHOT_COMMITTED",
            processed=1,
            total=1,
            current_item="sector-snapshot",
            last_completed_item="sector-snapshot",
        )

        return _continue_after_sector_snapshot(
            db,
            pipeline=pipeline,
            upload_run=upload_run,
            tickers=list(downstream_tickers),
            market_cutoff=market_cutoff,
            should_cancel=should_cancel,
            lease_guard=lease_guard,
            dependencies=dependencies,
            result=result,
            performance=performance,
            progress_callback=progress_callback,
            memory_probe=memory_probe,
        )
    except CeriBootstrapRequiredError as exc:
        if overlap_coordinator is not None:
            overlap_coordinator.abort()
        result["performance"] = performance.snapshot()
        _schedule_sec_prerequisite_repair(
            db,
            pipeline,
            exc,
            result=result,
            resume_from_step="VALIDATING_RUN",
            lease_guard=lease_guard,
            scheduler=dependencies.schedule_sec_readiness_repair,
        )
        return _to_execution_result(pipeline, result)
    except PipelineBlockedError as exc:
        if overlap_coordinator is not None:
            overlap_coordinator.abort()
        result["performance"] = performance.snapshot()
        result["blocked_reason"] = exc.reason_code
        result["blocked_diagnostics"] = exc.diagnostics
        _record_performance_metrics(db, PipelineStatus.BLOCKED, result["performance"])
        _mark_pipeline_blocked(db, pipeline, exc, result=result, lease_guard=lease_guard)
        raise
    except IBGatewayUnavailable as exc:
        if overlap_coordinator is not None:
            overlap_coordinator.abort()
        result["performance"] = performance.snapshot()
        _record_performance_metrics(db, PipelineStatus.FAILED, result["performance"])
        _mark_pipeline_failed(db, pipeline, exc, result=result, lease_guard=lease_guard)
        return _to_execution_result(pipeline, result)
    except (JobLeaseLost, ControlPlaneLockTimeout):
        if overlap_coordinator is not None:
            overlap_coordinator.abort()
        raise
    except PipelineCancelled:
        if overlap_coordinator is not None:
            overlap_coordinator.abort()
        result["performance"] = performance.snapshot()
        _record_performance_metrics(db, PipelineStatus.CANCELLED, result["performance"])
        _mark_pipeline_cancelled(db, pipeline, result=result, lease_guard=lease_guard)
        raise
    except Exception as exc:
        if overlap_coordinator is not None:
            overlap_coordinator.abort()
        rollback = getattr(db, "rollback", None)
        if callable(rollback):
            rollback()
            pipeline = _require_pipeline(db, pipeline_run_id)
        result["performance"] = performance.snapshot()
        _record_performance_metrics(db, PipelineStatus.FAILED, result["performance"])
        _mark_pipeline_failed(db, pipeline, exc, result=result, lease_guard=lease_guard)
        raise


def _continue_after_sector_snapshot(
    db: Session,
    *,
    pipeline: PipelineRun,
    upload_run: UploadRun,
    tickers: list[str],
    market_cutoff: MarketCalculationCutoff,
    should_cancel: Callable[[], bool],
    lease_guard: Callable[[], None] | None,
    dependencies: PipelineExecutionDependencies,
    result: dict[str, Any],
    performance: PipelinePerformanceTracker,
    progress_callback: Callable[..., None] | None,
    memory_probe: Callable[..., None] | None,
) -> PipelineExecutionResult:
    if not tickers:
        reason = "ALL_REQUESTED_TICKERS_TERMINAL_INACTIVE"
        result["downstream_publication_skipped"] = 1
        result["downstream_publication_skip_reason"] = reason
        for step_name in (
            CERI_PIPELINE_PROVIDER_INGEST_STEP,
            CERI_PIPELINE_CAPTURE_STEP,
            DECISION_HANDOFF_PIPELINE_STEP,
            SLSE_PIPELINE_CAPTURE_STEP,
            SLSE_PIPELINE_EVALUATION_STEP,
            WINNER_CAPTURE_PIPELINE_STEP,
        ):
            if not _pipeline_has_step(db, pipeline.id, step_name):
                continue
            current = _require_step(db, pipeline.id, step_name)
            if current.status in {PipelineStepStatus.COMPLETED, PipelineStepStatus.SKIPPED}:
                continue
            with _pipeline_step(
                db,
                pipeline,
                step_name,
                lease_guard=lease_guard,
                performance=performance,
            ) as skipped_step:
                skipped_step.status = PipelineStepStatus.SKIPPED
                skipped_step.message = reason
        result["performance"] = performance.snapshot()
        final_status = (
            PipelineStatus.PARTIAL if result.get("partial_scope") else PipelineStatus.COMPLETED
        )
        _record_performance_metrics(db, final_status, result["performance"])
        _mark_pipeline_finished(db, pipeline, final_status, result, lease_guard=lease_guard)
        return _to_execution_result(pipeline, result)

    provider_ingest_enabled = _ceri_provider_ingest_enabled(dependencies)
    if provider_ingest_enabled:
        _raise_if_cancelled(should_cancel)
        with _pipeline_step(
            db,
            pipeline,
            CERI_PIPELINE_PROVIDER_INGEST_STEP,
            lease_guard=lease_guard,
            performance=performance,
        ):
            schedule = dependencies.schedule_ceri_provider_ingest or _schedule_ceri_provider_ingest
            scheduled = _call_market_sensitive(schedule, db, upload_run.id, market_cutoff)
            result["ceri_provider_jobs"] = int(
                getattr(scheduled, "provider_batches", scheduled) or 0
            )
            result["ceri_provider_workflow_key"] = _ceri_provider_workflow_key(
                upload_run.id, scheduled
            )
            if isinstance(db, Session):
                from app.services.pipeline_dependency_service import (
                    prepare_ceri_workflow_dependency,
                )

                prepare_ceri_workflow_dependency(
                    db,
                    pipeline=pipeline,
                    workflow_key=result["ceri_provider_workflow_key"],
                    resume_from_step=DECISION_HANDOFF_PIPELINE_STEP,
                )
        result["performance"] = performance.snapshot()
        _mark_pipeline_waiting_for_ceri(db, pipeline, result, lease_guard=lease_guard)
        return _to_execution_result(pipeline, result)

    if _ceri_run_capture_enabled(dependencies):
        _raise_if_cancelled(should_cancel)
        with _pipeline_step(
            db,
            pipeline,
            CERI_PIPELINE_CAPTURE_STEP,
            lease_guard=lease_guard,
            performance=performance,
        ):
            capture = dependencies.capture_ceri_snapshot or _capture_ceri_snapshot
            ceri_result = _call_market_sensitive(capture, db, upload_run.id, market_cutoff)
            _apply_ceri_capture_result(result, ceri_result)
            if isinstance(db, Session) and dependencies.capture_ceri_snapshot is None:
                from app.services.ceri.score_population import certified_scores

                scores = certified_scores(db, pipeline.id, market_cutoff.context_id)
                result["ceri_certified_score_ids"] = [score.id for score in scores]
                pipeline.result_json = {**(pipeline.result_json or {}), **result}

    if _pipeline_has_step(db, pipeline.id, DECISION_HANDOFF_PIPELINE_STEP):
        _raise_if_cancelled(should_cancel)
        _freeze_pipeline_handoff(
            db,
            pipeline,
            upload_run.id,
            market_cutoff,
            dependencies,
            result,
            lease_guard=lease_guard,
            performance=performance,
            should_cancel=should_cancel,
            progress_callback=progress_callback,
        )

    if _setup_lifecycle_pipeline_step_enabled(dependencies):
        _raise_if_cancelled(should_cancel)
        setup_capture_checkpoint = _setup_capture_checkpoint_callback(
            db,
            should_cancel=should_cancel,
            progress_callback=progress_callback,
        )
        with _pipeline_step(
            db,
            pipeline,
            SLSE_PIPELINE_CAPTURE_STEP,
            lease_guard=lease_guard,
            performance=performance,
        ) as capture_step:
            capture = dependencies.capture_setup_signals or _capture_setup_signals
            capture_result = _call_market_sensitive(
                capture,
                db,
                upload_run.id,
                market_cutoff,
                frozen_tickers=tuple(tickers),
                should_cancel=should_cancel,
                checkpoint_callback=setup_capture_checkpoint,
            )
            _apply_setup_lifecycle_capture_result(
                result,
                capture_result,
                performance=performance,
            )
            _retain_setup_capture_handoff(capture_step, capture_result)
        _raise_if_cancelled(should_cancel)
        setup_evaluation_checkpoint = _setup_evaluation_checkpoint_callback(
            db,
            should_cancel=should_cancel,
            progress_callback=progress_callback,
        )
        with _pipeline_step(
            db,
            pipeline,
            SLSE_PIPELINE_EVALUATION_STEP,
            lease_guard=lease_guard,
            performance=performance,
        ):
            evaluate = dependencies.evaluate_setup_lifecycles or _evaluate_setup_lifecycles
            evaluation_result = _invoke_setup_evaluation(
                evaluate,
                db,
                upload_run.id,
                capture_result=(
                    capture_result if _setup_capture_handoff_enabled(dependencies) else None
                ),
                capture_handoff_enabled=_setup_capture_handoff_enabled(dependencies),
                market_cutoff=market_cutoff,
                pipeline_run_id=pipeline.id,
                progress_callback=setup_evaluation_checkpoint,
            )
            _apply_setup_lifecycle_evaluation_result(result, evaluation_result)
        setup_evaluation_checkpoint(
            phase="STAGE_COMMITTED",
            processed=1,
            total=1,
            current_item="lifecycle-evaluation",
            last_completed_item="lifecycle-evaluation",
        )

    _raise_if_cancelled(should_cancel)
    with _pipeline_step(
        db,
        pipeline,
        "CAPTURING_WINNER_PREDICTIONS",
        lease_guard=lease_guard,
        performance=performance,
    ) as winner_step:
        if result["market_data_mode"] == "CACHE_FALLBACK":
            result["winner_prediction_capture_skipped"] = 1
            result["winner_prediction_capture_skip_reason"] = "CACHE_FALLBACK_MARKET_DATA"
        elif _winner_probability_capture_enabled(dependencies):
            capture = dependencies.capture_winner_predictions or _capture_winner_predictions
            capture_result = _invoke_winner_capture(
                capture,
                db,
                upload_run.id,
                market_cutoff=market_cutoff,
                decision_handoff_manifest_id=result.get("decision_handoff_manifest_id"),
                should_cancel=should_cancel,
                lease_guard=lease_guard,
                progress_callback=progress_callback,
                memory_probe=memory_probe,
            )
            _apply_winner_capture_result(result, capture_result, performance=performance)
            _apply_winner_step_outcome(winner_step, capture_result)
        else:
            result["winner_prediction_capture_skipped"] = 1

    result["performance"] = performance.snapshot()
    final_status = _final_pipeline_status(result)
    _record_performance_metrics(db, final_status, result["performance"])
    _mark_pipeline_finished(db, pipeline, final_status, result, lease_guard=lease_guard)
    return _to_execution_result(pipeline, result)


def _freeze_pipeline_handoff(
    db,
    pipeline,
    upload_run_id,
    market_cutoff,
    dependencies,
    result,
    *,
    lease_guard,
    performance,
    should_cancel,
    progress_callback,
):
    """Freeze native evidence before provider scheduling can interrupt resume."""
    handoff_checkpoint = _handoff_checkpoint_callback(
        db,
        should_cancel=should_cancel,
        progress_callback=progress_callback,
    )
    with _pipeline_step(
        db,
        pipeline,
        DECISION_HANDOFF_PIPELINE_STEP,
        lease_guard=lease_guard,
        performance=performance,
    ):
        freeze_handoff = dependencies.freeze_decision_handoff
        if freeze_handoff is None:
            from app.services.transition_preflight_plan_service import (
                freeze_transition_decision_handoff_manifest,
            )

            freeze_handoff = freeze_transition_decision_handoff_manifest
        freeze_kwargs = {
            "upload_run_id": upload_run_id,
            "market_cutoff": market_cutoff,
        }
        if _accepts_keyword(freeze_handoff, "checkpoint_callback"):
            freeze_kwargs["checkpoint_callback"] = handoff_checkpoint
        handoff = freeze_handoff(db, **freeze_kwargs)
        if handoff is None:
            raise RuntimeError("decision handoff stage has no consumed preflight plan")
        result["run_start_manifest_id"] = handoff.preflight_plan_id
        result["run_start_manifest_hash"] = handoff.run_start_anchor_fingerprint
        result["decision_handoff_manifest_id"] = handoff.id
        result["decision_handoff_manifest_hash"] = handoff.manifest_fingerprint
    handoff_checkpoint(
        phase="MANIFEST_COMMITTED",
        processed=1,
        total=1,
        current_item=f"manifest:{handoff.id}",
        last_completed_item=f"manifest:{handoff.id}",
    )


def _execute_resumed_pipeline(
    db: Session,
    *,
    pipeline: PipelineRun,
    upload_run: UploadRun,
    resume_from_step: str,
    should_cancel: Callable[[], bool],
    lease_guard: Callable[[], None] | None,
    dependencies: PipelineExecutionDependencies,
    progress_callback: Callable[..., None] | None = None,
    memory_probe: Callable[..., None] | None = None,
    execution_token: str | None = None,
) -> PipelineExecutionResult:
    if resume_from_step not in {
        "SECTOR_ROTATION_SNAPSHOT",
        CERI_PIPELINE_PROVIDER_INGEST_STEP,
        DECISION_HANDOFF_PIPELINE_STEP,
        SLSE_PIPELINE_CAPTURE_STEP,
        SLSE_PIPELINE_EVALUATION_STEP,
        WINNER_CAPTURE_PIPELINE_STEP,
    }:
        raise ValueError(
            "The durable resume path supports SECTOR_ROTATION_SNAPSHOT, "
            "CERI_PROVIDER_INGEST, and post-CERI decision-tail boundaries only."
        )
    pipeline = _claim_pipeline_continuation_resume(db, pipeline)
    performance = PipelinePerformanceTracker()
    result = _empty_result(pipeline, upload_run)
    result.update(_public_result(pipeline.result_json or {}))
    result.update(
        {
            "pipeline_run_id": pipeline.id,
            "upload_run_id": upload_run.id,
            "blocked_reason": None,
            "blocked_diagnostics": None,
            "resumed_from_step": resume_from_step,
        }
    )
    try:
        tickers = _pipeline_scope_tickers(db, pipeline)
        resumed_readiness = (
            load_current_session_readiness(db, pipeline_run_id=pipeline.id)
            if isinstance(db, Session)
            else None
        )
        if resumed_readiness is not None:
            availability_policy = pipeline_availability_policy(pipeline)
            if hard_readiness_blockers(resumed_readiness.rows, availability_policy):
                raise PipelineBlockedError(
                    "MARKET_DATA_SESSION_READINESS_BLOCKED: resumed decision tail has blockers",
                    reason_code="MARKET_DATA_SESSION_READINESS_BLOCKED",
                    diagnostics=resumed_readiness.as_dict(),
                )
            tickers = list(processing_tickers(resumed_readiness.rows, availability_policy))
        _mark_pipeline_running(db, pipeline, lease_guard=lease_guard)
        if not tickers and resume_from_step != "SECTOR_ROTATION_SNAPSHOT":
            if dependencies.market_cutoff is None:
                raise RuntimeError("resumed pipeline is missing its frozen market cutoff")
            return _continue_after_sector_snapshot(
                db,
                pipeline=pipeline,
                upload_run=upload_run,
                tickers=[],
                market_cutoff=dependencies.market_cutoff,
                should_cancel=should_cancel,
                lease_guard=lease_guard,
                dependencies=dependencies,
                result=result,
                performance=performance,
                progress_callback=progress_callback,
                memory_probe=memory_probe,
            )
        if resume_from_step == "SECTOR_ROTATION_SNAPSHOT":
            if dependencies.market_cutoff is None:
                raise RuntimeError("resumed sector pipeline is missing its frozen market cutoff")
            sector_checkpoint = _sector_checkpoint_callback(
                db,
                should_cancel=should_cancel,
                progress_callback=progress_callback,
            )
            validate_sector_checkpoint = dependencies.validate_sector_resume_checkpoint
            try:
                checkpoint = (
                    (validate_sector_checkpoint or _validate_sector_resume_checkpoint)(
                        db,
                        pipeline=pipeline,
                        upload_run_id=upload_run.id,
                        market_cutoff=dependencies.market_cutoff,
                        checkpoint_callback=sector_checkpoint,
                    )
                )
            except (ValueError, EvidenceUnavailableError) as exc:
                # A recovery boundary never grants permission to rebuild its
                # predecessors when their retained evidence cannot be certified.
                blocked_step = _require_step(db, pipeline.id, "SECTOR_ROTATION_SNAPSHOT")
                blocked_step.status = PipelineStepStatus.BLOCKED
                blocked_step.completed_at = _utcnow()
                blocked_step.message = "Blocked: SECTOR_RESUME_CHECKPOINT_INVALID"
                blocked_step.error_message = _safe_message(str(exc))
                if (pipeline.result_json or {}).get("recovery_continuation"):
                    result["recovery_continuation"] = {
                        **pipeline.result_json["recovery_continuation"],
                        "validation_state": "INVALID",
                    }
                raise PipelineBlockedError(
                    "Sector checkpoint recovery could not validate the retained inputs: "
                    + str(exc),
                    reason_code="SECTOR_RESUME_CHECKPOINT_INVALID",
                    diagnostics={
                        "resume_from_step": "SECTOR_ROTATION_SNAPSHOT",
                        "validation_error": str(exc),
                    },
                ) from exc
            result.update(checkpoint["restored_result"])
            result["sector_resume_checkpoint"] = {
                key: value for key, value in checkpoint.items() if key != "restored_result"
            }
            pipeline.result_json = {
                **(pipeline.result_json or {}),
                "sector_resume_checkpoint": result["sector_resume_checkpoint"],
            }
            if (pipeline.result_json or {}).get("recovery_continuation"):
                continuation = {
                    **pipeline.result_json["recovery_continuation"],
                    "validation_state": "VALIDATED",
                }
                pipeline.result_json = {
                    **pipeline.result_json, "recovery_continuation": continuation,
                }
                result["recovery_continuation"] = continuation
            _save_progress(db, lease_guard=lease_guard)
            _raise_if_cancelled(should_cancel)
            with _pipeline_step(
                db,
                pipeline,
                "SECTOR_ROTATION_SNAPSHOT",
                lease_guard=lease_guard,
                performance=performance,
            ):
                published = checkpoint.get("published_sector_result")
                if published is not None:
                    result.update(published)
                    result["sector_rotation_snapshot_reused"] = True
                else:
                    sector_snapshot = _call_market_sensitive(
                        dependencies.build_sector_rotation_snapshot,
                        db,
                        upload_run.id,
                        dependencies.market_cutoff,
                        checkpoint_callback=sector_checkpoint,
                    )
                    result["sector_rotation_snapshots"] = 1
                    result["sector_rotation_sector_count"] = int(
                        sector_snapshot.summary.get("sector_count") or len(sector_snapshot.rows)
                    )
                    result["sector_rotation_leading_sector"] = sector_snapshot.summary.get(
                        "leading_sector"
                    )
                    result["sector_rotation_weakest_sector"] = sector_snapshot.summary.get(
                        "weakest_sector"
                    )
                    result["sector_rotation_warning_count"] = len(sector_snapshot.warnings)
            sector_checkpoint(
                phase="SNAPSHOT_COMMITTED",
                processed=1,
                total=1,
                current_item="sector-snapshot",
                last_completed_item="sector-snapshot",
            )
            return _continue_after_sector_snapshot(
                db,
                pipeline=pipeline,
                upload_run=upload_run,
                tickers=tickers,
                market_cutoff=dependencies.market_cutoff,
                should_cancel=should_cancel,
                lease_guard=lease_guard,
                dependencies=dependencies,
                result=result,
                performance=performance,
                progress_callback=progress_callback,
                memory_probe=memory_probe,
            )
        if resume_from_step == CERI_PIPELINE_PROVIDER_INGEST_STEP:
            _raise_if_cancelled(should_cancel)
            with _pipeline_step(
                db,
                pipeline,
                CERI_PIPELINE_PROVIDER_INGEST_STEP,
                lease_guard=lease_guard,
                performance=performance,
            ):
                validate_preflight = dependencies.validate_pipeline_preflight
                result["sec_preflight"] = (
                    validate_preflight(db, tickers)
                    if validate_preflight is not None
                    else validate_sec_pipeline_preflight(db, tickers=tickers, pipeline=pipeline)
                )
                _retain_sec_preflight_coverage(result)
                schedule = (
                    dependencies.schedule_ceri_provider_ingest or _schedule_ceri_provider_ingest
                )
                scheduled = _call_market_sensitive(
                    schedule, db, upload_run.id, dependencies.market_cutoff
                )
                result["ceri_provider_jobs"] = int(
                    getattr(scheduled, "provider_batches", scheduled) or 0
                )
                result["ceri_provider_workflow_key"] = _ceri_provider_workflow_key(
                    upload_run.id, scheduled
                )
            result["performance"] = performance.snapshot()
            _mark_pipeline_waiting_for_ceri(
                db,
                pipeline,
                result,
                lease_guard=lease_guard,
            )
            return _to_execution_result(pipeline, result)

        _raise_if_cancelled(should_cancel)
        _validate_ceri_completion_barrier(db, pipeline, tickers=tickers)
        if _pipeline_has_step(db, pipeline.id, DECISION_HANDOFF_PIPELINE_STEP):
            retained_handoff = _reusable_decision_handoff(db, pipeline, upload_run.id)
            if retained_handoff is not None:
                result.update(retained_handoff)
            else:
                if dependencies.market_cutoff is None:
                    raise RuntimeError("resumed pipeline is missing its frozen market cutoff")
                _freeze_pipeline_handoff(
                    db,
                    pipeline,
                    upload_run.id,
                    dependencies.market_cutoff,
                    dependencies,
                    result,
                    lease_guard=lease_guard,
                    performance=performance,
                    should_cancel=should_cancel,
                    progress_callback=progress_callback,
                )
        validate_checkpoint = dependencies.validate_resume_checkpoint
        checkpoint = _reusable_resume_checkpoint(db, pipeline, upload_run.id, resume_from_step)
        if checkpoint is None:
            resume_validation_checkpoint = _resume_validation_checkpoint_callback(
                db,
                stage=resume_from_step,
                should_cancel=should_cancel,
                progress_callback=progress_callback,
            )
            if validate_checkpoint is not None:
                checkpoint = (
                    validate_checkpoint(
                        db,
                        upload_run.id,
                        resume_from_step,
                        checkpoint_callback=resume_validation_checkpoint,
                    )
                    if _accepts_keyword(validate_checkpoint, "checkpoint_callback")
                    else validate_checkpoint(db, upload_run.id, resume_from_step)
                )
            else:
                checkpoint = _validate_resume_checkpoint(
                    db,
                    pipeline,
                    upload_run.id,
                    resume_from_step,
                    checkpoint_callback=resume_validation_checkpoint,
                )
            pipeline.result_json = {
                **(pipeline.result_json or {}),
                "resume_checkpoint": checkpoint,
            }
            _save_progress(db, lease_guard=lease_guard)
        result["resume_checkpoint"] = checkpoint
        result["technical_error_count"] = int(checkpoint.get("technical_error_count") or 0)
        result["market_regime_low_confidence"] = int(
            result.get("market_regime_confidence") == "low"
        )

        capture_result = (
            _retained_setup_capture_handoff(db, pipeline.id)
            if resume_from_step == SLSE_PIPELINE_EVALUATION_STEP
            and _setup_lifecycle_pipeline_step_enabled(dependencies)
            else None
        )
        run_setup_capture = resume_from_step in {
            DECISION_HANDOFF_PIPELINE_STEP,
            SLSE_PIPELINE_CAPTURE_STEP,
        }
        run_setup_evaluation = resume_from_step in {
            DECISION_HANDOFF_PIPELINE_STEP,
            SLSE_PIPELINE_CAPTURE_STEP,
            SLSE_PIPELINE_EVALUATION_STEP,
        }
        if _setup_lifecycle_pipeline_step_enabled(dependencies) and run_setup_capture:
            _raise_if_cancelled(should_cancel)
            setup_capture_checkpoint = _setup_capture_checkpoint_callback(
                db,
                should_cancel=should_cancel,
                progress_callback=progress_callback,
            )
            with _pipeline_step(
                db,
                pipeline,
                SLSE_PIPELINE_CAPTURE_STEP,
                lease_guard=lease_guard,
                performance=performance,
            ) as capture_step:
                capture = dependencies.capture_setup_signals or _capture_setup_signals
                if dependencies.market_cutoff is None:
                    raise RuntimeError("resumed pipeline is missing its frozen market cutoff")
                capture_result = _call_market_sensitive(
                    capture,
                    db,
                    upload_run.id,
                    dependencies.market_cutoff,
                    frozen_tickers=tuple(tickers),
                    should_cancel=should_cancel,
                    checkpoint_callback=setup_capture_checkpoint,
                )
                _apply_setup_lifecycle_capture_result(
                    result,
                    capture_result,
                    performance=performance,
                )
                _retain_setup_capture_handoff(capture_step, capture_result)
        if _setup_lifecycle_pipeline_step_enabled(dependencies) and run_setup_evaluation:
            _raise_if_cancelled(should_cancel)
            setup_evaluation_checkpoint = _setup_evaluation_checkpoint_callback(
                db,
                should_cancel=should_cancel,
                progress_callback=progress_callback,
            )
            with _pipeline_step(
                db,
                pipeline,
                SLSE_PIPELINE_EVALUATION_STEP,
                lease_guard=lease_guard,
                performance=performance,
            ):
                evaluate = dependencies.evaluate_setup_lifecycles or _evaluate_setup_lifecycles
                evaluation_result = _invoke_setup_evaluation(
                    evaluate,
                    db,
                    upload_run.id,
                    capture_result=(
                        capture_result if _setup_capture_handoff_enabled(dependencies) else None
                    ),
                    capture_handoff_enabled=_setup_capture_handoff_enabled(dependencies),
                    market_cutoff=dependencies.market_cutoff,
                    pipeline_run_id=pipeline.id,
                    progress_callback=setup_evaluation_checkpoint,
                )
                _apply_setup_lifecycle_evaluation_result(result, evaluation_result)
            setup_evaluation_checkpoint(
                phase="STAGE_COMMITTED",
                processed=1,
                total=1,
                current_item="lifecycle-evaluation",
                last_completed_item="lifecycle-evaluation",
            )

        _raise_if_cancelled(should_cancel)
        with _pipeline_step(
            db,
            pipeline,
            "CAPTURING_WINNER_PREDICTIONS",
            lease_guard=lease_guard,
            performance=performance,
        ) as winner_step:
            if result.get("market_data_mode") == "CACHE_FALLBACK":
                result["winner_prediction_capture_skipped"] = 1
                result["winner_prediction_capture_skip_reason"] = "CACHE_FALLBACK_MARKET_DATA"
            elif _winner_probability_capture_enabled(dependencies):
                capture = dependencies.capture_winner_predictions or _capture_winner_predictions
                winner_result = _invoke_winner_capture(
                    capture,
                    db,
                    upload_run.id,
                    market_cutoff=dependencies.market_cutoff,
                    decision_handoff_manifest_id=result.get("decision_handoff_manifest_id"),
                    should_cancel=should_cancel,
                    lease_guard=lease_guard,
                    progress_callback=progress_callback,
                    memory_probe=memory_probe,
                )
                _apply_winner_capture_result(
                    result,
                    winner_result,
                    performance=performance,
                )
                _apply_winner_step_outcome(winner_step, winner_result)
            else:
                result["winner_prediction_capture_skipped"] = 1

        result["performance"] = performance.snapshot()
        final_status = _final_pipeline_status(result)
        _record_performance_metrics(db, final_status, result["performance"])
        _mark_pipeline_finished(db, pipeline, final_status, result, lease_guard=lease_guard)
        return _to_execution_result(pipeline, result)
    except CeriBootstrapRequiredError as exc:
        result["performance"] = performance.snapshot()
        _schedule_sec_prerequisite_repair(
            db,
            pipeline,
            exc,
            result=result,
            resume_from_step=resume_from_step,
            lease_guard=lease_guard,
            scheduler=dependencies.schedule_sec_readiness_repair,
        )
        return _to_execution_result(pipeline, result)
    except PipelineBlockedError as exc:
        result["performance"] = performance.snapshot()
        result["blocked_reason"] = exc.reason_code
        result["blocked_diagnostics"] = exc.diagnostics
        _mark_pipeline_blocked(db, pipeline, exc, result=result, lease_guard=lease_guard)
        raise
    except (JobLeaseLost, ControlPlaneLockTimeout):
        raise
    except PipelineCancelled:
        result["performance"] = performance.snapshot()
        _mark_pipeline_cancelled(db, pipeline, result=result, lease_guard=lease_guard)
        raise
    except Exception as exc:
        rollback = getattr(db, "rollback", None)
        if callable(rollback):
            rollback()
            pipeline = _require_pipeline(db, pipeline.id)
        result["performance"] = performance.snapshot()
        _mark_pipeline_failed(db, pipeline, exc, result=result, lease_guard=lease_guard)
        raise


def _reusable_decision_handoff(
    db: Session,
    pipeline: PipelineRun,
    upload_run_id: int,
) -> dict[str, Any] | None:
    step = db.scalar(
        select(PipelineStep).where(
            PipelineStep.pipeline_run_id == pipeline.id,
            PipelineStep.step_name == DECISION_HANDOFF_PIPELINE_STEP,
        )
    )
    if step is None or step.status != PipelineStepStatus.COMPLETED:
        return None
    handoff = db.scalar(
        select(TransitionDecisionHandoffManifest).where(
            TransitionDecisionHandoffManifest.pipeline_run_id == pipeline.id
        )
    )
    if handoff is None:
        return None
    manifest = dict(handoff.manifest_json or {})
    if CanonicalEvidenceSerializer.fingerprint(manifest) != handoff.manifest_fingerprint:
        return None
    binding = dict(manifest.get("run") or {})
    if (
        binding.get("upload_run_id") != upload_run_id
        or binding.get("pipeline_run_id") != pipeline.id
    ):
        return None
    return {
        "decision_handoff_manifest_id": handoff.id,
        "decision_handoff_manifest_hash": handoff.manifest_fingerprint,
        "decision_handoff_reused": True,
    }


def _reusable_resume_checkpoint(
    db: Session,
    pipeline: PipelineRun,
    upload_run_id: int,
    resume_from_step: str,
) -> dict[str, Any] | None:
    retained = dict((pipeline.result_json or {}).get("resume_checkpoint") or {})
    if not retained.get("validated") or retained.get("resume_from_step") != resume_from_step:
        return None
    handoff = _reusable_decision_handoff(db, pipeline, upload_run_id)
    if handoff is None:
        return None
    if (
        retained.get("decision_handoff_manifest_fingerprint")
        != handoff["decision_handoff_manifest_hash"]
    ):
        return None
    if int(retained.get("expected_tickers") or 0) != len(_pipeline_scope_tickers(db, pipeline)):
        return None
    return {**retained, "reused": True}


def _validate_resume_checkpoint(
    db: Session,
    pipeline: PipelineRun,
    upload_run_id: int,
    resume_from_step: str,
    *,
    checkpoint_callback: Callable[..., None] | None = None,
) -> dict[str, Any]:
    steps = list(
        db.scalars(
            select(PipelineStep)
            .where(PipelineStep.pipeline_run_id == pipeline.id)
            .order_by(PipelineStep.step_order)
        ).all()
    )
    target = next((step for step in steps if step.step_name == resume_from_step), None)
    if target is None:
        raise ValueError(f"Pipeline has no resume step named {resume_from_step}.")
    invalid = [
        step.step_name
        for step in steps
        if step.step_order < target.step_order
        and step.status not in {PipelineStepStatus.COMPLETED, PipelineStepStatus.SKIPPED}
    ]
    if invalid:
        raise ValueError(
            "Cannot resume because prior stages are not complete: " + ", ".join(invalid)
        )

    scoped_tickers = _pipeline_scope_tickers(db, pipeline)
    expected = len(scoped_tickers)
    checks = {
        "fundamental_scores": _run_ticker_count(
            db, FundamentalScore, upload_run_id, scoped_tickers
        ),
        "technical_scores": _run_ticker_count(db, TechnicalScore, upload_run_id, scoped_tickers),
        "combined_results": _run_ticker_count(db, CombinedResult, upload_run_id, scoped_tickers),
        "ranking_results": _run_ticker_count(db, RankingResult, upload_run_id, scoped_tickers),
    }
    if any(checks[name] != expected for name in checks):
        raise ValueError(
            "Resume checkpoint invariant failed: "
            f"expected {expected} distinct tickers, observed {checks}."
        )
    ranking_rows = int(
        db.scalar(
            select(func.count())
            .select_from(RankingResult)
            .where(RankingResult.run_id == upload_run_id)
        )
        or 0
    )
    if ranking_rows <= 0:
        raise ValueError("Resume checkpoint has no persisted ranking rows.")
    technical_scores = list(
        db.scalars(select(TechnicalScore).where(TechnicalScore.run_id == upload_run_id)).all()
    )
    context_counts = {
        "market_regime_snapshots": int(
            db.scalar(
                select(func.count())
                .select_from(MarketRegimeSnapshot)
                .where(MarketRegimeSnapshot.run_id == upload_run_id)
            )
            or 0
        ),
        "sector_rotation_snapshots": int(
            db.scalar(
                select(func.count())
                .select_from(SectorRotationSnapshot)
                .where(SectorRotationSnapshot.run_id == upload_run_id)
            )
            or 0
        ),
    }
    if any(count <= 0 for count in context_counts.values()):
        raise ValueError(f"Resume checkpoint is missing required market context: {context_counts}.")
    certified_evidence = _validate_resume_evidence(
        db,
        pipeline=pipeline,
        upload_run_id=upload_run_id,
        checkpoint_callback=checkpoint_callback,
    )
    return {
        "resume_from_step": resume_from_step,
        "expected_tickers": expected,
        **checks,
        "ranking_rows": ranking_rows,
        "technical_error_count": _technical_error_count(technical_scores),
        **context_counts,
        **certified_evidence,
        "validated": True,
    }


def _validate_sector_resume_checkpoint(
    db: Session,
    *,
    pipeline: PipelineRun,
    upload_run_id: int,
    market_cutoff: MarketCalculationCutoff,
    checkpoint_callback: Callable[..., None] | None = None,
) -> dict[str, Any]:
    """Fail closed unless every upstream sector input is still pipeline-owned and sealed."""

    steps = list(
        db.scalars(
            select(PipelineStep)
            .where(PipelineStep.pipeline_run_id == pipeline.id)
            .order_by(PipelineStep.step_order)
        ).all()
    )
    target = next((step for step in steps if step.step_name == "SECTOR_ROTATION_SNAPSHOT"), None)
    if target is None:
        raise ValueError("Pipeline has no SECTOR_ROTATION_SNAPSHOT resume boundary.")
    invalid = [
        step.step_name
        for step in steps
        if step.step_order < target.step_order
        and step.status not in {PipelineStepStatus.COMPLETED, PipelineStepStatus.SKIPPED}
    ]
    if invalid:
        raise ValueError(
            "Cannot resume sector rotation because prior stages are incomplete: "
            + ", ".join(invalid)
        )

    tickers = _pipeline_scope_tickers(db, pipeline)
    expected = len(tickers)
    from app.services.core_mutation_authority import (
        sector_evidence_rows,
        validate_evidence,
        validate_source_values,
    )

    models = {
        CoreEvidenceKind.FUNDAMENTAL: FundamentalScore,
        CoreEvidenceKind.TECHNICAL: TechnicalScore,
        CoreEvidenceKind.COMBINED: CombinedResult,
        CoreEvidenceKind.RANKING: RankingResult,
    }
    row_counts = {kind: int(db.scalar(select(func.count()).select_from(model).where(
        model.run_id == upload_run_id,
    )) or 0) for kind, model in models.items()}
    distinct_counts = {}
    ranking_addresses = []
    incomplete_rows = warning_rows = technical_errors = 0

    market_snapshot = db.scalar(
        select(MarketRegimeSnapshot)
        .where(
            MarketRegimeSnapshot.run_id == upload_run_id,
            MarketRegimeSnapshot.calculation_context_id == market_cutoff.context_id,
        )
        .order_by(MarketRegimeSnapshot.id.desc())
        .limit(1)
    )
    if market_snapshot is None:
        raise ValueError("Sector resume checkpoint has no pipeline-owned market regime snapshot.")

    total = sum(row_counts.values()) + 1
    certified_ids = set()
    index = 0
    for kind, model in models.items():
        last_id = 0
        tickers_seen = set()
        observed_rows = 0
        while True:
            batch = list(db.scalars(select(model).where(
                model.run_id == upload_run_id, model.id > last_id,
            ).order_by(model.id).limit(32)))
            if not batch:
                break
            last_id = batch[-1].id
            ids = {row.evidence_id for row in batch if row.evidence_id is not None}
            envelopes = sector_evidence_rows(db, ids)
            for row in batch:
                evidence = envelopes.get(row.evidence_id)
                if evidence is None:
                    raise ValueError("SECTOR_RESUME_SOURCE_EVIDENCE_MISSING")
                validate_evidence(evidence)
                evidence_id = _require_unchanged_core_evidence(db, kind=kind, row=row)
                _require_sector_resume_source_authority(
                    evidence, kind=kind, row=row, upload_run_id=upload_run_id,
                    pipeline_run_id=pipeline.id, market_cutoff=market_cutoff,
                )
                tickers_seen.add(str(row.ticker).strip().upper())
                if kind is CoreEvidenceKind.RANKING:
                    ranking_addresses.append((row.ranking_profile, row.ticker, row.id, evidence_id))
                elif kind is CoreEvidenceKind.COMBINED:
                    incomplete_rows += int(not row.is_complete)
                    warning_rows += int(row.has_warning)
                elif kind is CoreEvidenceKind.TECHNICAL:
                    technical_errors += _technical_error_count([row])
                certified_ids.add(evidence_id)
                observed_rows += 1
                index += 1
                item = f"{kind.value}:{row.id}"
                # Release decoded serving JSON after every verified row.  Only
                # addresses and counters survive this bounded validation phase.
                db.expire(row)
                if checkpoint_callback is not None and index % 50 == 0:
                    checkpoint_callback(
                        phase="RESUME_AUTHORITY_VALIDATION", processed=index, total=total,
                        current_item=item, last_completed_item=item,
                    )
            del envelopes, batch, row, evidence
        distinct_counts[kind.value.lower() + "_tickers"] = len(tickers_seen)
        if observed_rows != row_counts[kind]:
            raise ValueError("SECTOR_RESUME_SOURCE_ROW_COUNT_CHANGED: " + kind.value)
        if tickers_seen != set(tickers):
            raise ValueError("SECTOR_RESUME_SOURCE_MEMBERSHIP_CHANGED: " + kind.value)
    if any(count != expected for count in distinct_counts.values()):
        raise ValueError(
            "Sector resume checkpoint invariant failed: "
            f"expected {expected} distinct tickers, observed {distinct_counts}."
        )
    retained = _public_result(pipeline.result_json or {})
    ranking_step = next((step for step in steps if step.step_name == "RANKING_PROFILES"), None)
    if ranking_step is not None and ranking_step.status == PipelineStepStatus.COMPLETED:
        profiles = {}
        for profile, ticker, _row_id, _evidence_id in ranking_addresses:
            profiles.setdefault(profile, set()).add(str(ticker).strip().upper())
        if (
            retained.get("ranking_results") != row_counts[CoreEvidenceKind.RANKING]
            or retained.get("ranking_profiles") != len(profiles)
            or any(members != set(tickers) for members in profiles.values())
        ):
            raise ValueError("SECTOR_RESUME_RANKING_COHORT_CHANGED")
    regime_evidence = get_certified_evidence_for_row(
        db, kind=CoreEvidenceKind.REGIME, current_row=market_snapshot,
    )
    validate_evidence(regime_evidence)
    validate_source_values(market_snapshot, regime_evidence, db=db)
    _require_sector_resume_source_authority(
        regime_evidence, kind=CoreEvidenceKind.REGIME, row=market_snapshot,
        upload_run_id=upload_run_id, pipeline_run_id=pipeline.id, market_cutoff=market_cutoff,
    )
    certified_ids.add(regime_evidence.id)
    if checkpoint_callback is not None:
        checkpoint_callback(
            phase="RESUME_AUTHORITY_VALIDATION", processed=total, total=total,
            current_item=f"REGIME:{market_snapshot.id}",
            last_completed_item=f"REGIME:{market_snapshot.id}",
        )

    existing_sector = list(
        db.scalars(
            select(SectorRotationSnapshot).where(
                SectorRotationSnapshot.run_id == upload_run_id,
                SectorRotationSnapshot.is_current_revision.is_(True),
            )
        )
    )
    if len(existing_sector) > 1:
        raise ValueError("SECTOR_RESUME_MULTIPLE_CURRENT_SNAPSHOTS")
    if existing_sector:
        sector = existing_sector[0]
        sector_evidence = get_certified_evidence_for_row(
            db, kind=CoreEvidenceKind.SECTOR, current_row=sector,
        )
        sector_evidence_id = int(sector_evidence.id)
        validate_evidence(sector_evidence)
        validate_source_values(sector, sector_evidence, db=db)
        _require_sector_resume_source_authority(
            sector_evidence,
            kind=CoreEvidenceKind.SECTOR,
            row=sector,
            upload_run_id=upload_run_id,
            pipeline_run_id=pipeline.id,
            market_cutoff=market_cutoff,
        )
        from app.services.contextual_effective_configuration import resolve_sector_configuration

        resolve_sector_configuration().require_retry_identity(
            CalculationIdentity.from_canonical_payload(sector_evidence.calculation_identity_json)
        )
        expected_sources = {
            f"ranking:{index:06d}": address[3]
            for index, address in enumerate(sorted(ranking_addresses), start=1)
        }
        expected_sources["regime"] = int(market_snapshot.evidence_id)
        observed_sources = dict(sector_evidence.source_evidence_ids_json or {})
        if (
            {key: value for key, value in observed_sources.items() if key != "prior_sector"}
            != expected_sources
        ):
            raise ValueError("SECTOR_RESUME_PUBLISHED_SOURCE_SET_CHANGED")
        from app.services.core_mutation_authority import validate_sector_manifest

        identity = CalculationIdentity.from_canonical_payload(
            sector_evidence.calculation_identity_json
        )
        envelope = (sector_evidence.payload_json.get("debug") or {}).get("native_input_envelope")
        if not isinstance(envelope, dict):
            raise ValueError("SECTOR_RESUME_PUBLISHED_SOURCE_MANIFEST_MISSING")
        validate_sector_manifest(db, identity, envelope, checkpoint_callback=checkpoint_callback)
        certified_ids.add(sector_evidence_id)

    if retained.get("market_data_mode") not in {"IB_GATEWAY", "CACHE_FALLBACK"}:
        raise ValueError("Sector resume checkpoint is missing the retained market-data mode.")
    retained.update(
        {
            "uploaded_rows": expected,
            "fundamental_scores": row_counts[CoreEvidenceKind.FUNDAMENTAL],
            "technical_scores": row_counts[CoreEvidenceKind.TECHNICAL],
            "combined_results": row_counts[CoreEvidenceKind.COMBINED],
            "ranking_results": row_counts[CoreEvidenceKind.RANKING],
            "ranking_profiles": len({address[0] for address in ranking_addresses}),
            "incomplete_rows": incomplete_rows,
            "warning_rows": warning_rows,
            "technical_error_count": technical_errors,
            "market_regime_snapshots": 1,
            "market_regime": market_snapshot.regime,
            "market_risk_state": market_snapshot.risk_state,
            "market_regime_confidence": market_snapshot.confidence,
            "market_regime_warning_count": len(market_snapshot.warnings_json or []),
            "market_regime_low_confidence": int(market_snapshot.confidence == "low"),
        }
    )
    return {
        "resume_from_step": "SECTOR_ROTATION_SNAPSHOT",
        "expected_tickers": expected,
        **distinct_counts,
        "ranking_rows": row_counts[CoreEvidenceKind.RANKING],
        "certified_evidence_count": len(certified_ids),
        "market_calculation_context_id": market_cutoff.context_id,
        "validated": True,
        "restored_result": retained,
        **({"published_sector_result": {
            "sector_rotation_snapshots": 1,
            "sector_rotation_sector_count": int(sector.sector_count or 0),
            "sector_rotation_leading_sector": sector.leading_sector,
            "sector_rotation_weakest_sector": sector.weakest_sector,
            "sector_rotation_warning_count": len(sector.warning_flags_json or []),
            "sector_rotation_snapshot_id": sector.id,
            "sector_rotation_evidence_id": sector_evidence_id,
        }} if existing_sector else {}),
    }


def _require_sector_resume_source_authority(
    evidence: CoreCalculationEvidence,
    *,
    kind: CoreEvidenceKind,
    row: Any,
    upload_run_id: int,
    pipeline_run_id: int,
    market_cutoff: MarketCalculationCutoff,
) -> None:
    source_identity = CalculationIdentity.from_canonical_payload(evidence.calculation_identity_json)
    dimensions = {
        "run_id": (source_identity.ownership.run_id, upload_run_id),
        "pipeline_id": (source_identity.ownership.pipeline_id, pipeline_run_id),
        "market_calculation_context_id": (
            source_identity.calculation_context.market_calculation_context_id,
            market_cutoff.context_id,
        ),
        "calculation_cutoff": (
            source_identity.temporal.calculation_cutoff,
            market_cutoff.cutoff_at,
        ),
        "as_of_session": (
            source_identity.temporal.as_of_session,
            market_cutoff.latest_completed_session,
        ),
    }
    mismatches = [
        name
        for name, (dimension, value) in dimensions.items()
        if dimension.state is not IdentityState.KNOWN or dimension.value != value
    ]
    if mismatches:
        raise ValueError(
            "SECTOR_RESUME_SOURCE_AUTHORITY_MISMATCH: "
            f"kind={kind.value} row={getattr(row, 'id', None)} dimensions={mismatches}"
        )


def _validate_ceri_completion_barrier(
    db: Session,
    pipeline: PipelineRun,
    *,
    tickers: list[str],
) -> None:
    retained = dict(pipeline.result_json or {})
    workflow_key = str(retained.get("ceri_provider_workflow_key") or "")
    if retained.get("ceri_completion_state") != "CERTIFIED" or not workflow_key.startswith(
        "ceri:pipeline:"
    ):
        raise ValueError("CERI_COMPLETION_BARRIER_NOT_CERTIFIED")
    if not isinstance(db, Session):
        return
    from app.services.ceri.score_population import certified_scores
    from app.services.market_calculation_context_service import resolve_pipeline_ceri_context

    if retained.get("ceri_calculation_context_id") is not None:
        context = resolve_pipeline_ceri_context(
            db,
            calculation_context_id=retained.get("ceri_calculation_context_id"),
            upload_run_id=pipeline.upload_run_id,
            pipeline_run_id=pipeline.id,
        )
    else:
        # Existing non-fresh runs may have valid pre-cutoff retained history
        # under the original market context. New provider workflows always
        # retain a post-acquisition CERI context before feature calculation.
        context = market_context_for_pipeline(db, pipeline)
    receipt = retained.get("ceri_certified_score_ids")
    if not receipt:
        raise ValueError("CERI_CERTIFIED_CAPTURE_RECEIPT_MISSING")
    scores = certified_scores(db, pipeline.id, context.context_id, expected_ids=receipt)
    captured = {row.ticker for row in scores}
    expected = {ticker.strip().upper() for ticker in tickers}
    if captured != expected:
        raise ValueError(
            "CERI_CERTIFIED_CAPTURE_INCOMPLETE: "
            f"expected {len(expected)} certified run snapshots, observed {len(captured)}"
        )


def _validate_resume_evidence(
    db: Session,
    *,
    pipeline: PipelineRun,
    upload_run_id: int,
    checkpoint_callback: Callable[..., None] | None = None,
) -> dict[str, Any]:
    """Prove resume inputs still match the frozen handoff and immutable evidence."""

    handoff = db.scalar(
        select(TransitionDecisionHandoffManifest).where(
            TransitionDecisionHandoffManifest.pipeline_run_id == pipeline.id
        )
    )
    if handoff is None:
        raise ValueError(
            "LEGACY_EVIDENCE_UNAVAILABLE: resume has no frozen decision handoff manifest"
        )
    manifest = dict(handoff.manifest_json or {})
    if CanonicalEvidenceSerializer.fingerprint(manifest) != handoff.manifest_fingerprint:
        raise ValueError(
            "HISTORICAL_EVIDENCE_UNAVAILABLE: resume handoff manifest fingerprint mismatch"
        )
    binding = dict(manifest.get("run") or {})
    market_context = dict(manifest.get("market_context") or {})
    if (
        binding.get("upload_run_id") != upload_run_id
        or binding.get("pipeline_run_id") != pipeline.id
        or market_context.get("id") != handoff.market_calculation_context_id
    ):
        raise ValueError("HISTORICAL_EVIDENCE_UNAVAILABLE: resume handoff ownership mismatch")
    frozen_context = db.get(MarketCalculationContext, handoff.market_calculation_context_id)
    if (
        frozen_context is None
        or frozen_context.upload_run_id != upload_run_id
        or frozen_context.pipeline_run_id != pipeline.id
    ):
        raise ValueError(
            "HISTORICAL_EVIDENCE_UNAVAILABLE: resume market context unavailable or "
            f"misowned upload_run_id={upload_run_id} pipeline_run_id={pipeline.id} "
            f"context_id={handoff.market_calculation_context_id}"
        )

    raw_rows = list(
        db.scalars(
            select(RawCompanyRow)
            .where(RawCompanyRow.run_id == upload_run_id)
            .order_by(RawCompanyRow.row_number)
        )
    )
    from app.services.pipeline_partial_results import filter_pipeline_rows

    raw_rows = filter_pipeline_rows(db, raw_rows, pipeline.id)
    fundamentals = _resume_rows_by_ticker(db, FundamentalScore, upload_run_id)
    technicals = _resume_rows_by_ticker(db, TechnicalScore, upload_run_id)
    combined = _resume_rows_by_ticker(db, CombinedResult, upload_run_id)
    rankings = _resume_rankings_by_ticker(db, upload_run_id)
    artifact_lineage = dict(manifest.get("artifact_lineage") or {})
    certified_ids: set[int] = set()
    total = len(raw_rows)
    for index, raw in enumerate(raw_rows, start=1):
        ticker = raw.ticker.strip().upper()
        expected = artifact_lineage.get(ticker)
        if not isinstance(expected, dict):
            raise ValueError(
                f"HISTORICAL_EVIDENCE_UNAVAILABLE: resume handoff missing ticker {ticker}"
            )
        _require_manifest_artifact(raw, expected.get("raw_row"), label=f"{ticker}:raw")
        for label, kind, row in (
            ("fundamental_score", CoreEvidenceKind.FUNDAMENTAL, fundamentals.get(ticker)),
            ("technical_score", CoreEvidenceKind.TECHNICAL, technicals.get(ticker)),
            ("combined_result", CoreEvidenceKind.COMBINED, combined.get(ticker)),
        ):
            _require_manifest_artifact(row, expected.get(label), label=f"{ticker}:{label}")
            certified_ids.add(_require_unchanged_core_evidence(db, kind=kind, row=row))
        expected_rankings = list(expected.get("ranking_results") or [])
        actual_rankings = rankings.get(ticker, [])
        if len(expected_rankings) != len(actual_rankings):
            raise ValueError(
                f"HISTORICAL_EVIDENCE_UNAVAILABLE: resume ranking set changed for {ticker}"
            )
        for expected_ranking, ranking in zip(expected_rankings, actual_rankings, strict=True):
            _require_manifest_artifact(
                ranking, expected_ranking, label=f"{ticker}:ranking:{ranking.ranking_profile}"
            )
            certified_ids.add(
                _require_unchanged_core_evidence(db, kind=CoreEvidenceKind.RANKING, row=ranking)
            )
        for definition in REQUIRED_HANDOFF_CONTEXT_ARTIFACTS:
            certified_ids.add(
                _require_frozen_context_evidence(
                    db,
                    definition=definition,
                    expected=expected.get(definition.key),
                    ticker=ticker,
                    pipeline=pipeline,
                    market_context=frozen_context,
                )
            )
        # Report only after this company's complete frozen evidence set passed.
        if checkpoint_callback is not None:
            checkpoint_callback(
                phase="RESUME_EVIDENCE_VALIDATED",
                processed=index,
                total=total,
                current_item=ticker,
                last_completed_item=ticker,
            )
    return {
        "historical_read_mode": "CERTIFIED_EVIDENCE",
        "certified_evidence_count": len(certified_ids),
        "decision_handoff_manifest_id": handoff.id,
        "decision_handoff_manifest_fingerprint": handoff.manifest_fingerprint,
    }


def _resume_rows_by_ticker(db: Session, model: type, run_id: int) -> dict[str, Any]:
    rows = db.scalars(select(model).where(model.run_id == run_id)).all()
    return {row.ticker.strip().upper(): row for row in rows}


def _resume_rankings_by_ticker(db: Session, run_id: int) -> dict[str, list[RankingResult]]:
    rows = db.scalars(
        select(RankingResult)
        .where(RankingResult.run_id == run_id)
        .order_by(RankingResult.ticker, RankingResult.ranking_profile, RankingResult.id)
    ).all()
    grouped: dict[str, list[RankingResult]] = {}
    for row in rows:
        grouped.setdefault(row.ticker.strip().upper(), []).append(row)
    return grouped


def _require_manifest_artifact(row: Any, expected: Any, *, label: str) -> None:
    if row is None or not isinstance(expected, dict):
        raise ValueError(f"HISTORICAL_EVIDENCE_UNAVAILABLE: resume artifact missing {label}")
    actual = {
        "id": getattr(row, "id", None),
        "semantic_hash": CanonicalEvidenceSerializer.fingerprint(
            {
                column.name: getattr(row, column.name, None)
                for column in row.__table__.columns
                if column.name not in {"created_at", "updated_at", "last_seen_at", "calculated_at"}
            }
        ),
    }
    if actual != expected:
        raise ValueError(f"HISTORICAL_EVIDENCE_UNAVAILABLE: resume artifact changed {label}")


def _require_certified_pointer(db: Session, *, kind: CoreEvidenceKind, row: Any) -> int:
    try:
        return int(get_certified_evidence_for_row(db, kind=kind, current_row=row).id)
    except EvidenceUnavailableError as exc:
        raise ValueError(str(exc)) from exc


def _require_frozen_context_evidence(
    db: Session,
    *,
    definition: RequiredHandoffContextArtifact,
    expected: Any,
    ticker: str,
    pipeline: PipelineRun,
    market_context: MarketCalculationContext,
) -> int:
    """Resolve the manifest-addressed context row, never a newer current revision."""

    try:
        if (
            not isinstance(expected, dict)
            or not isinstance(expected.get("id"), int)
            or not isinstance(expected.get("semantic_hash"), str)
        ):
            validate_required_handoff_context_artifact(
                None,
                definition=definition,
                ticker=ticker,
                upload_run_id=pipeline.upload_run_id,
                pipeline_run_id=pipeline.id,
                calculation_context_id=market_context.id,
                cutoff_at=market_context.cutoff_at,
                input_as_of_session=market_context.latest_completed_session,
                calendar_version=market_context.calendar_version,
                expected_identity=expected,
            )
        row = db.get(definition.model, int(expected["id"]))
        validate_required_handoff_context_artifact(
            row,
            definition=definition,
            ticker=ticker,
            upload_run_id=pipeline.upload_run_id,
            pipeline_run_id=pipeline.id,
            calculation_context_id=market_context.id,
            cutoff_at=market_context.cutoff_at,
            input_as_of_session=market_context.latest_completed_session,
            calendar_version=market_context.calendar_version,
            expected_identity=expected,
            allow_current_revision_transition=True,
        )
    except RequiredHandoffArtifactError as exc:
        raise ValueError(f"HISTORICAL_EVIDENCE_UNAVAILABLE: {exc}") from exc
    return _require_certified_pointer(db, kind=definition.kind, row=row)


def _require_unchanged_core_evidence(
    db: Session,
    *,
    kind: CoreEvidenceKind,
    row: Any,
) -> int:
    try:
        evidence = get_certified_evidence_for_row(db, kind=kind, current_row=row)
    except EvidenceUnavailableError as exc:
        raise ValueError(str(exc)) from exc
    # Readiness/configuration-at-creation belong to immutable evidence, not to
    # mutable compatibility columns. Reattach the retained metadata without
    # recalculating either policy; every business column still must match.
    projection = calculation_evidence_payload(row)
    from app.services.effective_configuration import CONFIGURATION_PAYLOAD_KEY
    from app.services.producer_readiness import READINESS_PAYLOAD_KEY

    config = evidence.payload_json.get(CONFIGURATION_PAYLOAD_KEY)
    if config is not None:
        from app.services.core_calculation_evidence import normalize_configuration_business_payload

        _validate_projection_source_pins(db, kind=kind, projection=projection, evidence=evidence)
        normalize_configuration_business_payload(
            projection,
            namespace=config["semantic"]["namespace"],
            source_ids=evidence.source_evidence_ids_json,
        )
    for key in (READINESS_PAYLOAD_KEY, CONFIGURATION_PAYLOAD_KEY):
        if key in evidence.payload_json:
            projection[key] = evidence.payload_json[key]
    _normalize_allowed_resume_projection_diagnostics(
        kind=kind,
        projection=projection,
        evidence_payload=evidence.payload_json,
    )
    if CanonicalEvidenceSerializer.fingerprint(projection) != evidence.payload_fingerprint:
        raise ValueError(
            "HISTORICAL_EVIDENCE_UNAVAILABLE: resume compatibility row changed after evidence "
            f"kind={kind.value} row={getattr(row, 'id', None)}"
        )
    return int(evidence.id)


def _normalize_allowed_resume_projection_diagnostics(
    *,
    kind: CoreEvidenceKind,
    projection: dict[str, Any],
    evidence_payload: dict[str, Any],
) -> None:
    """Undo only the pipeline's exact post-seal cache-fallback annotation.

    Technical scoring seals immutable business evidence before the pipeline knows
    whether it had to use the explicitly permitted cache fallback. The serving
    row is then annotated with degraded confidence/session diagnostics. Those
    four fields are non-financial (and mutation authority already treats them as
    such), but resume validation previously compared them as business changes.
    Accept the exact transform performed by ``_mark_technical_scores_degraded``;
    any additional mutation remains fail-closed.
    """

    if kind is not CoreEvidenceKind.TECHNICAL:
        return
    warning = "cache_fallback_market_data"
    evidence_warnings = list(evidence_payload.get("warning_flags_json") or [])
    expected_warnings = list(evidence_warnings)
    if warning not in expected_warnings:
        expected_warnings.append(warning)
    if projection.get("warning_flags_json") != expected_warnings:
        return
    if projection.get("technical_confidence") != "low":
        return

    evidence_quality = evidence_payload.get("data_quality_score")
    expected_quality = Decimal("6.0")
    if evidence_quality is not None:
        try:
            expected_quality = min(Decimal(str(evidence_quality)), expected_quality)
        except (ArithmeticError, ValueError):
            return
    try:
        if Decimal(str(projection.get("data_quality_score"))) != expected_quality:
            return
    except (ArithmeticError, ValueError):
        return

    evidence_missing = dict(evidence_payload.get("missing_data_json") or {})
    projection_missing = dict(projection.get("missing_data_json") or {})
    market_data = projection_missing.pop("market_data", None)
    if projection_missing != evidence_missing or not isinstance(market_data, dict):
        return
    if set(market_data) != {
        "mode",
        "ib_api_available",
        "expected_latest_session",
        "actual_latest_session",
    }:
        return
    if (
        market_data.get("mode") != "CACHE_FALLBACK"
        or market_data.get("ib_api_available") is not False
    ):
        return
    if any(
        value is not None and not isinstance(value, str)
        for value in (
            market_data.get("expected_latest_session"),
            market_data.get("actual_latest_session"),
        )
    ):
        return

    for diagnostic_field in (
        "technical_confidence",
        "data_quality_score",
        "warning_flags_json",
        "missing_data_json",
    ):
        if diagnostic_field in evidence_payload:
            projection[diagnostic_field] = evidence_payload[diagnostic_field]
        else:
            projection.pop(diagnostic_field, None)


def _validate_projection_source_pins(db, *, kind, projection, evidence):
    """Projection address normalization must never conceal a source change."""
    debug = projection.get("debug_json") or {}
    pins = evidence.source_evidence_ids_json
    if kind is CoreEvidenceKind.COMBINED:
        observed = debug.get("source_ids") or {}
        retained = (evidence.payload_json.get("debug_json") or {}).get("source_ids") or {}
        valid = observed.get("raw_row_id") == retained.get("raw_row_id")
        if any(key.endswith("_evidence_id") for key in observed):
            valid = valid and observed == retained
        else:
            valid = valid and set(observed) == {
                "raw_row_id",
                "fundamental_score_id",
                "technical_score_id",
            }
            for role, model in (("fundamental", FundamentalScore), ("technical", TechnicalScore)):
                source_id = observed.get(role + "_score_id")
                if source_id is not None:
                    source = db.get(model, source_id)
                    valid = valid and source is not None and source.evidence_id == pins.get(role)
                    continue

                # A producer can be source-certified while deliberately excluded
                # from the business calculation by consumer-readiness policy. In
                # that case the compatibility projection has no score-row address;
                # its immutable eligibility decision is the source address.
                if role == "fundamental":
                    permission = (debug.get("contextual_consumer_eligibility") or {}).get(
                        role
                    ) or {}
                    decision = permission.get("decision") or {}
                    excluded = permission.get("included") is False and decision.get("status") in {
                        "INELIGIBLE",
                        "POLICY_UNDECIDED",
                    }
                else:
                    decision = (debug.get("technical_consumer_eligibility") or {}).get(
                        "decision"
                    ) or {}
                    excluded = decision.get("status") in {
                        "INELIGIBLE",
                        "POLICY_UNDECIDED",
                    }
                valid = (
                    valid and excluded and decision.get("producer_evidence_id") == pins.get(role)
                )
        if not valid:
            raise ValueError("HISTORICAL_EVIDENCE_UNAVAILABLE: resume source evidence changed")
    permissions = debug.get("contextual_consumer_eligibility") or {}
    for role, permission in permissions.items():
        if role not in pins or not isinstance(permission, dict):
            continue
        if "source_evidence_id" in permission:
            valid = permission["source_evidence_id"] == pins[role]
        elif "source_feature_id" in permission:
            from app.models.ib_market_intelligence_tables import IBIntelligenceFeature

            source_model = FundamentalScore if role == "fundamental" else IBIntelligenceFeature
            source = db.get(source_model, permission["source_feature_id"])
            valid = source is not None and source.evidence_id == pins[role]
        else:
            valid = False
        if not valid:
            raise ValueError("HISTORICAL_EVIDENCE_UNAVAILABLE: resume contextual source changed")


def _run_ticker_count(db: Session, model: type, run_id: int, tickers=None) -> int:
    query = select(func.count(distinct(model.ticker))).where(model.run_id == run_id)
    if tickers is not None:
        query = query.where(model.ticker.in_(tickers))
    return int(
        db.scalar(query) or 0
    )


@contextmanager
def _pipeline_step(
    db: Session,
    pipeline: PipelineRun,
    step_name: str,
    *,
    lease_guard: Callable[[], None] | None = None,
    performance: PipelinePerformanceTracker | None = None,
):
    observed_started = perf_counter()
    attempt_started_at = _utcnow()

    def observe_step(status: str, reason_code: str | None = None) -> None:
        duration_seconds = max(0.0, perf_counter() - observed_started)
        operational_metrics.set_gauge("swinglens_pipeline_current_stage", 0, stage=step_name)
        operational_metrics.observe(
            "swinglens_pipeline_stage_duration_seconds",
            duration_seconds,
            stage=step_name,
            status=status,
        )
        if reason_code:
            operational_metrics.increment(
                "swinglens_pipeline_failures_total",
                stage=step_name,
                reason_code=reason_code,
            )
        log_event(
            logger,
            "pipeline.stage_finished",
            pipeline_run_id=pipeline.id,
            stage=step_name,
            status=status,
            reason_code=reason_code,
            duration_ms=round(duration_seconds * 1000, 3),
        )

    _interrupt_superseded_running_steps(
        db,
        pipeline_id=pipeline.id,
        authoritative_step=step_name,
        observed_at=attempt_started_at,
    )
    step = _require_step(db, pipeline.id, step_name)
    step_id = step.id
    if step.status in {
        PipelineStepStatus.RUNNING,
        PipelineStepStatus.COMPLETED,
        PipelineStepStatus.FAILED,
        PipelineStepStatus.BLOCKED,
        PipelineStepStatus.CANCELLED,
        PipelineStepStatus.INTERRUPTED,
    }:
        _archive_pipeline_step_attempt(step)
        step.retry_count = (step.retry_count or 0) + 1
        step.message = f"Replaying step attempt {step.retry_count + 1}."
    else:
        step.message = None
    from app.services.pipeline_state_machine import transition_pipeline

    transition_pipeline(
        db,
        pipeline,
        _pipeline_status_for_step(step_name),
        actor="pipeline_orchestrator",
        current_step=step_name,
    )
    step.status = PipelineStepStatus.RUNNING
    step.started_at = attempt_started_at
    step.completed_at = None
    step.error_message = None
    if performance is not None:
        performance.start_step(step_name)
    operational_metrics.set_gauge("swinglens_pipeline_current_stage", 1, stage=step_name)
    log_event(
        logger,
        "pipeline.stage_started",
        pipeline_run_id=pipeline.id,
        stage=step_name,
        status=PipelineStepStatus.RUNNING,
    )
    _save_progress(db, lease_guard=lease_guard)
    _report_job_stage_progress(db, pipeline, step_name)
    try:
        yield step
    except (JobLeaseLost, ControlPlaneLockTimeout):
        observe_step("LEASE_LOST", "JOB_LEASE_LOST")
        raise
    except CeriBootstrapRequiredError:
        step.status = PipelineStepStatus.PENDING
        step.completed_at = None
        step.error_message = None
        step.message = "Waiting for automatic SEC preparation."
        if performance is not None:
            performance.finish_step(step_name, PipelineStatus.PREPARING)
        _save_progress(db, lease_guard=lease_guard)
        observe_step(PipelineStatus.PREPARING)
        raise
    except PipelineBlockedError as exc:
        step.status = PipelineStepStatus.BLOCKED
        step.completed_at = _utcnow()
        step.error_message = _safe_message(str(exc))
        step.message = f"Blocked: {exc.reason_code}"
        if performance is not None:
            performance.finish_step(step_name, step.status)
        _save_progress(db, lease_guard=lease_guard)
        observe_step(step.status, exc.reason_code)
        raise
    except PipelineCancelled:
        step.status = PipelineStepStatus.CANCELLED
        step.completed_at = _utcnow()
        step.error_message = "Pipeline cancellation requested."
        if performance is not None:
            performance.finish_step(step_name, step.status)
        _save_progress(db, lease_guard=lease_guard)
        observe_step(step.status)
        raise
    except Exception as exc:
        if isinstance(db, Session):
            # Failure reporting is not a publication boundary for staged domain
            # writes. Keep only the previously committed stage/attempt state.
            db.rollback()
            step = db.get(PipelineStep, step_id)
        step.status = PipelineStepStatus.FAILED
        step.completed_at = _utcnow()
        step.error_message = _safe_message(str(exc))
        if performance is not None:
            performance.finish_step(step_name, step.status)
        _save_progress(db, lease_guard=lease_guard)
        observe_step(step.status, "UNEXPECTED")
        raise
    else:
        if step.status == PipelineStepStatus.RUNNING:
            step.status = PipelineStepStatus.COMPLETED
        step.completed_at = _utcnow()
        if performance is not None:
            performance.finish_step(step_name, step.status)
        _save_progress(db, lease_guard=lease_guard)
        _report_job_stage_progress(db, pipeline, step_name)
        observe_step(step.status)


def _archive_pipeline_step_attempt(
    step: PipelineStep,
    *,
    status: str | None = None,
    finished_at: datetime | None = None,
    reason: str | None = None,
) -> None:
    payload = dict(step.result_json or {})
    history = list(payload.get("attempt_history") or [])
    archived_status = status or step.status
    archived_finished = finished_at or step.completed_at
    record = {
        "attempt": int(step.retry_count or 0) + 1,
        "status": archived_status,
        "started_at": step.started_at.isoformat() if step.started_at else None,
        "finished_at": archived_finished.isoformat() if archived_finished else None,
        "reason": reason,
    }
    if not history or not _same_pipeline_attempt(history[-1], record):
        history.append(record)
    payload["attempt_history"] = history
    step.result_json = payload


def _same_pipeline_attempt(left: dict[str, Any], right: dict[str, Any]) -> bool:
    if any(left.get(key) != right.get(key) for key in ("attempt", "status")):
        return False
    return all(
        _normalized_attempt_instant(left.get(key)) == _normalized_attempt_instant(right.get(key))
        for key in ("started_at", "finished_at")
    )


def _normalized_attempt_instant(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _interrupt_superseded_running_steps(
    db: Session,
    *,
    pipeline_id: int,
    authoritative_step: str,
    observed_at: datetime,
) -> None:
    """Ensure a replay exposes exactly one authoritative RUNNING step."""
    for step in db.scalars(select(PipelineStep).where(PipelineStep.pipeline_run_id == pipeline_id)):
        if step.step_name == authoritative_step or step.status != PipelineStepStatus.RUNNING:
            continue
        _archive_pipeline_step_attempt(
            step,
            status=PipelineStepStatus.INTERRUPTED,
            finished_at=observed_at,
            reason="SUPERSEDED_BY_PIPELINE_REPLAY",
        )
        step.status = PipelineStepStatus.INTERRUPTED
        step.completed_at = observed_at
        step.message = f"Interrupted by replay at {authoritative_step}."
        step.error_message = None


def _report_job_stage_progress(
    db: Session,
    pipeline: PipelineRun,
    stage: str,
) -> None:
    callback = getattr(pipeline, "_job_progress_callback", None)
    if callable(callback):
        callback(db, stage=stage, current_item=None)


def _technical_job_checkpoint(
    db: Session,
    *,
    progress_callback: Callable[..., None] | None,
    lease_guard: Callable[[], None] | None,
    phase: str,
    processed: int,
    total: int,
    current_item: str | None = None,
    last_completed_item: str | None = None,
) -> None:
    if progress_callback is not None:
        progress_callback(
            db,
            stage="SCORING_TECHNICALS",
            current_item=f"{phase}:{current_item or '-'}",
            last_completed_item=(
                last_completed_item
                if phase
                in {
                    "LOADING_INPUTS",
                    "CALCULATING",
                    "CALCULATED",
                    "DECLARING_EVIDENCE",
                    "BATCH_PERSISTED",
                    "PERSISTING_EVIDENCE",
                    "PUBLISHED",
                }
                else None
            ),
            processed=(processed if phase != "VALIDATING_EVIDENCE" else None),
            total=(total if phase != "VALIDATING_EVIDENCE" else None),
            checkpoint_version="technical-recovery-v1",
            close_read_transaction=phase
            in {"LOADING_INPUTS", "INPUTS_LOADED", "DECLARING_EVIDENCE"},
            commit_mutation_transaction=phase in {"SOURCE_MANIFEST_PERSISTED", "BATCH_PERSISTED"},
        )
    elif lease_guard is not None:
        lease_guard()


def _combined_job_checkpoint(
    db: Session,
    *,
    progress_callback: Callable[..., None] | None,
    lease_guard: Callable[[], None] | None,
    phase: str,
    processed: int,
    total: int,
    current_item: str | None = None,
    last_completed_item: str | None = None,
) -> None:
    if progress_callback is not None:
        progress_callback(
            db,
            stage="COMBINING_RESULTS",
            current_item=f"{phase}:{current_item or '-'}",
            last_completed_item=last_completed_item,
            processed=processed,
            total=total,
            checkpoint_version=f"combined-recovery-v1:{phase}:{processed}",
            close_read_transaction=phase in {"INPUTS_LOADED", "DECLARING_EVIDENCE"},
            commit_mutation_transaction=phase == "BATCH_PERSISTED",
        )
    elif lease_guard is not None:
        lease_guard()


def _ranking_job_checkpoint(
    db: Session,
    *,
    progress_callback: Callable[..., None] | None,
    lease_guard: Callable[[], None] | None,
    phase: str,
    processed: int,
    total: int,
    current_item: str | None = None,
    last_completed_item: str | None = None,
) -> None:
    if progress_callback is not None:
        progress_callback(
            db,
            stage="RANKING_PROFILES",
            current_item=f"{phase}:{current_item or '-'}",
            last_completed_item=last_completed_item,
            processed=processed,
            total=total,
            checkpoint_version=f"ranking-recovery-v1:{phase}:{processed}",
            close_read_transaction=phase in {"INPUTS_LOADED", "DECLARING_EVIDENCE"},
            commit_mutation_transaction=phase == "PROFILE_PERSISTED",
        )
    elif lease_guard is not None:
        lease_guard()


def _require_pipeline(db: Session, pipeline_run_id: int) -> PipelineRun:
    pipeline = db.get(PipelineRun, pipeline_run_id)
    if pipeline is None:
        raise ValueError(f"Pipeline run {pipeline_run_id} was not found.")
    return pipeline


def _require_upload_run(db: Session, upload_run_id: int) -> UploadRun:
    upload_run = db.get(UploadRun, upload_run_id)
    if upload_run is None:
        raise ValueError(f"Upload run {upload_run_id} was not found.")
    return upload_run


def _require_step(db: Session, pipeline_run_id: int, step_name: str) -> PipelineStep:
    step = db.scalar(
        select(PipelineStep)
        .where(PipelineStep.pipeline_run_id == pipeline_run_id)
        .where(PipelineStep.step_name == step_name)
    )
    if step is None:
        raise ValueError(f"Pipeline step {step_name} was not found.")
    return step


def _tickers_for_run(db: Session, upload_run_id: int) -> list[str]:
    rows = db.scalars(
        select(RawCompanyRow.ticker)
        .where(RawCompanyRow.run_id == upload_run_id)
        .order_by(RawCompanyRow.row_number)
    )
    seen: set[str] = set()
    tickers: list[str] = []
    for value in rows:
        ticker = str(value).strip().upper()
        if ticker and ticker not in seen:
            seen.add(ticker)
            tickers.append(ticker)
    return tickers


def _validate_market_data_resume(db, pipeline, tickers, market_cutoff):
    """Prove the retained fundamentals before skipping their completed stage."""
    for name in ("VALIDATING_RUN", "SCORING_FUNDAMENTALS"):
        if _require_step(db, pipeline.id, name).status != PipelineStepStatus.COMPLETED:
            raise ValueError("MARKET_DATA_RESUME_PRIOR_STAGE_INCOMPLETE: " + name)
    retained = (pipeline.result_json or {}).get("ib_fetch_plan")
    fetch_plan_state = "RETAINED"
    initial_admission = None
    if isinstance(retained, dict):
        required = {"run_id", "requested_tickers", "symbols_including_benchmarks", "items"}
        if not required <= retained.keys() or any(
            not isinstance(retained[key], list)
            for key in ("requested_tickers", "symbols_including_benchmarks", "items")
        ):
            raise ValueError("MARKET_DATA_RESUME_FROZEN_PLAN_REQUIRED")
        try:
            restored = fetch_plan_from_dict(retained)
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError("MARKET_DATA_RESUME_FROZEN_PLAN_REQUIRED") from exc
        if (
            restored.run_id != pipeline.upload_run_id
            or sorted(restored.requested_tickers) != sorted(tickers)
            or not set(tickers) <= set(restored.symbols_including_benchmarks)
        ):
            raise ValueError("MARKET_DATA_RESUME_PLAN_SCOPE_CHANGED")
    else:
        if retained is not None:
            raise ValueError("MARKET_DATA_RESUME_FROZEN_PLAN_REQUIRED")
        initial_admission = _validate_unstarted_market_data_resume(
            db, pipeline, tickers, market_cutoff
        )
        fetch_plan_state = "NOT_ADMITTED"
    if isinstance(db, Session):
        from app.services.calculation_identity import (
            PIPELINE_CONTEXT_COMPATIBILITY,
            CalculationIdentityCompatibilityValidator,
        )
        from app.services.combined_ranking_identity import fundamental_score_identity
        from app.services.market_calculation_context_service import (
            calculation_identity_from_market_context,
        )

        rows = {
            row.ticker.upper(): row
            for row in db.scalars(
                select(FundamentalScore).where(FundamentalScore.run_id == pipeline.upload_run_id)
            )
        }
        for ticker in tickers:
            row = rows.get(ticker)
            if row is None:
                raise ValueError("MARKET_DATA_RESUME_FUNDAMENTAL_MISSING: " + ticker)
            _require_unchanged_core_evidence(db, kind=CoreEvidenceKind.FUNDAMENTAL, row=row)
            expected = calculation_identity_from_market_context(
                market_cutoff, run_id=pipeline.upload_run_id, pipeline_id=pipeline.id, ticker=ticker
            )
            comparison = CalculationIdentityCompatibilityValidator.compare(
                expected, fundamental_score_identity(row), policy=PIPELINE_CONTEXT_COMPATIBILITY
            )
            if not comparison.accepted:
                raise ValueError("MARKET_DATA_RESUME_FUNDAMENTAL_CONTEXT_CHANGED: " + ticker)
    return {
        "validated": True,
        "fundamentals_reused": len(tickers),
        "fetch_plan_state": fetch_plan_state,
        **({"initial_admission": initial_admission} if initial_admission is not None else {}),
    }


def _validate_unstarted_market_data_resume(db, pipeline, tickers, market_cutoff):
    """Permit a first admission after a Gateway failure, never replace one."""
    saved = pipeline.result_json or {}
    initial_admission = (
        CanonicalEvidenceSerializer.canonicalize({
            "contract_version": "market-data-initial-admission-v1",
            "pipeline_run_id": pipeline.id,
            "upload_run_id": pipeline.upload_run_id,
            "scope_id": getattr(pipeline, "scope_id", None),
            "refresh_cycle_id": getattr(pipeline, "refresh_cycle_id", None),
            "acquisition_plan_id": getattr(pipeline, "acquisition_plan_id", None),
            "market_calculation_context_id": market_cutoff.context_id,
            "market_cutoff_at": market_cutoff.cutoff_at,
            "input_as_of_session": market_cutoff.latest_completed_session,
        }) if market_cutoff is not None else None
    )
    checkpoint = saved.get("market_data_resume_checkpoint") or {}
    retained_initial_admission = (
        isinstance(checkpoint, dict)
        and checkpoint.get("validated") is True
        and checkpoint.get("fetch_plan_state") == "NOT_ADMITTED"
        and checkpoint.get("first_plan_admitted") is not True
        and initial_admission is not None
        and checkpoint.get("initial_admission") == initial_admission
    )
    gateway_failed_before_admission = (
        saved.get("ib_api_available_at_execution") is False
        and saved.get("ib_execution_error_code") == "IB_GATEWAY_API_UNREACHABLE"
    )
    if (
        saved.get("ib_fetch_plan") is not None
        or saved.get("ib_fetch_authority") is not None
        or (isinstance(checkpoint, dict) and checkpoint.get("first_plan_admitted") is True)
        or not (gateway_failed_before_admission or retained_initial_admission)
        or int(saved.get("ib_planned_requests") or 0) != 0
        or int(saved.get("ib_executed_requests") or 0) != 0
    ):
        raise ValueError("MARKET_DATA_RESUME_FROZEN_PLAN_REQUIRED")
    if (
        market_cutoff is None
        or latest_completed_us_trading_day() != market_cutoff.latest_completed_session
    ):
        raise ValueError("MARKET_DATA_RESUME_SESSION_CHANGED_REPLAN_REQUIRED")
    if isinstance(db, Session):
        authority = require_semantic_authority(pipeline)
        evidence = (
            select(IBFetchRun.id).where(IBFetchRun.run_id == pipeline.upload_run_id).limit(1),
            select(WorkScopeRecord.scope_id).where(
                WorkScopeRecord.parent_scope_id == authority.scope_id,
                WorkScopeRecord.scope_kind == "ib-price-acquisition",
            ).limit(1),
            select(BackgroundJob.id).where(
                BackgroundJob.job_type == IB_FETCH_JOB_TYPE,
                BackgroundJob.related_run_id == pipeline.upload_run_id,
            ).limit(1),
        )
        if any(db.scalar(statement) is not None for statement in evidence):
            raise ValueError("MARKET_DATA_RESUME_ACQUISITION_ALREADY_ADMITTED")
    return initial_admission


def _validate_first_market_data_plan(plan, pipeline, tickers, market_cutoff):
    """Bind the first newly planned request to the unchanged pipeline session."""
    expected_session = market_cutoff.latest_completed_session
    if latest_completed_us_trading_day() != expected_session:
        raise ValueError("MARKET_DATA_RESUME_SESSION_CHANGED_REPLAN_REQUIRED")
    item_tickers = {item.ticker for item in plan.items}
    if (
        plan.run_id != pipeline.upload_run_id
        or sorted(plan.requested_tickers) != sorted(tickers)
        or not set(tickers) <= item_tickers
        or not item_tickers <= set(plan.symbols_including_benchmarks)
    ):
        raise ValueError("MARKET_DATA_RESUME_PLAN_SCOPE_CHANGED")
    for item in plan.items:
        if item.freshness_threshold_date != expected_session:
            raise ValueError("MARKET_DATA_RESUME_PLAN_SESSION_CHANGED")
        if item.duration or item.post_resolution_duration:
            if item.request_end_date != expected_session or (
                item.reviewed_session_expiry is not None
                and item.reviewed_session_expiry != expected_session
            ) or (
                item.request_end_mode == "CURRENT"
                and item.reviewed_session_expiry != expected_session
            ):
                raise ValueError("MARKET_DATA_RESUME_PLAN_SESSION_CHANGED")


def _pipeline_scope_tickers(db: Session, pipeline: PipelineRun) -> list[str]:
    if not isinstance(db, Session):
        return _tickers_for_run(db, pipeline.upload_run_id)
    from app.services.scope_refresh_adoption import (
        require_semantic_authority,
        retained_scope_members,
    )

    authority = require_semantic_authority(pipeline)
    return [
        member.subject_id
        for member in retained_scope_members(db, authority.scope_id)
        if member.subject_type == "TICKER"
    ]


def _mark_pipeline_running(
    db: Session,
    pipeline: PipelineRun,
    *,
    lease_guard: Callable[[], None] | None = None,
) -> None:
    from app.services.pipeline_state_machine import transition_pipeline

    pipeline.started_at = pipeline.started_at or _utcnow()
    transition_pipeline(
        db,
        pipeline,
        PipelineStatus.RUNNING,
        actor="pipeline_orchestrator",
        message="Full pipeline is running.",
    )
    publish_after_commit(db, "set_gauge", "swinglens_pipeline_active", 1)
    _save_progress(db, lease_guard=lease_guard)


def _claim_pipeline_continuation_resume(
    db: Session,
    pipeline: PipelineRun,
) -> PipelineRun:
    """Atomically prove that a continuation still has resume authority.

    The short row lock is held only for the state check and transition.  It is
    deliberately acquired before any replay side effect so cancellation or a
    terminal winner cannot be discovered after work has already resumed.
    """

    if not isinstance(db, Session):
        if pipeline.status in {
            PipelineStatus.CANCEL_REQUESTED,
            PipelineStatus.CANCELLED,
            PipelineStatus.FAILED,
            PipelineStatus.COMPLETED,
            PipelineStatus.PARTIAL,
            PipelineStatus.BLOCKED,
        }:
            raise PipelineContinuationSuppressed(int(pipeline.id or 0), str(pipeline.status))
        return pipeline

    authoritative = db.scalar(
        select(PipelineRun)
        .where(PipelineRun.id == pipeline.id)
        .with_for_update()
        .execution_options(populate_existing=True)
    )
    if authoritative is None:
        raise ValueError(f"Pipeline run {pipeline.id} was not found.")

    if authoritative.status == PipelineStatus.CANCEL_REQUESTED:
        from app.services.pipeline_state_machine import transition_pipeline

        transition_pipeline(
            db,
            authoritative,
            PipelineStatus.CANCELLED,
            actor="pipeline_orchestrator",
            message="Pipeline cancellation completed before continuation resume.",
        )
        _cancel_unfinished_steps(db, authoritative.id)
        db.commit()
        raise PipelineContinuationSuppressed(authoritative.id, PipelineStatus.CANCELLED)

    if authoritative.status in {
        PipelineStatus.CANCELLED,
        PipelineStatus.FAILED,
        PipelineStatus.COMPLETED,
        PipelineStatus.PARTIAL,
        PipelineStatus.BLOCKED,
    }:
        raise PipelineContinuationSuppressed(authoritative.id, str(authoritative.status))

    return authoritative


def _mark_pipeline_waiting_for_ceri(
    db: Session,
    pipeline: PipelineRun,
    result: dict[str, Any],
    *,
    lease_guard: Callable[[], None] | None = None,
) -> None:
    from app.services.pipeline_state_machine import transition_pipeline

    workflow_key = str(result.get("ceri_provider_workflow_key") or "")
    if not workflow_key.startswith("ceri:pipeline:"):
        raise RuntimeError("CERI provider scheduling produced no durable workflow identity.")
    provider_step = _require_step(db, pipeline.id, CERI_PIPELINE_PROVIDER_INGEST_STEP)
    wait_started_at = _utcnow()
    performance = dict(result.get("performance") or {})
    dispatch_duration_ms = dict(performance.get("step_durations_ms") or {}).get(
        CERI_PIPELINE_PROVIDER_INGEST_STEP
    )
    async_timing = {
        "dispatch_duration_ms": dispatch_duration_ms,
        "dependency_wait_duration_ms": None,
        "child_execution_duration_ms": None,
        "total_logical_duration_ms": None,
        "dependency_wait_started_at": wait_started_at.isoformat(),
        "completed_at": None,
        "status": "WAITING_DEPENDENCY",
    }
    provider_step.result_json = {
        **(provider_step.result_json or {}),
        "async_timing": async_timing,
    }
    performance["async_step_timings"] = {
        **dict(performance.get("async_step_timings") or {}),
        CERI_PIPELINE_PROVIDER_INGEST_STEP: async_timing,
    }
    result["performance"] = performance
    provider_step.status = PipelineStepStatus.WAITING_DEPENDENCY
    provider_step.completed_at = None
    provider_step.message = "Provider workflow dispatched; waiting for required child stages."
    transition_pipeline(
        db,
        pipeline,
        PipelineStatus.WAITING_FOR_CERI_COMPLETION,
        actor="pipeline_orchestrator",
        current_step=CERI_PIPELINE_PROVIDER_INGEST_STEP,
        message="Waiting for certified CERI provider workflow completion.",
    )
    pipeline.result_json = {
        **(pipeline.result_json or {}),
        **_public_result(result),
        "ceri_completion_state": "WAITING",
        "ceri_async_state": "RUNNING_CHILD_WORKFLOW",
        "ceri_provider_workflow_key": workflow_key,
    }
    _save_progress(db, lease_guard=lease_guard)


def _mark_pipeline_finished(
    db: Session,
    pipeline: PipelineRun,
    status: str,
    result: dict[str, Any],
    *,
    lease_guard: Callable[[], None] | None = None,
) -> None:
    from app.services.pipeline_state_machine import transition_pipeline

    if isinstance(db, Session):
        from app.services.scope_refresh_adoption import (
            require_children_terminal,
            require_semantic_authority,
        )

        authority = require_semantic_authority(pipeline)
        result["semantic_child_accounting"] = require_children_terminal(db, authority.scope_id)
    publish_after_commit(db, "set_gauge", "swinglens_pipeline_active", 0)
    if (result.get("partial_scope") or result.get("sec_coverage")
            or result.get("market_data_availability")):
        from app.services.pipeline_outcome import derive_pipeline_outcome

        result["pipeline_outcome_summary"] = derive_pipeline_outcome(status, result)
        # Containment observes terminal metadata during the transition itself.
        pipeline.result_json = {**(pipeline.result_json or {}), **_public_result(result)}
    transition_pipeline(
        db,
        pipeline,
        status,
        actor="pipeline_orchestrator",
        clear_current_step=True,
        message=_completion_message(status, result),
    )
    pipeline.result_json = {
        **(pipeline.result_json or {}),
        **_public_result(result),
    }
    _save_progress(db, lease_guard=lease_guard)


def _mark_pipeline_cancelled(
    db: Session,
    pipeline: PipelineRun,
    *,
    result: dict[str, Any] | None = None,
    lease_guard: Callable[[], None] | None = None,
) -> None:
    from app.services.pipeline_state_machine import transition_pipeline

    transition_pipeline(
        db,
        pipeline,
        PipelineStatus.CANCELLED,
        actor="pipeline_orchestrator",
        message="Pipeline was cancelled.",
    )
    if result is not None:
        pipeline.result_json = {
            **(pipeline.result_json or {}),
            **_public_result(result),
        }
    _cancel_unfinished_steps(db, pipeline.id)
    _save_progress(db, lease_guard=lease_guard)


def _mark_pipeline_failed(
    db: Session,
    pipeline: PipelineRun,
    exc: Exception,
    *,
    result: dict[str, Any] | None = None,
    lease_guard: Callable[[], None] | None = None,
) -> None:
    from app.services.pipeline_state_machine import transition_pipeline

    transition_pipeline(
        db,
        pipeline,
        PipelineStatus.FAILED,
        actor="pipeline_orchestrator",
        message="Pipeline failed.",
        error_message=_safe_message(str(exc)),
    )
    if result is not None:
        pipeline.result_json = {
            **(pipeline.result_json or {}),
            **_public_result(result),
        }
    _save_progress(db, lease_guard=lease_guard)


def _mark_pipeline_blocked(
    db: Session,
    pipeline: PipelineRun,
    exc: PipelineBlockedError,
    *,
    result: dict[str, Any] | None = None,
    lease_guard: Callable[[], None] | None = None,
) -> None:
    from app.services.pipeline_state_machine import transition_pipeline

    transition_pipeline(
        db,
        pipeline,
        PipelineStatus.BLOCKED,
        actor="pipeline_orchestrator",
        message=(
            "Pipeline blocked at market-data fetching."
            if pipeline.current_step == "FETCHING_MARKET_DATA"
            else "Pipeline blocked before execution."
        ),
        error_message=_safe_message(str(exc)),
    )
    pipeline.result_json = {
        **(pipeline.result_json or {}),
        **(_public_result(result) if result is not None else {}),
        "blocked_reason": exc.reason_code,
        "blocked_diagnostics": exc.diagnostics,
    }
    _save_progress(db, lease_guard=lease_guard)


def _schedule_sec_prerequisite_repair(
    db: Session,
    pipeline: PipelineRun,
    exc: CeriBootstrapRequiredError,
    *,
    result: dict[str, Any],
    resume_from_step: str,
    lease_guard: Callable[[], None] | None = None,
    scheduler: Callable[..., Any] | None = None,
) -> None:
    from app.services.ceri.sec.readiness_repair import schedule_sec_readiness_repair

    result["sec_preflight"] = exc.diagnostics
    pipeline.result_json = {
        **(pipeline.result_json or {}),
        **_public_result(result),
    }
    schedule = scheduler or schedule_sec_readiness_repair
    schedule(
        db,
        pipeline=pipeline,
        diagnostics=exc.diagnostics,
        resume_from_step=resume_from_step,
    )


def _cancel_unfinished_steps(db: Session, pipeline_run_id: int) -> None:
    for step in db.scalars(
        select(PipelineStep).where(PipelineStep.pipeline_run_id == pipeline_run_id)
    ):
        if step.status in {PipelineStepStatus.PENDING, PipelineStepStatus.RUNNING}:
            step.status = PipelineStepStatus.CANCELLED
            step.completed_at = _utcnow()


def _save_progress(db: Session, *, lease_guard: Callable[[], None] | None = None) -> None:
    db.flush()
    commit = getattr(db, "commit", None)
    if callable(commit):
        commit()
    if lease_guard is not None:
        lease_guard()


def _raise_if_cancelled(should_cancel: Callable[[], bool]) -> None:
    if should_cancel():
        raise PipelineCancelled("Pipeline cancellation requested.")


def _resume_validation_checkpoint_callback(
    db: Session,
    *,
    stage: str,
    should_cancel: Callable[[], bool],
    progress_callback: Callable[..., None] | None,
) -> Callable[..., None]:
    def checkpoint(
        *,
        phase: str,
        processed: int,
        total: int,
        current_item: str | None = None,
        last_completed_item: str | None = None,
    ) -> None:
        _raise_if_cancelled(should_cancel)
        if progress_callback is not None:
            progress_callback(
                db,
                stage=stage,
                current_item=f"{phase}:{current_item or '-'}",
                last_completed_item=last_completed_item,
                processed=processed,
                total=total,
                checkpoint_version=f"pipeline-resume-v1:{phase}:{processed}",
                only_if_advanced=False,
            )

    return checkpoint


def _setup_capture_checkpoint_callback(
    db: Session,
    *,
    should_cancel: Callable[[], bool],
    progress_callback: Callable[..., None] | None,
) -> Callable[..., None]:
    def checkpoint(
        current_item: str,
        processed: int,
        total: int,
        *,
        phase: str = "PERSISTING",
    ) -> None:
        _raise_if_cancelled(should_cancel)
        if progress_callback is not None:
            progress_callback(
                db,
                stage=SLSE_PIPELINE_CAPTURE_STEP,
                current_item=f"{phase}:{current_item}",
                last_completed_item=current_item if processed else None,
                processed=processed,
                total=total,
                checkpoint_version=f"setup-capture-v1:{phase}:{processed}",
                only_if_advanced=False,
                close_read_transaction=phase
                in {
                    "PREPARING",
                    "SOURCE_HISTORY_LOADED",
                    "SETUP_INPUTS_BUILT",
                    "DECISION_MANIFESTS_RECONSTRUCTED",
                    "TEMPORAL_LINEAGE_VALIDATED",
                    "ARTIFACT_LINEAGE_SERIALIZED",
                },
                commit_mutation_transaction=phase == "EVIDENCE_BATCH_PERSISTED",
            )

    return checkpoint


def _setup_evaluation_checkpoint_callback(
    db: Session,
    *,
    should_cancel: Callable[[], bool],
    progress_callback: Callable[..., None] | None,
) -> Callable[..., None]:
    def checkpoint(
        *,
        phase: str,
        processed: int,
        total: int,
        current_item: str | None = None,
        last_completed_item: str | None = None,
    ) -> None:
        _raise_if_cancelled(should_cancel)
        if progress_callback is not None:
            progress_callback(
                db,
                stage=SLSE_PIPELINE_EVALUATION_STEP,
                current_item=f"{phase}:{current_item or '-'}",
                last_completed_item=last_completed_item,
                processed=processed,
                total=total,
                checkpoint_version=f"setup-evaluation-v1:{phase}:{processed}",
                only_if_advanced=False,
                operational_metadata_patch={
                    "setup_lifecycle_evaluation_progress": {
                        "phase": phase,
                        "processed": processed,
                        "total": total,
                    }
                },
            )

    return checkpoint


def _ranking_checkpoint_callback(db, *, should_cancel, progress_callback, lease_guard):
    def checkpoint(**progress):
        _raise_if_cancelled(should_cancel)
        _ranking_job_checkpoint(
            db,
            progress_callback=progress_callback,
            lease_guard=lease_guard,
            **progress,
        )

    return checkpoint


def _sector_checkpoint_callback(
    db: Session,
    *,
    should_cancel: Callable[[], bool],
    progress_callback: Callable[..., None] | None,
) -> Callable[..., None]:
    validation_metrics: dict[str, dict[str, int]] = {}
    phase_history: list[dict[str, Any]] = []
    current_phase: dict[str, Any] = {}
    phase_clock = perf_counter()

    def checkpoint(
        *,
        phase: str,
        processed: int,
        total: int,
        current_item: str | None = None,
        last_completed_item: str | None = None,
        metrics: dict[str, int] | None = None,
    ) -> None:
        nonlocal phase_clock, current_phase
        _raise_if_cancelled(should_cancel)
        observed = datetime.now(UTC).isoformat()
        clock = perf_counter()
        if phase != current_phase.get("phase"):
            if current_phase:
                phase_history.append({
                    **current_phase, "completed_at": observed,
                    "elapsed_ms": round((clock - phase_clock) * 1000),
                })
                del phase_history[:-32]
            current_phase = {"phase": phase, "started_at": observed}
            phase_clock = clock
        current_phase.update(processed=processed, total=total)
        if phase in {"INPUTS_LOADED", "SOURCE_ROWS_LOADED", "SOURCE_MANIFEST_PREPARED"}:
            close_pipeline_read_transaction(db)
        if metrics is not None:
            validation_metrics[phase] = dict(metrics)
        if progress_callback is not None:
            progress_callback(
                db,
                stage="SECTOR_ROTATION_SNAPSHOT",
                current_item=f"{phase}:{current_item or '-'}",
                last_completed_item=last_completed_item,
                processed=processed,
                total=total,
                checkpoint_version=f"sector-rotation-v1:{phase}:{processed}",
                only_if_advanced=False,
                operational_metadata_patch={
                    "sector_progress": {
                        "phase": phase,
                        "processed": processed,
                        "total": total,
                        "validation_metrics": dict(validation_metrics),
                        "phase_started_at": current_phase["started_at"],
                        "phase_elapsed_ms": round((clock - phase_clock) * 1000),
                        "phase_history": [dict(item) for item in phase_history],
                    }
                },
            )

    return checkpoint


def _handoff_checkpoint_callback(
    db: Session,
    *,
    should_cancel: Callable[[], bool],
    progress_callback: Callable[..., None] | None,
) -> Callable[..., None]:
    def checkpoint(
        *,
        phase: str,
        processed: int,
        total: int,
        current_item: str | None = None,
        last_completed_item: str | None = None,
    ) -> None:
        _raise_if_cancelled(should_cancel)
        if progress_callback is not None:
            progress_callback(
                db,
                stage=DECISION_HANDOFF_PIPELINE_STEP,
                current_item=f"{phase}:{current_item or '-'}",
                last_completed_item=last_completed_item,
                processed=processed,
                total=total,
                checkpoint_version=f"decision-handoff-v1:{phase}:{processed}",
                only_if_advanced=False,
            )

    return checkpoint


def _pipeline_has_step(db: Session, pipeline_run_id: int, step_name: str) -> bool:
    return any(
        row.step_name == step_name
        for row in db.scalars(
            select(PipelineStep).where(PipelineStep.pipeline_run_id == pipeline_run_id)
        )
    )


def _pipeline_status_for_step(step_name: str) -> str:
    if step_name in {
        PipelineStatus.SCORING_FUNDAMENTALS,
        PipelineStatus.FETCHING_MARKET_DATA,
        PipelineStatus.SCORING_TECHNICALS,
        PipelineStatus.MARKET_REGIME_SNAPSHOT,
        PipelineStatus.COMBINING_RESULTS,
        PipelineStatus.RANKING_PROFILES,
        PipelineStatus.SECTOR_ROTATION_SNAPSHOT,
        PipelineStatus.FREEZING_DECISION_HANDOFF_MANIFEST,
        PipelineStatus.CERI_PROVIDER_INGEST,
        PipelineStatus.CERI_CAPTURE_SNAPSHOT,
        PipelineStatus.CAPTURING_SETUP_SIGNALS,
        PipelineStatus.EVALUATING_SETUP_LIFECYCLES,
        PipelineStatus.CAPTURING_WINNER_PREDICTIONS,
    }:
        return step_name
    return PipelineStatus.RUNNING


def _apply_fetch_result(result: dict[str, Any], fetch_run: IBFetchRun) -> None:
    result["ib_fetch_run_id"] = fetch_run.id
    result["ib_executed_requests"] = fetch_run.executed_request_count or 0
    result["ib_success_count"] = fetch_run.success_count or 0
    result["ib_failure_count"] = fetch_run.failure_count or 0
    result["ib_skipped_count"] = fetch_run.skipped_count or 0
    result["fetch_failed"] = int(fetch_run.status in {"FAILED", "PARTIAL"})
    result["fresh_fetch_count"] = fetch_run.success_count or 0


def _market_data_policy(pipeline: PipelineRun) -> MarketDataPolicy:
    raw_policy = (pipeline.result_json or {}).get(
        "market_data_policy",
        MarketDataPolicy.REQUIRE_IB.value,
    )
    try:
        return MarketDataPolicy(raw_policy)
    except ValueError:
        return MarketDataPolicy.REQUIRE_IB


def _apply_ib_execution_status(
    result: dict[str, Any],
    status: IBGatewayHealthStatus,
) -> None:
    operational_metrics.set_gauge("swinglens_ib_connected", float(status.api_connected))
    result["ib_execution_status"] = status.status
    result["ib_execution_checked_at"] = status.checked_at.isoformat()
    result["ib_api_available_at_execution"] = status.api_connected
    result["ib_execution_error_code"] = status.error_code


def _is_historical_data_ready(status: IBHistoricalCapabilityStatus | Any) -> bool:
    ready = getattr(status, "ready", None)
    if isinstance(ready, bool):
        return ready
    return str(getattr(status, "status", status)) == "IB_HISTORICAL_DATA_READY"


def _historical_capability_payload(status: IBHistoricalCapabilityStatus | Any) -> dict[str, Any]:
    serializer = getattr(status, "to_dict", None)
    if callable(serializer):
        return dict(serializer())
    checked_at = getattr(status, "checked_at", None)
    return {
        "status": str(getattr(status, "status", "IB_HISTORICAL_DATA_DEGRADED")),
        "checked_at": checked_at.isoformat() if hasattr(checked_at, "isoformat") else None,
        "ticker": str(getattr(status, "ticker", "SPY")),
        "feeds": list(getattr(status, "feeds", ())),
        "server_version": getattr(status, "server_version", None),
        "api_ready": bool(getattr(status, "api_ready", False)),
        "result": str(getattr(status, "result", "FAILED")),
        "message": str(getattr(status, "message", "Historical capability probe failed.")),
    }


def _apply_market_session_metadata(result: dict[str, Any], plan: FetchPlan) -> None:
    expected = [
        item.freshness_threshold_date for item in plan.items if item.freshness_threshold_date
    ]
    actual = [
        item.latest_bar_date
        for item in plan.items
        if item.ticker in plan.requested_tickers and item.latest_bar_date is not None
    ]
    result["latest_expected_market_session"] = max(expected).isoformat() if expected else None
    result["actual_latest_data_session"] = min(actual).isoformat() if actual else None


def _cached_ticker_count(plan: FetchPlan) -> int:
    return len(
        {
            item.ticker
            for item in plan.items
            if item.ticker in plan.requested_tickers and item.latest_bar_date is not None
        }
    )


def _mark_technical_scores_degraded(
    scores: list[Any],
    result: dict[str, Any],
) -> None:
    warning = "cache_fallback_market_data"
    for score in scores:
        score.technical_confidence = "low"
        current_quality = getattr(score, "data_quality_score", None)
        if current_quality is None or Decimal(str(current_quality)) > Decimal("6.0"):
            score.data_quality_score = Decimal("6.0")
        warnings = list(getattr(score, "warning_flags_json", None) or [])
        if warning not in warnings:
            warnings.append(warning)
        score.warning_flags_json = warnings
        missing = dict(getattr(score, "missing_data_json", None) or {})
        missing["market_data"] = {
            "mode": "CACHE_FALLBACK",
            "ib_api_available": False,
            "expected_latest_session": result.get("latest_expected_market_session"),
            "actual_latest_session": result.get("actual_latest_data_session"),
        }
        score.missing_data_json = missing


def _plan_skips_ticker(plan: FetchPlan, ticker: str) -> bool:
    items = [item for item in plan.items if item.ticker == ticker]
    return bool(items) and all(item.action == FetchAction.SKIP for item in items)


def _require_market_data_dependencies(db, pipeline, plan, fetch_run, market_cutoff):
    from app.services.price_bar_repository import load_price_bar_rows_for_context

    items = list(db.scalars(select(IBFetchItem).where(
        IBFetchItem.fetch_run_id == fetch_run.id
    ))) if fetch_run is not None else []
    hazards = list(fetch_execution_hazards(fetch_run, plan, items))
    retained = (pipeline.result_json or {}).get("ib_fetch_plan")
    complete_plan = fetch_plan_from_dict(retained) if isinstance(retained, dict) else plan
    required = {(item.ticker, item.what_to_show) for item in complete_plan.items
                if required_dependency(item)}
    if required:
        bars = load_price_bar_rows_for_context(
            db, tuple(sorted({ticker for ticker, _ in required})),
            what_to_show=("ADJUSTED_LAST", "TRADES"), timeframes=("1 day",),
            max_session=market_cutoff.latest_completed_session,
            as_of=market_cutoff.cutoff_at, calculation_context_id=market_cutoff.context_id,
        )
        current = {(bar.ticker, bar.what_to_show) for bar in bars
                   if bar.bar_date == market_cutoff.latest_completed_session}
        hazards.extend(f"REQUIRED_SESSION_UNAVAILABLE:{ticker}:{feed}"
                       for ticker, feed in sorted(required - current))
    if hazards:
        raise PipelineBlockedError(
            "Market-data infrastructure or required dependency is unavailable: "
            + ",".join(hazards),
            reason_code="MARKET_DATA_REQUIRED_INPUT_BLOCKED",
            diagnostics={"hard_failures": hazards},
        )


def _apply_fetch_performance(
    performance: PipelinePerformanceTracker,
    fetch_run: IBFetchRun,
) -> None:
    values = getattr(fetch_run, "_performance", {}) or {}
    for name in ("ib_pacing_wait_ms", "ib_network_ms", "bar_cache_write_ms"):
        performance.set_metric(name, values.get(name))


def _technical_error_count(scores: list[Any]) -> int:
    return sum(
        bool(getattr(score, "insufficient_data", False))
        or getattr(score, "technical_confidence", None) in {"low", "error"}
        for score in scores
    )


def _final_pipeline_status(result: dict[str, Any]) -> str:
    if result["combined_results"] <= 0:
        return PipelineStatus.FAILED
    if (
        result["incomplete_rows"]
        or result["warning_rows"]
        or result["ib_failure_count"]
        or result.get("market_data_excluded_count", 0)
        or result.get("market_data_unavailable_count", 0)
        or result.get("market_data_history_gap_count", 0)
        or result["technical_error_count"]
        or result["fetch_failed"]
        or result["market_regime_low_confidence"]
        or result["ceri_failed"]
        or result["setup_lifecycle_failed"]
        or result["winner_prediction_failed"]
    ):
        return PipelineStatus.PARTIAL
    return PipelineStatus.COMPLETED


def _completion_message(status: str, result: dict[str, Any]) -> str:
    winner_summary = _winner_completion_summary(result)
    unresolved = int(result.get("sec_unresolved_count") or 0)
    if unresolved:
        winner_summary += f" SEC source coverage remains unresolved for {unresolved} tickers."
    if status == PipelineStatus.COMPLETED:
        return (
            f"Pipeline completed with {result['combined_results']} combined rows.{winner_summary}"
        )
    if status == PipelineStatus.PARTIAL:
        excluded = int(result.get("market_data_excluded_count") or 0)
        return (
            f"Pipeline completed partially with {result['combined_results']} combined rows, "
            f"{result['incomplete_rows']} incomplete rows, and "
            f"{result['ib_failure_count']} IB failures."
            + (f" {excluded} tickers excluded from the original universe." if excluded else "")
            + winner_summary
        )
    return "Pipeline failed before combined results were produced."


def _winner_completion_summary(result: dict[str, Any]) -> str:
    inserted = int(result.get("winner_prediction_inserted") or 0)
    excluded = int(result.get("winner_prediction_excluded") or 0)
    failed = int(result.get("winner_prediction_failed") or 0)
    if excluded <= 0 and failed <= 0:
        return ""
    return f" Winner Evidence: {inserted} inserted, {excluded} excluded, {failed} failed."


def _retain_sec_preflight_coverage(result: dict[str, Any]) -> None:
    preflight = result.get("sec_preflight") or {}
    coverage = preflight.get("sec_coverage")
    # Explicit None clears an invalid or superseded retained projection when
    # terminal result state is merged back into the parent pipeline.
    result["sec_coverage"] = coverage
    result["sec_unresolved_count"] = int(preflight.get("sec_unresolved_count") or 0)
    result["sec_unresolved_tickers"] = list(preflight.get("sec_unresolved_tickers") or [])


def _empty_result(pipeline: PipelineRun, upload_run: UploadRun) -> dict[str, Any]:
    return {
        "pipeline_run_id": pipeline.id,
        "upload_run_id": upload_run.id,
        "uploaded_rows": (
            len(pipeline.result_json["partial_scope"]["requested_tickers"])
            if (pipeline.result_json or {}).get("partial_scope")
            else upload_run.row_count or 0
        ),
        "partial_scope": (pipeline.result_json or {}).get("partial_scope"),
        **({"market_data_availability_policy":
            pipeline.result_json["market_data_availability_policy"]}
           if (pipeline.result_json or {}).get("market_data_availability_policy") else {}),
        **({"market_data_recovery_source": pipeline.result_json["market_data_recovery_source"]}
           if (pipeline.result_json or {}).get("market_data_recovery_source") else {}),
        "market_data_unavailable_count": 0,
        "market_data_history_gap_count": 0,
        **({
            "sec_coverage": pipeline.result_json["sec_coverage"],
            "sec_unresolved_count": int(pipeline.result_json.get("sec_unresolved_count") or 0),
            "sec_unresolved_tickers": list(
                pipeline.result_json.get("sec_unresolved_tickers") or []
            ),
        } if (pipeline.result_json or {}).get("sec_coverage") is not None else {}),
        "market_data_excluded_count": len(
            ((pipeline.result_json or {}).get("partial_scope") or {}).get("excluded_tickers", [])
        ),
        "fundamental_scores": 0,
        "ib_planned_requests": 0,
        "ib_executed_requests": 0,
        "ib_success_count": 0,
        "ib_failure_count": 0,
        "ib_skipped_count": 0,
        "market_data_policy": MarketDataPolicy.REQUIRE_IB.value,
        "market_data_mode": None,
        "degraded": False,
        "ib_execution_status": None,
        "ib_execution_checked_at": None,
        "ib_api_available_at_execution": None,
        "ib_execution_error_code": None,
        "fresh_fetch_count": 0,
        "cache_used_count": 0,
        "latest_expected_market_session": None,
        "actual_latest_data_session": None,
        "failure_reason": None,
        "technical_scores": 0,
        "technical_error_count": 0,
        "market_regime_snapshots": 0,
        "market_regime": None,
        "market_risk_state": None,
        "market_regime_confidence": None,
        "market_regime_warning_count": 0,
        "market_regime_low_confidence": 0,
        "combined_results": 0,
        "ranking_profiles": 0,
        "ranking_results": 0,
        "ranking_status": PipelineStepStatus.PENDING,
        "ranking_reason": None,
        "sector_rotation_snapshots": 0,
        "sector_rotation_sector_count": 0,
        "sector_rotation_leading_sector": None,
        "sector_rotation_weakest_sector": None,
        "sector_rotation_warning_count": 0,
        "ceri_score_snapshots": 0,
        "ceri_change_events": 0,
        "ceri_alerts": 0,
        "ceri_unrated": 0,
        "ceri_quarantined": 0,
        "ceri_conflicted": 0,
        "ceri_stale": 0,
        "ceri_failed": 0,
        "ceri_capture_skipped": 0,
        "setup_lifecycle_snapshots_captured": 0,
        "setup_lifecycle_canonical_snapshots": 0,
        "setup_lifecycle_change_events": 0,
        "setup_lifecycle_transitions": 0,
        "setup_lifecycle_alerts": 0,
        "setup_lifecycle_active_episodes": 0,
        "setup_lifecycle_low_confidence": 0,
        "setup_lifecycle_failed": 0,
        "setup_lifecycle_capture_skipped": 0,
        "setup_lifecycle_evaluation_skipped": 0,
        "winner_prediction_inserted": 0,
        "winner_prediction_duplicate": 0,
        "winner_prediction_excluded": 0,
        "winner_prediction_failed": 0,
        "winner_prediction_planned": 0,
        "winner_prediction_attempted": 0,
        "winner_prediction_failure_ratio": 0.0,
        "winner_prediction_exclusion_reasons": {},
        "winner_prediction_failure_classifications": {},
        "winner_prediction_representative_failures": [],
        "winner_prediction_pending_outcomes": 0,
        "winner_prediction_decision_time_estimates": 0,
        "winner_prediction_capture_skipped": 0,
        "incomplete_rows": 0,
        "warning_rows": 0,
        "fetch_failed": 0,
    }


def _to_execution_result(
    pipeline: PipelineRun,
    result: dict[str, Any],
) -> PipelineExecutionResult:
    return PipelineExecutionResult(
        pipeline_run_id=pipeline.id,
        upload_run_id=result["upload_run_id"],
        status=pipeline.status,
        uploaded_rows=result["uploaded_rows"],
        fundamental_scores=result["fundamental_scores"],
        ib_planned_requests=result["ib_planned_requests"],
        ib_executed_requests=result["ib_executed_requests"],
        ib_success_count=result["ib_success_count"],
        ib_failure_count=result["ib_failure_count"],
        ib_skipped_count=result["ib_skipped_count"],
        technical_scores=result["technical_scores"],
        market_regime_snapshots=result["market_regime_snapshots"],
        market_regime=result["market_regime"],
        market_risk_state=result["market_risk_state"],
        market_regime_confidence=result["market_regime_confidence"],
        market_regime_warning_count=result["market_regime_warning_count"],
        combined_results=result["combined_results"],
        ranking_profiles=result["ranking_profiles"],
        ranking_results=result["ranking_results"],
        ranking_status=result["ranking_status"],
        ranking_reason=result["ranking_reason"],
        sector_rotation_snapshots=result["sector_rotation_snapshots"],
        sector_rotation_sector_count=result["sector_rotation_sector_count"],
        sector_rotation_leading_sector=result["sector_rotation_leading_sector"],
        sector_rotation_weakest_sector=result["sector_rotation_weakest_sector"],
        sector_rotation_warning_count=result["sector_rotation_warning_count"],
        ceri_score_snapshots=result["ceri_score_snapshots"],
        ceri_change_events=result["ceri_change_events"],
        ceri_alerts=result["ceri_alerts"],
        ceri_unrated=result["ceri_unrated"],
        ceri_quarantined=result["ceri_quarantined"],
        ceri_conflicted=result["ceri_conflicted"],
        ceri_stale=result["ceri_stale"],
        ceri_failed=result["ceri_failed"],
        ceri_capture_skipped=result["ceri_capture_skipped"],
        setup_lifecycle_snapshots_captured=result["setup_lifecycle_snapshots_captured"],
        setup_lifecycle_canonical_snapshots=result["setup_lifecycle_canonical_snapshots"],
        setup_lifecycle_change_events=result["setup_lifecycle_change_events"],
        setup_lifecycle_transitions=result["setup_lifecycle_transitions"],
        setup_lifecycle_alerts=result["setup_lifecycle_alerts"],
        setup_lifecycle_active_episodes=result["setup_lifecycle_active_episodes"],
        setup_lifecycle_low_confidence=result["setup_lifecycle_low_confidence"],
        setup_lifecycle_failed=result["setup_lifecycle_failed"],
        setup_lifecycle_capture_skipped=result["setup_lifecycle_capture_skipped"],
        setup_lifecycle_evaluation_skipped=result["setup_lifecycle_evaluation_skipped"],
        winner_prediction_inserted=result["winner_prediction_inserted"],
        winner_prediction_duplicate=result["winner_prediction_duplicate"],
        winner_prediction_excluded=result["winner_prediction_excluded"],
        winner_prediction_failed=result["winner_prediction_failed"],
        winner_prediction_pending_outcomes=result["winner_prediction_pending_outcomes"],
        winner_prediction_decision_time_estimates=result[
            "winner_prediction_decision_time_estimates"
        ],
        winner_prediction_capture_skipped=result["winner_prediction_capture_skipped"],
        incomplete_rows=result["incomplete_rows"],
        warning_rows=result["warning_rows"],
        performance=result.get("performance", {}),
        sec_coverage=result.get("sec_coverage"),
        sec_unresolved_count=int(result.get("sec_unresolved_count") or 0),
        sec_unresolved_tickers=list(result.get("sec_unresolved_tickers") or []),
        pipeline_outcome_summary=result.get("pipeline_outcome_summary"),
    )


def _public_result(result: dict[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in result.items()
        if key
        not in {
            "fetch_failed",
            "technical_error_count",
            "market_regime_low_confidence",
        }
    }


def _record_performance_metrics(db: Session, status: str, performance: dict[str, Any]) -> None:
    publish_after_commit(db, "increment", "swinglens_pipeline_runs_total", status=status)
    publish_after_commit(db, "increment", "swinglens_pipelines_finished_total", status=status)
    publish_after_commit(
        db,
        "observe",
        "swinglens_pipeline_duration_seconds",
        float(performance.get("pipeline_wall_ms") or 0) / 1000.0,
        status=status,
    )


def _safe_message(message: str) -> str:
    return str(redact_sensitive(message)).replace("\n", " ").strip()[:500]


def _setup_lifecycle_pipeline_step_enabled(dependencies: PipelineExecutionDependencies) -> bool:
    if dependencies.setup_lifecycle_pipeline_step_enabled is not None:
        return dependencies.setup_lifecycle_pipeline_step_enabled
    return get_settings().setup_lifecycle_pipeline_step_enabled


def _setup_capture_handoff_enabled(dependencies: PipelineExecutionDependencies) -> bool:
    if dependencies.setup_capture_handoff_enabled is not None:
        return dependencies.setup_capture_handoff_enabled
    return get_settings().setup_capture_handoff_enabled


def _ceri_run_capture_enabled(dependencies: PipelineExecutionDependencies) -> bool:
    if not ceri_flags().enabled:
        return False
    if dependencies.ceri_run_capture_enabled is not None:
        return dependencies.ceri_run_capture_enabled
    return ceri_flags().run_capture


def _ceri_provider_ingest_enabled(dependencies: PipelineExecutionDependencies) -> bool:
    if not ceri_flags().enabled:
        return False
    if dependencies.ceri_provider_ingest_enabled is not None:
        return dependencies.ceri_provider_ingest_enabled
    settings = get_settings()
    return ceri_flags().provider_ingest and bool(
        settings.ceri_legacy_pipeline_scheduling_enabled or settings.ceri_batched_workflow_enabled
    )


if TYPE_CHECKING:
    from app.services.ceri.batched_workflow import CeriBatchedWorkflowPlan


def _schedule_ceri_provider_ingest(
    db: Session,
    run_id: int,
    *,
    market_cutoff: MarketCalculationCutoff | None = None,
) -> int | CeriBatchedWorkflowPlan:
    """Queue provider-specific ingestion jobs for the current SwingLens run."""
    settings = get_settings()
    # Pipeline-owned provider work must have one durable finalizer/capture tail.
    # Even installations retaining the legacy admin scheduler therefore use the
    # batched workflow whenever a frozen pipeline context is supplied.
    if market_cutoff is not None or getattr(settings, "ceri_batched_workflow_enabled", False):
        from app.services.ceri.batched_workflow import schedule_ceri_batched_workflow

        if market_cutoff is not None:
            return schedule_ceri_batched_workflow(
                db, run_id, market_cutoff=market_cutoff
            )
        return schedule_ceri_batched_workflow(db, run_id).provider_batches
    if not getattr(settings, "ceri_legacy_pipeline_scheduling_enabled", True):
        return 0
    from app.models.ceri_tables import CeriCompany
    from app.services.ceri.enums import CeriDataset
    from app.services.ceri.provider_registry import CeriProviderRegistry

    tickers = sorted(
        {
            row.ticker.upper()
            for row in db.scalars(select(RawCompanyRow).where(RawCompanyRow.run_id == run_id))
            if row.ticker
        }
    )
    existing_companies = {
        (company.ticker.upper(), (company.exchange or "").upper())
        for company in db.scalars(select(CeriCompany))
    }
    for ticker in tickers:
        if (ticker, "US") in existing_companies:
            continue
        db.add(
            CeriCompany(
                ticker=ticker,
                exchange="US",
                current_provider_ids_json={"eodhd": f"{ticker}.US"},
            )
        )
        existing_companies.add((ticker, "US"))
    db.flush()

    registry = CeriProviderRegistry()
    datasets_by_provider = {
        "eodhd": (CeriDataset.ESTIMATES, CeriDataset.EARNINGS, CeriDataset.CATALYSTS),
        "sec": (CeriDataset.GUIDANCE,),
    }
    dataset_priorities = {
        CeriDataset.ESTIMATES: 80,
        CeriDataset.EARNINGS: 90,
        CeriDataset.CATALYSTS: 100,
        # SEC guidance may scan several filings. Keep it behind the inputs
        # needed to produce the first run score snapshots.
        CeriDataset.GUIDANCE: 120,
    }
    scheduled = 0
    for ticker in tickers:
        for provider, datasets in datasets_by_provider.items():
            try:
                capabilities = registry.capabilities(provider)
            except Exception:
                continue
            for dataset in datasets:
                if dataset not in capabilities.datasets:
                    continue
                request_key = f"ceri:pipeline:{run_id}:{provider}:{dataset.value}:{ticker}"
                enqueue_job(
                    db,
                    CERI_PROVIDER_INGEST,
                    {
                        "provider": provider,
                        "dataset": dataset.value,
                        "ticker": ticker,
                        "run_id": run_id,
                        "request_key": request_key,
                        "scope": {"ticker": ticker, "run_id": run_id},
                        **(
                            {
                                "cutoff_at": market_cutoff.cutoff_at.isoformat(),
                                "as_of_session": market_cutoff.latest_completed_session.isoformat(),
                                "calendar_version": market_cutoff.calendar_version,
                                "calculation_context_id": market_cutoff.context_id,
                            }
                            if market_cutoff is not None
                            else {}
                        ),
                    },
                    related_run_id=run_id,
                    request_key=request_key,
                    priority=dataset_priorities[dataset],
                )
                scheduled += 1
    db.flush()
    return scheduled


def _ceri_provider_workflow_key(run_id: int, scheduled: Any) -> str:
    value = getattr(scheduled, "workflow_key", None)
    if value:
        return str(value)
    from app.services.ceri.config import load_ceri_config

    return f"ceri:pipeline:{run_id}:{load_ceri_config().config_hash}"


def _winner_probability_capture_enabled(dependencies: PipelineExecutionDependencies) -> bool:
    if dependencies.winner_probability_capture_enabled is not None:
        return dependencies.winner_probability_capture_enabled
    return get_settings().winner_probability_capture_in_pipeline


def _fetch_technical_overlap_enabled(dependencies: PipelineExecutionDependencies) -> bool:
    if dependencies.fetch_technical_overlap_enabled is not None:
        return dependencies.fetch_technical_overlap_enabled
    return get_settings().fetch_technical_overlap_enabled


def _accepts_keyword(callable_obj: Callable[..., Any], keyword: str) -> bool:
    try:
        parameters = signature(callable_obj).parameters
    except (TypeError, ValueError):
        return True
    return keyword in parameters or any(
        parameter.kind == Parameter.VAR_KEYWORD for parameter in parameters.values()
    )


def _capture_ceri_snapshot(
    db: Session,
    run_id: int,
    *,
    market_cutoff: MarketCalculationCutoff | None = None,
):
    from app.services.ceri.capture_service import CeriRunCaptureService

    return CeriRunCaptureService().capture_run(db, run_id, market_cutoff=market_cutoff)


def _invoke_winner_capture(
    capture: Callable[..., Any],
    db: Session,
    run_id: int,
    *,
    market_cutoff: MarketCalculationCutoff | None,
    decision_handoff_manifest_id: int | None,
    should_cancel: Callable[[], bool] | None,
    lease_guard: Callable[[], None] | None,
    progress_callback: Callable[..., None] | None,
    memory_probe: Callable[..., None] | None,
) -> Any:
    from app.services.winner_probability.capture_service import (
        WinnerPredictionCaptureCancelled,
    )

    optional = {
        "market_cutoff": market_cutoff,
        "decision_handoff_manifest_id": decision_handoff_manifest_id,
        "should_cancel": should_cancel,
        "lease_guard": lease_guard,
        "progress_callback": progress_callback,
        "memory_probe": memory_probe,
    }
    kwargs = {
        name: value
        for name, value in optional.items()
        if value is not None and _accepts_keyword(capture, name)
    }
    try:
        return capture(db, run_id, **kwargs)
    except WinnerPredictionCaptureCancelled as exc:
        raise PipelineCancelled(str(exc)) from exc


def _capture_winner_predictions(
    db: Session,
    run_id: int,
    **kwargs: Any,
):
    from app.services.winner_probability.capture_service import WinnerPredictionCaptureService

    return WinnerPredictionCaptureService().capture_run(db, run_id=run_id, **kwargs)


def _capture_setup_signals(
    db: Session,
    run_id: int,
    *,
    market_cutoff: MarketCalculationCutoff | None = None,
    frozen_tickers: tuple[str, ...] | None = None,
    should_cancel: Callable[[], bool] | None = None,
    checkpoint_callback: Callable[..., None] | None = None,
):
    from app.services.setup_lifecycle.snapshot_builder import (
        SetupLifecycleCaptureCancelled,
        SetupLifecycleSnapshotCaptureService,
    )

    try:
        return SetupLifecycleSnapshotCaptureService().capture_snapshots_for_run(
            db,
            run_id,
            market_cutoff=market_cutoff,
            frozen_tickers=frozen_tickers,
            should_cancel=should_cancel,
            progress_callback=checkpoint_callback,
        )
    except SetupLifecycleCaptureCancelled as exc:
        raise PipelineCancelled(str(exc)) from exc


def _retain_setup_capture_handoff(step, capture_result):
    from app.services.setup_lifecycle.snapshot_builder import SnapshotCaptureResult

    if isinstance(capture_result, SnapshotCaptureResult):
        step.result_json = {
            **(step.result_json or {}),
            "setup_capture_handoff": asdict(capture_result),
        }


def _retained_setup_capture_handoff(db, pipeline_id):
    from app.services.setup_lifecycle.snapshot_builder import SnapshotCaptureResult

    step = _require_step(db, pipeline_id, SLSE_PIPELINE_CAPTURE_STEP)
    payload = (step.result_json or {}).get("setup_capture_handoff")
    if step.status != PipelineStepStatus.COMPLETED or payload is None:
        return None
    return SnapshotCaptureResult(**{**payload, "snapshot_ids": tuple(payload["snapshot_ids"])})


def _evaluate_setup_lifecycles(
    db: Session,
    run_id: int,
    *,
    capture_result: Any | None = None,
    market_cutoff: MarketCalculationCutoff | None = None,
    pipeline_run_id: int | None = None,
    progress_callback: Callable[..., None] | None = None,
):
    from app.services.setup_lifecycle.evaluation_service import (
        SetupLifecycleEvaluationService,
    )

    return SetupLifecycleEvaluationService().evaluate_run(
        db,
        run_id,
        capture_result=capture_result,
        market_cutoff=market_cutoff,
        pipeline_run_id=pipeline_run_id,
        progress_callback=progress_callback,
    )


def _invoke_setup_evaluation(
    evaluate: Callable[..., Any],
    db: Session,
    run_id: int,
    *,
    capture_result: Any | None,
    market_cutoff: MarketCalculationCutoff,
    pipeline_run_id: int,
    progress_callback: Callable[..., None] | None = None,
    capture_handoff_enabled: bool | None = None,
) -> Any:
    log_event(
        logger, "setup.lifecycle.evaluation_inputs", pipeline_run_id=pipeline_run_id,
        run_id=run_id, capture_handoff_enabled=capture_handoff_enabled,
        capture_handoff_supplied=capture_result is not None,
        capture_path="STAGE_HANDOFF" if capture_result is not None else "INTERNAL_RECAPTURE",
    )
    parameters = signature(evaluate).parameters.values()
    names = {parameter.name for parameter in parameters}
    accepts_kwargs = any(parameter.kind == Parameter.VAR_KEYWORD for parameter in parameters)
    required = {"market_cutoff", "pipeline_run_id"}
    if not accepts_kwargs and not required.issubset(names):
        raise TypeError(
            "Pipeline setup lifecycle evaluator must accept market_cutoff and pipeline_run_id."
        )
    kwargs: dict[str, Any] = {
        "market_cutoff": market_cutoff,
        "pipeline_run_id": pipeline_run_id,
    }
    if capture_result is not None:
        if not accepts_kwargs and "capture_result" not in names:
            raise TypeError("Setup lifecycle evaluator does not accept capture_result handoff.")
        kwargs["capture_result"] = capture_result
    if progress_callback is not None and (accepts_kwargs or "progress_callback" in names):
        kwargs["progress_callback"] = progress_callback
    return evaluate(db, run_id, **kwargs)


def _apply_ceri_capture_result(result: dict[str, Any], ceri_result: Any) -> None:
    values = ceri_result.as_dict() if hasattr(ceri_result, "as_dict") else dict(ceri_result)
    result["ceri_score_snapshots"] = int(
        values.get("score_snapshots", values.get("snapshots_captured", 0))
    )
    result["ceri_change_events"] = int(values.get("change_events", values.get("changes", 0)))
    result["ceri_alerts"] = int(values.get("alerts", 0))
    result["ceri_unrated"] = int(values.get("unrated", 0))
    result["ceri_quarantined"] = int(values.get("quarantined", 0))
    result["ceri_conflicted"] = int(values.get("conflicted", 0))
    result["ceri_stale"] = int(values.get("stale", 0))
    result["ceri_failed"] = int(values.get("failed", 0))
    result["ceri_capture_skipped"] = int(values.get("skipped", 0))


def _apply_winner_capture_result(
    result: dict[str, Any],
    capture_result: Any,
    *,
    performance: PipelinePerformanceTracker | None = None,
) -> None:
    values = (
        capture_result.as_dict() if hasattr(capture_result, "as_dict") else dict(capture_result)
    )
    result["winner_prediction_inserted"] = int(values.get("inserted", 0))
    result["winner_prediction_duplicate"] = int(values.get("duplicate", 0))
    result["winner_prediction_excluded"] = int(values.get("excluded", 0))
    result["winner_prediction_failed"] = int(values.get("failed", 0))
    result["winner_prediction_planned"] = int(values.get("planned", 0))
    result["winner_prediction_attempted"] = int(values.get("attempted", 0))
    result["winner_prediction_failure_ratio"] = float(values.get("failure_ratio", 0.0))
    result["winner_prediction_exclusion_reasons"] = dict(values.get("exclusion_reasons") or {})
    result["winner_prediction_failure_classifications"] = dict(
        values.get("failure_classifications") or {}
    )
    result["winner_prediction_representative_failures"] = list(
        values.get("representative_failures") or ()
    )
    result["winner_prediction_pending_outcomes"] = int(values.get("pending_outcomes", 0))
    result["winner_prediction_decision_time_estimates"] = int(
        values.get("decision_time_estimates", 0)
    )
    if performance is not None:
        for name, value in (values.get("performance") or {}).items():
            performance.set_metric(name, value)


def _apply_winner_step_outcome(step: PipelineStep, capture_result: Any) -> None:
    values = (
        capture_result.as_dict() if hasattr(capture_result, "as_dict") else dict(capture_result)
    )
    failed = int(values.get("failed", 0))
    if failed <= 0:
        return
    inserted = int(values.get("inserted", 0))
    duplicate = int(values.get("duplicate", 0))
    excluded = int(values.get("excluded", 0))
    attempted = int(values.get("attempted", 0))
    failure_ratio = float(values.get("failure_ratio", failed / attempted if attempted else 1.0))
    classifications = values.get("failure_classifications") or {}
    dominant = max(classifications, key=classifications.get) if classifications else "UNCLASSIFIED"
    step.status = PipelineStepStatus.FAILED
    step.message = (
        f"Winner Evidence degraded: {inserted} inserted, {duplicate} duplicate, "
        f"{excluded} excluded, {failed} failed."
    )
    step.error_message = (
        f"{failed} of {attempted or failed} Winner items failed "
        f"({failure_ratio:.1%}); dominant failure: {dominant}."
    )


def _apply_setup_lifecycle_capture_result(
    result: dict[str, Any],
    capture_result: Any,
    *,
    performance: PipelinePerformanceTracker | None = None,
) -> None:
    values = (
        capture_result.as_dict() if hasattr(capture_result, "as_dict") else dict(capture_result)
    )
    result["setup_lifecycle_snapshots_captured"] = int(
        values.get("snapshots_captured", values.get("captured", 0))
    )
    result["setup_lifecycle_canonical_snapshots"] = int(
        values.get("canonical_snapshots", values.get("canonical", 0))
    )
    result["setup_lifecycle_low_confidence"] += int(values.get("low_confidence", 0))
    result["setup_lifecycle_failed"] += int(values.get("failed", 0))
    if performance is not None:
        for name, value in (values.get("performance") or {}).items():
            performance.set_metric(name, value)


def _apply_setup_lifecycle_evaluation_result(
    result: dict[str, Any],
    evaluation_result: Any,
) -> None:
    values = (
        evaluation_result.as_dict()
        if hasattr(evaluation_result, "as_dict")
        else dict(evaluation_result)
    )
    result["setup_lifecycle_change_events"] = int(
        values.get("change_events", values.get("changed", 0))
    )
    result["setup_lifecycle_canonical_snapshots"] = int(
        values.get(
            "canonical_snapshots",
            values.get("canonical", result["setup_lifecycle_canonical_snapshots"]),
        )
    )
    result["setup_lifecycle_transitions"] = int(
        values.get("lifecycle_transitions", values.get("transitioned", 0))
    )
    result["setup_lifecycle_alerts"] = int(values.get("alerts", values.get("alerted", 0)))
    result["setup_lifecycle_active_episodes"] = int(values.get("active_episodes", 0))
    result["setup_lifecycle_low_confidence"] += int(values.get("low_confidence", 0))
    result["setup_lifecycle_failed"] += int(values.get("failed", 0))


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _duration_ms(started_at: datetime | None, completed_at: datetime | None) -> float | None:
    if started_at is None or completed_at is None:
        return None
    if started_at.tzinfo is None and completed_at.tzinfo is not None:
        started_at = started_at.replace(tzinfo=completed_at.tzinfo)
    if completed_at.tzinfo is None and started_at.tzinfo is not None:
        completed_at = completed_at.replace(tzinfo=started_at.tzinfo)
    return round(max(0.0, (completed_at - started_at).total_seconds() * 1000), 3)
