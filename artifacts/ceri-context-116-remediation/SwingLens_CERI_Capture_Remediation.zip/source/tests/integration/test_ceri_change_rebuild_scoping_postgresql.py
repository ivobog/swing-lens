"""Production-shape regression for scoped CERI change detection."""

from __future__ import annotations

import re
from collections import Counter
from datetime import UTC, date, datetime, timedelta

import pytest
import test_contextual_configuration_adoption_postgresql as contextual
from sqlalchemy import event
from sqlalchemy.dialects import postgresql
from sqlalchemy.orm import Session

from app.models.ceri_tables import (
    CeriCatalystEvent,
    CeriCatalystEventRevision,
    CeriCompany,
    CeriGuidanceEvent,
    CeriScoreSnapshot,
    CeriSourceRecord,
)
from app.models.tables import MarketCalculationContext, PipelineRun, UploadRun
from app.services.ceri.change_detection_service import ChangeDetectionResult
from app.services.ceri.change_rebuild_service import (
    CeriChangeRebuildRequest,
    CeriChangeRebuildService,
)
from app.services.ceri.evidence_eligibility import (
    HARD_UNSUCCESSFUL_PIPELINE_STATES,
    eligible_snapshot_select,
)
from app.services.pipeline_outcome import NO_INTEGRITY_HAZARD, PIPELINE_OUTCOME_CONTRACT_VERSION

contextual_engine = contextual.contextual_engine
pytestmark = [pytest.mark.integration, pytest.mark.destructive]

TABLES = (
    "ceri_score_snapshots",
    "ceri_catalyst_events",
    "ceri_catalyst_event_revisions",
    "ceri_guidance_events",
    "ceri_source_records",
)


@pytest.mark.parametrize(
    "target_count,unrelated_count,chunk_size",
    [(5, 0, 2), (5, 250, 2), (11, 500, 4)],
)
@pytest.mark.parametrize(
    "owner_state",
    ["COMPLETED", *sorted(HARD_UNSUCCESSFUL_PIPELINE_STATES), "SAFE_PARTIAL", "PARTIAL"],
)
def test_high_cardinality_unrelated_rows_never_enter_scoped_change_reads(
    contextual_engine,
    monkeypatch,
    record_property,
    target_count,
    unrelated_count,
    chunk_size,
    owner_state,
):
    as_of = date(2026, 9, 25)
    cutoff = datetime(2026, 9, 25, 22, tzinfo=UTC)
    with Session(contextual_engine) as db:
        target_ids, target_source_ids, target_run_id = _seed_population(
            db,
            target_count=target_count,
            unrelated_count=unrelated_count,
            as_of=as_of,
            cutoff=cutoff,
        )
        safe_partial = owner_state == "SAFE_PARTIAL"
        from sqlalchemy import select

        owner = db.scalar(select(PipelineRun).where(PipelineRun.upload_run_id == target_run_id))
        owner.status = "PARTIAL" if safe_partial else owner_state
        owner.result_json = (
            {
                "pipeline_outcome_summary": {
                    "contract_version": PIPELINE_OUTCOME_CONTRACT_VERSION,
                    "integrity": {"status": NO_INTEGRITY_HAZARD},
                }
            }
            if safe_partial
            else {}
        )
        db.commit()
        detector = RecordingDetector()
        captured: list[tuple[str, object]] = []
        materialized: Counter[str] = Counter()

        from app.services.ceri import change_rebuild_service as module

        original = module._scoped_scalars

        def observe_materialization(session, statement):
            rows = original(session, statement)
            entity = statement.column_descriptions[0].get("entity")
            table = getattr(entity, "__tablename__", None)
            if table in TABLES:
                materialized[table] += len(rows)
            return rows

        def observe_sql(_connection, _cursor, sql, parameters, _context, _many):
            if sql.lstrip().upper().startswith("SELECT") and any(table in sql for table in TABLES):
                captured.append((sql, parameters))

        monkeypatch.setattr(module, "_scoped_scalars", observe_materialization)
        event.listen(contextual_engine, "before_cursor_execute", observe_sql)
        try:
            result = CeriChangeRebuildService(
                detector=detector,
                company_chunk_size=chunk_size,
            ).rebuild(
                db,
                CeriChangeRebuildRequest(
                    company_ids=tuple(target_ids),
                    run_id=target_run_id,
                    as_of_session=as_of,
                    cutoff_at=cutoff,
                ),
            )
        finally:
            event.remove(contextual_engine, "before_cursor_execute", observe_sql)

        assert result.failed == 0
        eligible = owner_state in {"COMPLETED", "SAFE_PARTIAL"}
        assert set(detector.company_ids) == (set(target_ids) if eligible else set())
        assert len(detector.score_ids) == (target_count if eligible else 0)
        assert len(detector.revision_ids) == target_count
        assert len(detector.guidance_ids) == target_count
        assert captured
        assert not [sql for sql, _params in captured if not re.search(r"\bWHERE\b", sql, re.I)]

        source_body_queries = [
            (sql, params)
            for sql, params in captured
            if re.match(r"\s*SELECT\s+ceri_source_records\.id", sql, re.I)
        ]
        assert source_body_queries
        loaded_source_ids = {
            value
            for _sql, params in source_body_queries
            for value in _integer_parameters(params)
            if value in target_source_ids
        }
        assert loaded_source_ids == target_source_ids
        assert not {
            value
            for _sql, params in source_body_queries
            for value in _integer_parameters(params)
            if value not in target_source_ids
        }

        query_counts = {table: sum(table in sql for sql, _params in captured) for table in TABLES}
        max_parameters = max(_parameter_count(params) for _sql, params in captured)
        record_property("unrelated_companies", unrelated_count)
        record_property("unrelated_source_records", unrelated_count * 2)
        record_property("scoped_companies", target_count)
        record_property("chunk_size", chunk_size)
        record_property("owner_state", owner_state)
        record_property("materialized_rows", dict(materialized))
        record_property("source_body_rows", len(loaded_source_ids))
        record_property("query_counts", query_counts)
        record_property("maximum_parameter_count", max_parameters)
        record_property("predicate_free_large_ceri_reads", 0)

        assert materialized["ceri_score_snapshots"] <= target_count * 2
        assert materialized["ceri_catalyst_events"] == target_count
        assert materialized["ceri_catalyst_event_revisions"] == target_count
        assert materialized["ceri_guidance_events"] == target_count
        # Compile the actual set-based predicate with expanded terminal-state
        # binds. JSON policy keys/values and conditional PARTIAL checks are a
        # fixed cost; scoped company IDs and run/session/cutoff are variable.
        policy_statement = eligible_snapshot_select(CeriScoreSnapshot)
        compiled = policy_statement.compile(
            dialect=postgresql.dialect(),
            compile_kwargs={"render_postcompile": True},
        )
        fixed_eligibility_parameters = len(compiled.params)
        scoped_boundary_parameters = 3 + chunk_size
        record_property("fixed_policy_parameter_count", fixed_eligibility_parameters)
        assert max_parameters <= fixed_eligibility_parameters + scoped_boundary_parameters
        # Independent of total population, at most two score reads and a
        # bounded set of event/source reads occur per requested company chunk.
        chunks = (target_count + chunk_size - 1) // chunk_size
        assert len(captured) <= chunks * 12


class RecordingDetector:
    def __init__(self):
        self.company_ids: list[int] = []
        self.score_ids: list[int] = []
        self.revision_ids: list[int] = []
        self.guidance_ids: list[int] = []

    def detect_score_changes(self, _db, *, current, prior, scope):
        del prior, scope
        self.company_ids.append(current.company_id)
        self.score_ids.append(current.id)
        return ChangeDetectionResult(0, 0)

    def detect_catalyst_revision(self, _db, *, revision, prior_revision, company_id, market_cutoff):
        del prior_revision, company_id, market_cutoff
        self.revision_ids.append(revision.id)
        return ChangeDetectionResult(0, 0)

    def detect_guidance_change(self, _db, *, guidance, **_kwargs):
        self.guidance_ids.append(guidance.id)
        return ChangeDetectionResult(0, 0)


def _seed_population(db, *, target_count, unrelated_count, as_of, cutoff):
    target_ids: list[int] = []
    target_source_ids: set[int] = set()
    target_run = UploadRun(filename="ceri-change-target.csv", status="COMPLETED", row_count=0)
    unrelated_run = UploadRun(filename="ceri-change-unrelated.csv", status="COMPLETED", row_count=0)
    db.add_all((target_run, unrelated_run))
    db.flush()
    owner = PipelineRun(upload_run_id=target_run.id, status="COMPLETED")
    db.add(owner)
    db.flush()
    context = MarketCalculationContext(
        pipeline_run_id=owner.id,
        upload_run_id=target_run.id,
        cutoff_at=cutoff - timedelta(minutes=1),
        exchange_timezone="America/New_York",
        latest_completed_session=as_of,
        calendar_version="test-scope-v1",
        bar_readiness_version="test-scope-v1",
        cutoff_reason="SCOPED_CERI_TEST",
    )
    db.add(context)
    db.flush()
    total = target_count + unrelated_count
    for index in range(total):
        company = CeriCompany(ticker=f"SCOPE{index:04d}", exchange="US")
        db.add(company)
        db.flush()
        is_target = index < target_count
        if is_target:
            target_ids.append(company.id)
        revision_source = _source(f"revision-{index}", cutoff - timedelta(days=2))
        guidance_source = _source(f"guidance-{index}", cutoff - timedelta(days=2))
        db.add_all((revision_source, guidance_source))
        db.flush()
        if is_target:
            target_source_ids.update((revision_source.id, guidance_source.id))
        catalyst = CeriCatalystEvent(
            company_id=company.id,
            category="PRODUCT",
            subject_key=f"subject-{index}",
        )
        db.add(catalyst)
        db.flush()
        db.add(
            CeriCatalystEventRevision(
                catalyst_event_id=catalyst.id,
                source_record_id=revision_source.id,
                revision_number=1,
                is_current=True,
                announced_at=cutoff - timedelta(days=1),
                effective_session=as_of,
                status="ANNOUNCED",
                direction="POSITIVE",
            )
        )
        db.add(
            CeriGuidanceEvent(
                source_record_id=guidance_source.id,
                company_id=company.id,
                action="RAISED",
                effective_at=cutoff - timedelta(days=1),
                effective_session=as_of,
                accepted_for_scoring=True,
            )
        )
        db.add(
            CeriScoreSnapshot(
                run_id=target_run.id if is_target else unrelated_run.id,
                calculation_context_id=context.id if is_target else None,
                company_id=company.id,
                ticker=company.ticker,
                as_of_session=as_of,
                cutoff_at=cutoff - timedelta(minutes=1),
                opportunity_score=5,
                data_confidence="Normal",
                coverage_pct=100,
                posture="Mixed",
                config_version="test",
                config_hash="test",
                calculation_version="test",
                evidence_contract_version="test",
                comparison_state="NO_PRIOR_COMPARABLE_SNAPSHOT",
                evidence_hash=f"score-{index}",
            )
        )
    return target_ids, target_source_ids, target_run.id


def _source(key, known_at):
    return CeriSourceRecord(
        provider="test",
        dataset="test",
        provider_record_id=key,
        retrieved_at=known_at,
        ingested_at=known_at,
        raw_json={"key": key},
        content_hash=f"hash-{key}",
        idempotency_key=f"scope-{key}",
    )


def _integer_parameters(parameters) -> set[int]:
    values: set[int] = set()
    if isinstance(parameters, dict):
        items = parameters.values()
    elif isinstance(parameters, (tuple, list)):
        items = parameters
    else:
        items = ()
    for item in items:
        if isinstance(item, bool):
            continue
        if isinstance(item, int):
            values.add(item)
        elif isinstance(item, (tuple, list, dict)):
            values.update(_integer_parameters(item))
    return values


def _parameter_count(parameters) -> int:
    if isinstance(parameters, dict):
        return sum(_parameter_count(value) for value in parameters.values())
    if isinstance(parameters, (tuple, list)):
        return sum(_parameter_count(value) for value in parameters)
    return 1
